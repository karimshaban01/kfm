<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
if (is_post()) {
    check_post();
    $name = p('name'); $phone = norm_phone(p('phone')); $email = strtolower(p('email')); $pw = $_POST['password'] ?? '';
    if ($name === '' || !$phone) throw new UserError('Enter your name and a valid Tanzanian phone number.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new UserError('That email address is not valid.');
    if (strlen($pw) < 8) throw new UserError('Password must be at least 8 characters.');
    if ($pw !== ($_POST['password2'] ?? '')) throw new UserError('Passwords do not match.');
    if (val('SELECT 1 FROM users WHERE phone=?', [$phone]) || ($email !== '' && val('SELECT 1 FROM users WHERE email=?', [$email]))) throw new UserError('An account with that phone or email already exists.');
    $id = insert('users', ['full_name' => $name, 'phone' => $phone, 'email' => $email !== '' ? $email : null, 'password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'role' => 'customer', 'status' => 'active', 'created_at' => now()]);
    audit('register', 'user', $id); do_login($phone, $pw); flash('Welcome to KFM!');
    $next = $_SESSION['next'] ?? ''; unset($_SESSION['next']); go($next && $next[0] === '/' ? $next : 'account.php');
}
head('Register');
?>
<div class="row justify-content-center"><div class="col-md-5"><div class="card card-body"><h1 class="h4">Create customer account</h1>
<form method="post"><?= csrf() ?>
<label class="form-label">Full name</label><input name="name" class="form-control mb-2" required value="<?= e($_POST['name'] ?? '') ?>">
<label class="form-label">Phone</label><input name="phone" class="form-control mb-2" required placeholder="0712 345 678" value="<?= e($_POST['phone'] ?? '') ?>">
<label class="form-label">Email (optional)</label><input type="email" name="email" class="form-control mb-2" value="<?= e($_POST['email'] ?? '') ?>">
<label class="form-label">Password (8+ characters)</label><input type="password" name="password" class="form-control mb-2" required minlength="8">
<label class="form-label">Confirm password</label><input type="password" name="password2" class="form-control mb-3" required>
<button class="btn btn-brown w-100"><?= t('Register') ?></button></form></div></div></div>
<?php foot();

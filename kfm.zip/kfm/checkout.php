<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = user(); if (!$u) { $_SESSION['next'] = url('checkout.php'); flash('Please log in or register to check out. Your cart is kept.', 'info'); go('login.php'); }
if ($u['role'] !== 'customer') throw new HttpError(403, 'Only customer accounts can place orders.');
$lines = cart_lines(); if (!$lines) { flash('Your cart is empty.', 'warning'); go('cart.php'); }
$sellers = count(array_unique(array_column($lines, 'seller_id'))); $sub = array_sum(array_column($lines, 'line'));
$fee = (float)setting('delivery_fee_default', 10000);
if (is_post()) {
    check_post();
    $fulfil = p('fulfil') === 'collection' ? 'collection' : 'delivery'; $method = p('method');
    $name = p('name'); $phone = norm_phone(p('phone')); $email = p('email');
    if ($name === '' || !$phone) throw new UserError('Enter your name and a valid phone number (e.g. 0712 345 678).');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new UserError('That email address is not valid.');
    $addr = ['name' => $name, 'phone' => $phone, 'text' => ''];
    if ($fulfil === 'delivery') {
        $addr['text'] = trim(p('street') . ', ' . p('ward') . ', ' . p('district') . ' ' . p('landmark') . ' ' . p('instructions'), ' ,');
        if (p('street') === '' && p('landmark') === '') throw new UserError('Enter a delivery address or landmark.');
    }
    $allowed = $fulfil === 'delivery' ? ['cash_on_delivery', 'mobile_money'] : ['cash_on_collection', 'mobile_money'];
    if (!in_array($method, $allowed, true)) throw new UserError('Choose a payment method.');
    $pay = ['provider' => null, 'ref' => '', 'phone' => null];
    if ($method === 'mobile_money') {
        $pay['provider'] = p('provider'); $pay['ref'] = strtoupper(p('ref')); $pay['phone'] = norm_phone(p('mm_phone')) ?: $phone;
        if (!in_array($pay['provider'], ['M-Pesa', 'Airtel Money', 'Mixx by Yas', 'HaloPesa'], true)) throw new UserError('Choose a mobile money provider.');
        if ($pay['ref'] !== '' && val('SELECT 1 FROM payments WHERE transaction_reference=?', [$pay['ref']])) throw new UserError('That transaction reference has already been used.');
    }
    [$oid, $num] = place_order($u, ['name' => $name, 'phone' => $phone, 'email' => $email, 'method' => $method, 'fulfil' => $fulfil, 'addr' => $addr, 'pay' => $pay]);
    go('order.php?id=' . $oid . '&new=1');
}
head('Checkout');
$f = fn($k, $d = '') => e($_POST[$k] ?? $d);
?>
<h1 class="h3"><?= t('Checkout') ?></h1>
<div class="alert alert-info">Your order contains items from <strong><?= $sellers ?></strong> seller(s). Each seller prepares and delivers their own part, but you pay once.</div>
<form method="post" class="row g-4"><?= csrf() ?>
<div class="col-lg-7">
  <div class="card card-body mb-3"><h2 class="h5">Contact</h2><div class="row g-2">
    <div class="col-md-6"><label class="form-label">Name</label><input name="name" required class="form-control" value="<?= $f('name', $u['full_name']) ?>"></div>
    <div class="col-md-6"><label class="form-label">Phone</label><input name="phone" required class="form-control" value="<?= $f('phone', $u['phone']) ?>"></div>
    <div class="col-12"><label class="form-label">Email (optional)</label><input name="email" type="email" class="form-control" value="<?= $f('email', $u['email']) ?>"></div></div></div>
  <div class="card card-body mb-3"><h2 class="h5">Delivery or collection</h2>
    <div class="form-check"><input class="form-check-input" type="radio" name="fulfil" value="delivery" id="fd" checked><label class="form-check-label" for="fd">Delivery - <?= money($fee) ?> per seller</label></div>
    <div class="form-check mb-2"><input class="form-check-input" type="radio" name="fulfil" value="collection" id="fc"><label class="form-check-label" for="fc">I will collect from the seller(s) - free</label></div>
    <div id="addr" class="row g-2"><div class="col-md-6"><input name="district" class="form-control" placeholder="District / area" value="<?= $f('district', 'Kasulu') ?>"></div><div class="col-md-6"><input name="ward" class="form-control" placeholder="Ward" value="<?= $f('ward') ?>"></div>
    <div class="col-12"><input name="street" class="form-control" placeholder="Street / village" value="<?= $f('street') ?>"></div><div class="col-12"><input name="landmark" class="form-control" placeholder="Nearby landmark" value="<?= $f('landmark') ?>"></div><div class="col-12"><textarea name="instructions" class="form-control" rows="2" placeholder="Delivery instructions (optional)"><?= $f('instructions') ?></textarea></div></div></div>
  <div class="card card-body"><h2 class="h5">Payment</h2>
    <div class="form-check"><input class="form-check-input" type="radio" name="method" value="cash_on_delivery" id="m1" checked><label class="form-check-label" for="m1">Cash on delivery</label></div>
    <div class="form-check"><input class="form-check-input" type="radio" name="method" value="cash_on_collection" id="m2"><label class="form-check-label" for="m2">Cash on collection</label></div>
    <div class="form-check"><input class="form-check-input" type="radio" name="method" value="mobile_money" id="m3"><label class="form-check-label" for="m3">Mobile money (verified by the marketplace)</label></div>
    <div id="mm" class="mt-2 border rounded p-2 bg-light" style="display:none"><div class="small mb-2" style="white-space:pre-line"><?= e(setting('mobile_money_instructions')) ?></div>
      <div class="row g-2"><div class="col-md-6"><select name="provider" class="form-select"><?= opts(['M-Pesa' => 'M-Pesa', 'Airtel Money' => 'Airtel Money', 'Mixx by Yas' => 'Mixx by Yas', 'HaloPesa' => 'HaloPesa'], $_POST['provider'] ?? '', 'Provider') ?></select></div>
      <div class="col-md-6"><input name="mm_phone" class="form-control" placeholder="Phone you paid from"></div><div class="col-12"><input name="ref" class="form-control" placeholder="Transaction reference (you can add it later on your order page)"></div></div></div></div>
</div>
<div class="col-lg-5"><div class="card card-body"><h2 class="h5">Summary</h2>
  <?php foreach ($lines as $l): ?><div class="d-flex justify-content-between small"><span><?= e($l['product_name']) ?> x<?= (int)$l['quantity'] ?><br><span class="text-muted"><?= e($l['shop_name']) ?></span></span><span><?= money($l['line']) ?></span></div><?php endforeach; ?><hr>
  <div class="d-flex justify-content-between"><span>Merchandise</span><span><?= money($sub) ?></span></div><div class="d-flex justify-content-between"><span>Delivery</span><span id="dl"><?= money($fee * $sellers) ?></span></div>
  <div class="d-flex justify-content-between fw-bold fs-5"><span>Total</span><span id="gt"><?= money($sub + $fee * $sellers) ?></span></div>
  <button class="btn btn-brown btn-lg mt-3"><?= t('Place order') ?></button></div></div>
</form>
<script>
const fee=<?= json_encode($fee * $sellers) ?>,sub=<?= json_encode($sub) ?>,fmt=n=>'TZS '+n.toLocaleString('en-US');
function sync(){const col=document.getElementById('fc').checked,m=document.querySelector('[name=method]:checked').value;
 document.getElementById('addr').style.display=col?'none':'';document.getElementById('m1').disabled=col;document.getElementById('m2').disabled=!col;
 if(col&&m==='cash_on_delivery')document.getElementById('m2').checked=true;if(!col&&m==='cash_on_collection')document.getElementById('m1').checked=true;
 document.getElementById('mm').style.display=document.getElementById('m3').checked?'':'none';
 document.getElementById('dl').textContent=fmt(col?0:fee);document.getElementById('gt').textContent=fmt(sub+(col?0:fee));}
document.querySelectorAll('input[type=radio]').forEach(r=>r.addEventListener('change',sync));sync();
</script>
<?php foot();

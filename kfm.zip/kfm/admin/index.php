<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin');
$c = fn($sql) => (int)val($sql);
$today = date('Y-m-d') . ' 00:00:00';
$stats = [['Sellers awaiting approval', $c("SELECT COUNT(*) FROM seller_profiles WHERE approval_status='pending'"), 'sellers.php?status=pending'], ['Products awaiting approval', $c("SELECT COUNT(*) FROM products WHERE status='pending'"), 'products.php?status=pending'],
    ['Payments to verify', $c("SELECT COUNT(*) FROM payments WHERE payment_status='awaiting_verification'"), 'payments.php?status=awaiting_verification'], ['Orders today', $c("SELECT COUNT(*) FROM orders WHERE created_at>='$today'"), 'orders.php'],
    ['Active sellers', $c("SELECT COUNT(*) FROM seller_profiles WHERE approval_status='approved'"), 'sellers.php?status=approved'], ['Published products', $c("SELECT COUNT(*) FROM products WHERE status='published'"), 'products.php?status=published']];
$gmv = (float)val("SELECT COALESCE(SUM(merchandise_subtotal),0) FROM seller_orders WHERE order_status='completed'");
$com = (float)val("SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger");
$top = rows("SELECT s.shop_name, SUM(so.merchandise_subtotal) total, COUNT(*) n FROM seller_orders so JOIN shops s ON s.seller_id=so.seller_id WHERE so.order_status='completed' GROUP BY s.shop_name ORDER BY total DESC LIMIT 5");
$recent = rows('SELECT * FROM orders ORDER BY id DESC LIMIT 8');
head('Admin dashboard', 'admin');
?>
<h1 class="h3"><?= t('Dashboard') ?></h1>
<div class="row g-3 mb-3"><?php foreach ($stats as $s): ?><div class="col-6 col-md-4 col-lg-2"><a class="card card-body text-decoration-none <?= $s[1] && in_array($s[0], ['Sellers awaiting approval', 'Products awaiting approval', 'Payments to verify'], true) ? 'border-warning' : '' ?>" href="<?= e(url('admin/' . $s[2])) ?>"><div class="small text-muted"><?= $s[0] ?></div><div class="fs-3"><?= $s[1] ?></div></a></div><?php endforeach; ?></div>
<div class="row g-3 mb-3"><div class="col-md-6"><div class="card card-body"><div class="small text-muted">Completed merchandise sales</div><div class="fs-4"><?= money($gmv) ?></div></div></div><div class="col-md-6"><div class="card card-body"><div class="small text-muted">Commission recognised (net of reversals)</div><div class="fs-4"><?= money($com) ?></div></div></div></div>
<div class="row g-3"><div class="col-md-6"><h2 class="h5">Top shops</h2><table class="table table-sm"><?php foreach ($top as $t) echo '<tr><td>' . e($t['shop_name']) . '</td><td>' . (int)$t['n'] . ' orders</td><td class="text-end">' . money($t['total']) . '</td></tr>'; if (!$top) echo '<tr><td class="text-muted">No completed sales yet.</td></tr>'; ?></table></div>
<div class="col-md-6"><h2 class="h5">Recent orders</h2><table class="table table-sm"><?php foreach ($recent as $o) echo '<tr><td><a href="' . e(url('admin/order.php?id=' . $o['id'])) . '">' . e($o['order_number']) . '</a></td><td>' . money($o['grand_total']) . '</td><td>' . badge($o['order_status']) . '</td></tr>'; ?></table></div></div>
<?php foot();

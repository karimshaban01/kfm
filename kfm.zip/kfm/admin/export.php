<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php'; need_role('admin');
$type = g('type') === 'commission' ? 'commission' : 'orders';
header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename="kfm-' . $type . '-' . date('Ymd') . '.csv"');
$out = fopen('php://output', 'w');
$safe = fn($v) => is_string($v) && $v !== '' && strpbrk($v[0], "=+-@\t\r") ? "'" . $v : $v;   // neutralise spreadsheet formulas
if ($type === 'orders') {
    fputcsv($out, ['Seller order', 'Checkout', 'Date', 'Seller', 'Customer', 'Payment', 'Status', 'Merchandise', 'Delivery', 'Commission rate', 'Commission', 'Seller net']);
    foreach (rows('SELECT so.*, o.order_number, o.customer_name, o.payment_method, COALESCE(s.shop_name, \'\') shop FROM seller_orders so JOIN orders o ON o.id=so.order_id LEFT JOIN shops s ON s.seller_id=so.seller_id ORDER BY so.id') as $r)
        fputcsv($out, array_map($safe, [$r['seller_order_number'], $r['order_number'], $r['created_at'], $r['shop'], $r['customer_name'], $r['payment_method'], $r['order_status'], $r['merchandise_subtotal'], $r['delivery_fee'], $r['commission_rate'], $r['commission_amount'], $r['seller_net_amount']]));
} else {
    fputcsv($out, ['Date', 'Seller order', 'Seller', 'Type', 'Source', 'Amount', 'Settled', 'Description']);
    foreach (rows('SELECT l.*, so.seller_order_number, COALESCE(s.shop_name, \'\') shop FROM commission_ledger l JOIN seller_orders so ON so.id=l.seller_order_id LEFT JOIN shops s ON s.seller_id=l.seller_id ORDER BY l.id') as $r)
        fputcsv($out, array_map($safe, [$r['created_at'], $r['seller_order_number'], $r['shop'], $r['transaction_type'], $r['source'], $r['commission_amount'], $r['settled_at'], $r['description']]));
}

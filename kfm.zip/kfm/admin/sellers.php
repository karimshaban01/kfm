<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin');
if (is_post()) {
    check_post(); $uid = (int)p('uid'); $do = p('do'); $reason = p('reason'); $pr = seller_profile($uid); if (!$pr) throw new UserError('Seller not found.');
    $map = ['approve' => ['approved', 'active'], 'reject' => ['rejected', 'rejected'], 'suspend' => ['suspended', 'suspended'], 'reinstate' => ['approved', 'active']];
    if (!isset($map[$do])) throw new UserError('Unknown action.');
    if (in_array($do, ['reject', 'suspend'], true) && $reason === '') throw new UserError('A reason is required to reject or suspend a seller.');
    tx(function () use ($uid, $do, $reason, $map, $a) {
        upd('seller_profiles', val('SELECT id FROM seller_profiles WHERE user_id=?', [$uid]), ['approval_status' => $map[$do][0], 'approved_by' => $a['id'], 'approved_at' => $do === 'approve' || $do === 'reinstate' ? now() : null, 'rejection_reason' => $reason !== '' ? $reason : null]);
        q('UPDATE shops SET status=?, updated_at=? WHERE seller_id=?', [$map[$do][1], now(), $uid]);
        notify($uid, 'Seller account ' . $map[$do][0], $reason, 'seller', $uid); audit('seller.' . $do, 'user', $uid, $reason);
    });
    flash('Seller ' . $map[$do][0] . '.'); go('admin/sellers.php?status=' . urlencode(g('status')));
}
$w = '1=1'; $par = []; if (g('status') !== '') { $w = 'sp.approval_status=?'; $par[] = g('status'); }
$list = rows("SELECT sp.*, u.full_name, u.phone, u.status ustatus, s.shop_name FROM seller_profiles sp JOIN users u ON u.id=sp.user_id LEFT JOIN shops s ON s.seller_id=u.id WHERE $w ORDER BY sp.id DESC", $par);
head('Sellers', 'admin');
?>
<h1 class="h3">Sellers</h1>
<form class="mb-3 d-flex gap-2"><select name="status" class="form-select w-auto"><?= opts(['pending' => 'Pending', 'approved' => 'Approved', 'rejected' => 'Rejected', 'suspended' => 'Suspended'], g('status'), 'All') ?></select><button class="btn btn-outline-secondary">Filter</button></form>
<?php foreach ($list as $s): ?><div class="card card-body mb-2"><div class="d-flex justify-content-between flex-wrap"><div><strong><?= e($s['shop_name'] ?: $s['business_name']) ?></strong> - <?= e($s['full_name']) ?> (+<?= e($s['phone']) ?>) <?= badge($s['approval_status']) ?></div><div class="small text-muted">Applied <?= e(substr($s['created_at'], 0, 10)) ?></div></div>
<div class="small"><?= e($s['business_location']) ?> - <?= e($s['business_description']) ?></div><?php if ($s['verification_document']): ?><div class="small"><a target="_blank" href="<?= e(url('file.php?f=' . $s['verification_document'])) ?>">View verification document</a></div><?php endif; ?>
<?php if ($s['rejection_reason']): ?><div class="small text-danger">Reason: <?= e($s['rejection_reason']) ?></div><?php endif; ?>
<form method="post" class="row g-2 mt-1"><?= csrf() ?><input type="hidden" name="uid" value="<?= $s['user_id'] ?>"><div class="col-md-5"><input name="reason" class="form-control form-control-sm" placeholder="Reason (required to reject/suspend)"></div><div class="col-md-7 d-flex gap-1 flex-wrap">
<?php foreach (['pending' => ['approve', 'reject'], 'rejected' => ['approve'], 'approved' => ['suspend'], 'suspended' => ['reinstate']][$s['approval_status']] as $act): ?><button name="do" value="<?= $act ?>" class="btn btn-sm <?= in_array($act, ['reject', 'suspend'], true) ? 'btn-outline-danger' : 'btn-success' ?>"><?= ucfirst($act) ?></button><?php endforeach; ?></div></form></div><?php endforeach; if (!$list) echo '<p class="text-muted">No sellers.</p>'; ?>
<?php foot();

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin'); $w = '1=1'; $par = []; if (g('q') !== '') { $w = '(a.action LIKE ? OR a.details LIKE ?)'; $par = ['%' . g('q') . '%', '%' . g('q') . '%']; }
[$items, $page, $pages] = paginate("SELECT a.*, u.full_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE $w ORDER BY a.id DESC", $par, 30);
head('Audit log', 'admin');
?>
<h1 class="h3">Audit log</h1><form class="mb-3 d-flex gap-2"><input name="q" value="<?= e(g('q')) ?>" class="form-control w-auto" placeholder="Search"><button class="btn btn-outline-secondary">Search</button></form>
<div class="table-responsive"><table class="table table-sm small"><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr><?php foreach ($items as $l): ?><tr><td><?= e($l['created_at']) ?></td><td><?= e($l['full_name'] ?? 'system') ?></td><td><?= e($l['action']) ?></td><td><?= e($l['entity_type']) ?> <?= e($l['entity_id']) ?></td><td><?= e($l['details']) ?></td><td><?= e($l['ip_address']) ?></td></tr><?php endforeach; ?></table></div>
<?php pager($page, $pages); foot();

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin');
if (is_post()) {
    check_post(); $name = p('name'); $id = (int)p('id');
    if (p('do') === 'toggle' && $id) { $c = row('SELECT * FROM categories WHERE id=?', [$id]); if ($c) upd('categories', $id, ['status' => $c['status'] === 'active' ? 'inactive' : 'active']); }
    elseif ($name !== '') {
        if (val('SELECT 1 FROM categories WHERE category_name=? AND id<>?', [$name, $id])) throw new UserError('That category already exists.');
        if ($id) { upd('categories', $id, ['category_name' => $name, 'description' => p('description')]); }
        else insert('categories', ['category_name' => $name, 'slug' => unique_slug('categories', 'slug', $name), 'description' => p('description'), 'status' => 'active', 'created_at' => now()]);
        audit('category.save', 'category', $id ?: null, $name);
    } else throw new UserError('Enter a category name.');
    flash('Saved.'); go('admin/categories.php');
}
$list = rows('SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id=c.id) n FROM categories c ORDER BY category_name');
head('Categories', 'admin');
?>
<h1 class="h3">Categories</h1>
<form method="post" class="row g-2 mb-3"><?= csrf() ?><div class="col-md-4"><input name="name" class="form-control" placeholder="New category name" required></div><div class="col-md-5"><input name="description" class="form-control" placeholder="Description (optional)"></div><div class="col-md-3"><button class="btn btn-brown w-100">Add</button></div></form>
<table class="table table-sm"><tr><th>Name</th><th>Products</th><th>Status</th><th></th></tr><?php foreach ($list as $c): ?><tr><td><form method="post" class="d-flex gap-1"><?= csrf() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><input name="name" value="<?= e($c['category_name']) ?>" class="form-control form-control-sm"><input type="hidden" name="description" value="<?= e($c['description']) ?>"><button class="btn btn-sm btn-outline-secondary">Rename</button></form></td><td><?= (int)$c['n'] ?></td><td><?= badge($c['status']) ?></td>
<td><form method="post"><?= csrf() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><button name="do" value="toggle" class="btn btn-sm btn-outline-secondary"><?= $c['status'] === 'active' ? 'Deactivate' : 'Activate' ?></button></form></td></tr><?php endforeach; ?></table>
<?php foot();

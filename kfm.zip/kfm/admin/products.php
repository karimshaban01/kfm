<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin');
if (is_post()) {
    check_post(); $pid = (int)p('pid'); $do = p('do'); $pr = row('SELECT * FROM products WHERE id=?', [$pid]); if (!$pr) throw new UserError('Product not found.'); $reason = p('reason'); $shop = row('SELECT * FROM shops WHERE id=?', [$pr['shop_id']]);
    if ($do === 'feature') { upd('products', $pid, ['is_featured' => $pr['is_featured'] ? 0 : 1]); flash('Featured flag changed.'); }
    else {
        if (in_array($do, ['reject', 'suspend'], true) && $reason === '') throw new UserError('A reason is required.');
        if ($do === 'approve') { if (!seller_approved($shop['seller_id'])) throw new UserError('The seller is not approved.'); upd('products', $pid, ['status' => ($pr['product_type'] === 'ready_made' && $pr['stock_quantity'] <= 0) ? 'out_of_stock' : 'published', 'status_reason' => null]); }
        elseif ($do === 'reject') upd('products', $pid, ['status' => 'rejected', 'status_reason' => $reason]);
        elseif ($do === 'suspend') upd('products', $pid, ['status' => 'suspended', 'status_reason' => $reason]);
        elseif ($do === 'restore') upd('products', $pid, ['status' => ($pr['product_type'] === 'ready_made' && $pr['stock_quantity'] <= 0) ? 'out_of_stock' : 'published', 'status_reason' => null]);
        else throw new UserError('Unknown action.');
        notify($shop['seller_id'], 'Product ' . $do . ': ' . $pr['product_name'], $reason, 'product', $pid); audit('product.' . $do, 'product', $pid, $reason); flash('Done.');
    }
    go('admin/products.php?status=' . urlencode(g('status')));
}
$w = '1=1'; $par = []; if (g('status') !== '') { $w = 'p.status=?'; $par[] = g('status'); }
[$items, $page, $pages] = paginate("SELECT p.*, s.shop_name, c.category_name FROM products p JOIN shops s ON s.id=p.shop_id JOIN categories c ON c.id=p.category_id WHERE $w ORDER BY p.id DESC", $par, 15);
head('Products', 'admin');
?>
<h1 class="h3">Products</h1>
<form class="mb-3 d-flex gap-2"><select name="status" class="form-select w-auto"><?= opts(array_combine(['draft', 'pending', 'published', 'rejected', 'suspended', 'out_of_stock'], ['Draft', 'Pending', 'Published', 'Rejected', 'Suspended', 'Out of stock']), g('status'), 'All') ?></select><button class="btn btn-outline-secondary">Filter</button></form>
<?php foreach ($items as $p): $im = product_image($p['id']); ?><div class="card card-body mb-2"><div class="d-flex gap-3"><?php if ($im): ?><img src="<?= e(img_url('products', $im)) ?>" style="height:70px" class="rounded" alt=""><?php endif; ?><div class="flex-grow-1"><strong><?= e($p['product_name']) ?></strong> <?= badge($p['status']) ?> <?= $p['is_featured'] ? '<span class="badge text-bg-warning">Featured</span>' : '' ?><div class="small text-muted"><?= e($p['shop_name']) ?> &middot; <?= e($p['category_name']) ?> &middot; <?= money($p['price']) ?> &middot; <?= label($p['product_type']) ?></div><div class="small"><?= e(mb_substr((string)$p['description'], 0, 160)) ?></div></div></div>
<form method="post" class="row g-2 mt-1"><?= csrf() ?><input type="hidden" name="pid" value="<?= $p['id'] ?>"><div class="col-md-5"><input name="reason" class="form-control form-control-sm" placeholder="Reason (required to reject/suspend)"></div><div class="col-md-7 d-flex gap-1 flex-wrap">
<?php if (in_array($p['status'], ['pending', 'rejected'], true)): ?><button name="do" value="approve" class="btn btn-sm btn-success">Approve</button><?php endif; ?><?php if ($p['status'] === 'pending'): ?><button name="do" value="reject" class="btn btn-sm btn-outline-danger">Reject</button><?php endif; ?>
<?php if (in_array($p['status'], ['published', 'out_of_stock'], true)): ?><button name="do" value="suspend" class="btn btn-sm btn-outline-danger">Suspend</button><button name="do" value="feature" class="btn btn-sm btn-outline-warning"><?= $p['is_featured'] ? 'Unfeature' : 'Feature' ?></button><?php endif; ?><?php if ($p['status'] === 'suspended'): ?><button name="do" value="restore" class="btn btn-sm btn-success">Restore</button><?php endif; ?></div></form></div><?php endforeach; if (!$items) echo '<p class="text-muted">No products.</p>'; ?>
<?php pager($page, $pages); foot();

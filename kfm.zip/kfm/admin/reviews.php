<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin');
if (is_post()) { check_post(); $r = row('SELECT * FROM reviews WHERE id=?', [(int)p('rid')]); if ($r) { q('UPDATE reviews SET status=? WHERE id=?', [$r['status'] === 'published' ? 'hidden' : 'published', $r['id']]); audit('review.moderate', 'review', $r['id']); } flash('Review updated.'); go('admin/reviews.php'); }
$list = rows('SELECT r.*, p.product_name, u.full_name FROM reviews r JOIN products p ON p.id=r.product_id JOIN users u ON u.id=r.customer_id ORDER BY r.id DESC LIMIT 60');
head('Reviews', 'admin');
?>
<h1 class="h3">Review moderation</h1>
<?php foreach ($list as $r): ?><div class="border-bottom py-2 d-flex justify-content-between gap-3"><div><span class="text-warning"><?= stars($r['rating']) ?></span> <strong><?= e($r['product_name']) ?></strong> by <?= e($r['full_name']) ?> <?= badge($r['status'] === 'published' ? 'published' : 'suspended') ?><div><?= nl2br(e($r['comment'])) ?></div></div>
<form method="post"><?= csrf() ?><input type="hidden" name="rid" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-outline-secondary"><?= $r['status'] === 'published' ? 'Hide' : 'Show' ?></button></form></div><?php endforeach; if (!$list) echo '<p class="text-muted">No reviews.</p>'; ?>
<?php foot();

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin');
if (is_post()) {
    check_post(); $rate = (float)p('commission_rate'); $fee = (float)p('delivery_fee_default');
    if (p('commission_rate') === '' || $rate < 0 || $rate > 50) throw new UserError('Commission must be between 0 and 50 percent.'); if ($fee < 0) throw new UserError('Delivery fee cannot be negative.');
    $old = setting('commission_rate');
    foreach (['marketplace_name', 'contact_phone', 'contact_email', 'mobile_money_instructions'] as $k) set_setting($k, p($k));
    set_setting('commission_rate', (string)$rate); set_setting('delivery_fee_default', (string)$fee);
    audit('settings.update', 'settings', null, 'commission ' . $old . ' -> ' . $rate); flash('Settings saved. The new commission rate applies to future orders only.'); go('admin/settings.php');
}
head('Settings', 'admin');
?>
<h1 class="h3">Marketplace settings</h1>
<form method="post" class="card card-body col-lg-8"><?= csrf() ?>
<label class="form-label">Marketplace name</label><input name="marketplace_name" class="form-control mb-2" value="<?= e(setting('marketplace_name')) ?>">
<div class="row g-2 mb-2"><div class="col-md-6"><label class="form-label">Commission rate (%) on merchandise</label><input type="number" step="0.01" min="0" max="50" name="commission_rate" class="form-control" value="<?= e(setting('commission_rate')) ?>"><div class="form-text">Delivery is never charged commission. Existing orders keep the rate they were placed with.</div></div>
<div class="col-md-6"><label class="form-label">Default delivery fee per seller (TZS)</label><input type="number" min="0" name="delivery_fee_default" class="form-control" value="<?= e(setting('delivery_fee_default')) ?>"></div></div>
<div class="row g-2 mb-2"><div class="col-md-6"><label class="form-label">Contact phone</label><input name="contact_phone" class="form-control" value="<?= e(setting('contact_phone')) ?>"></div><div class="col-md-6"><label class="form-label">Contact email</label><input name="contact_email" class="form-control" value="<?= e(setting('contact_email')) ?>"></div></div>
<label class="form-label">Mobile money payment instructions (shown to customers)</label><textarea name="mobile_money_instructions" rows="4" class="form-control mb-3"><?= e(setting('mobile_money_instructions')) ?></textarea><button class="btn btn-brown">Save settings</button></form>
<?php foot();

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin');
if (is_post()) {
    check_post(); $sid = (int)p('sid'); $do = p('do'); if (!val("SELECT 1 FROM users WHERE id=? AND role='seller'", [$sid])) throw new UserError('Seller not found.');
    if ($do === 'settle') {
        $n = q("UPDATE commission_ledger SET settled_at=? WHERE seller_id=? AND source='cash' AND settled_at IS NULL", [now(), $sid])->rowCount();
        audit('commission.settle', 'user', $sid, $n . ' ledger rows'); flash('Cash commission marked as settled (' . $n . ' entries).');
    } elseif ($do === 'payout') {
        tx(function () use ($sid, $a) {
            $b = seller_balance($sid); $amt = dec(p('amount')); if ($amt <= 0) throw new UserError('Enter a payout amount.'); if ($amt > $b['payable'] + 0.001) throw new UserError('Amount is more than the payable balance (' . money($b['payable']) . ').');
            if (p('method') === '') throw new UserError('Enter the payout method.');
            $id = insert('seller_payouts', ['seller_id' => $sid, 'amount' => $amt, 'payment_method' => p('method'), 'payment_reference' => p('ref') ?: null, 'payout_status' => 'paid', 'processed_by' => $a['id'], 'processed_at' => now(), 'created_at' => now()]);
            notify($sid, 'Payout sent', money($amt) . ' via ' . p('method'), 'payout', $id); audit('payout', 'user', $sid, money($amt));
        });
        flash('Payout recorded.');
    }
    go('admin/finance.php');
}
$sellers = rows("SELECT u.id, COALESCE(s.shop_name, u.full_name) name FROM users u LEFT JOIN shops s ON s.seller_id=u.id WHERE u.role='seller' ORDER BY name");
$tot = ['rec' => (float)val('SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger'), 'cash_owed' => (float)val("SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger WHERE source='cash' AND settled_at IS NULL"), 'mm' => (float)val("SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger WHERE source='mobile'")];
head('Finance', 'admin');
?>
<h1 class="h3">Commission and payouts <a class="btn btn-sm btn-outline-secondary ms-2" href="<?= e(url('admin/export.php?type=orders')) ?>">Export orders CSV</a> <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('admin/export.php?type=commission')) ?>">Export commission CSV</a></h1>
<div class="row g-3 mb-3"><div class="col-md-4"><div class="card card-body"><div class="small text-muted">Commission recognised</div><div class="fs-4"><?= money($tot['rec']) ?></div></div></div><div class="col-md-4"><div class="card card-body"><div class="small text-muted">Of which mobile money (already held)</div><div class="fs-4"><?= money($tot['mm']) ?></div></div></div><div class="col-md-4"><div class="card card-body border-warning"><div class="small text-muted">Cash commission not yet settled by sellers</div><div class="fs-4"><?= money($tot['cash_owed']) ?></div></div></div></div>
<div class="table-responsive"><table class="table table-sm align-middle"><tr><th>Seller</th><th>Sales</th><th>Commission</th><th>Cash owed to KFM</th><th>Payable to seller</th><th>Actions</th></tr>
<?php foreach ($sellers as $s): $b = seller_balance($s['id']); ?><tr><td><?= e($s['name']) ?></td><td><?= money($b['sales']) ?></td><td><?= money($b['commission']) ?></td><td><?= money($b['cash_commission_owed']) ?></td><td><?= money($b['payable']) ?></td><td class="d-flex flex-wrap gap-1">
<?php if (abs($b['cash_commission_owed']) > 0.001 || val("SELECT 1 FROM commission_ledger WHERE seller_id=? AND source='cash' AND settled_at IS NULL", [$s['id']])): ?><form method="post"><?= csrf() ?><input type="hidden" name="sid" value="<?= $s['id'] ?>"><button name="do" value="settle" class="btn btn-sm btn-outline-success" onclick="return confirm('Mark all cash commission for this seller as received?')">Mark cash settled</button></form><?php endif; ?>
<?php if ($b['payable'] > 0): ?><form method="post" class="d-flex gap-1"><?= csrf() ?><input type="hidden" name="sid" value="<?= $s['id'] ?>"><input name="amount" type="number" step="1" max="<?= $b['payable'] ?>" value="<?= (int)$b['payable'] ?>" class="form-control form-control-sm" style="width:110px"><input name="method" class="form-control form-control-sm" style="width:100px" placeholder="Method"><input name="ref" class="form-control form-control-sm" style="width:100px" placeholder="Reference"><button name="do" value="payout" class="btn btn-sm btn-brown">Pay out</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<?php foot();

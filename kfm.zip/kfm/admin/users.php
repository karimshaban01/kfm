<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin');
if (is_post()) {
    check_post(); $id = (int)p('uid'); $us = row('SELECT * FROM users WHERE id=?', [$id]); if (!$us) throw new UserError('User not found.');
    if (p('do') === 'status') {
        if ($id === (int)$a['id']) throw new UserError('You cannot suspend your own account.');
        $new = $us['status'] === 'active' ? 'suspended' : 'active'; upd('users', $id, ['status' => $new]); audit('user.' . $new, 'user', $id);
        if ($us['role'] === 'seller') q('UPDATE shops SET status=?, updated_at=? WHERE seller_id=? AND status IN (\'active\',\'suspended\')', [$new, now(), $id]);
        flash('User ' . $new . '.');
    } elseif (p('do') === 'reset') {
        $pw = $_POST['password'] ?? ''; if (strlen($pw) < 8) throw new UserError('Password must be at least 8 characters.');
        upd('users', $id, ['password_hash' => password_hash($pw, PASSWORD_DEFAULT)]); audit('user.password_reset', 'user', $id); flash('Password reset. Tell the user their new password securely.');
    }
    go('admin/users.php?role=' . urlencode(g('role')) . '&q=' . urlencode(g('q')));
}
$w = ['1=1']; $par = []; if (g('role') !== '') { $w[] = 'role=?'; $par[] = g('role'); } if (g('q') !== '') { $w[] = '(full_name LIKE ? OR phone LIKE ?)'; $par[] = '%' . g('q') . '%'; $par[] = '%' . g('q') . '%'; }
[$items, $page, $pages] = paginate('SELECT * FROM users WHERE ' . implode(' AND ', $w) . ' ORDER BY id DESC', $par, 20);
head('Users', 'admin');
?>
<h1 class="h3">Users</h1>
<form class="row g-2 mb-3"><div class="col-md-4"><input name="q" value="<?= e(g('q')) ?>" class="form-control" placeholder="Name or phone"></div><div class="col-md-3"><select name="role" class="form-select"><?= opts(['admin' => 'Admin', 'seller' => 'Seller', 'customer' => 'Customer'], g('role'), 'All roles') ?></select></div><div class="col-auto"><button class="btn btn-outline-secondary">Filter</button></div></form>
<div class="table-responsive"><table class="table table-sm align-middle"><tr><th>Name</th><th>Phone</th><th>Role</th><th>Status</th><th>Last login</th><th></th></tr>
<?php foreach ($items as $x): ?><tr><td><?= e($x['full_name']) ?></td><td>+<?= e($x['phone']) ?></td><td><?= label($x['role']) ?></td><td><?= badge($x['status']) ?></td><td><?= e($x['last_login_at']) ?></td><td class="d-flex gap-1"><form method="post"><?= csrf() ?><input type="hidden" name="uid" value="<?= $x['id'] ?>"><button name="do" value="status" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Change this account status?')"><?= $x['status'] === 'active' ? 'Suspend' : 'Activate' ?></button></form>
<form method="post" class="d-flex gap-1"><?= csrf() ?><input type="hidden" name="uid" value="<?= $x['id'] ?>"><input name="password" type="text" placeholder="New password" class="form-control form-control-sm" style="width:130px"><button name="do" value="reset" class="btn btn-sm btn-outline-secondary">Reset</button></form></td></tr><?php endforeach; ?></table></div>
<?php pager($page, $pages); foot();

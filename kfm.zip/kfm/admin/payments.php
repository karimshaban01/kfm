<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin');
if (is_post()) { check_post(); verify_payment((int)p('pid'), p('do') === 'verify', $a); flash(p('do') === 'verify' ? 'Payment verified.' : 'Payment rejected.'); go('admin/payments.php?status=' . urlencode(g('status'))); }
$w = '1=1'; $par = []; if (g('status') !== '') { $w = 'p.payment_status=?'; $par[] = g('status'); }
[$items, $page, $pages] = paginate("SELECT p.*, o.order_number, o.customer_name FROM payments p JOIN orders o ON o.id=p.order_id WHERE $w ORDER BY CASE WHEN p.payment_status='awaiting_verification' THEN 0 ELSE 1 END, p.id DESC", $par, 20);
head('Payments', 'admin');
?>
<h1 class="h3">Payments</h1>
<form class="mb-3 d-flex gap-2"><select name="status" class="form-select w-auto"><?= opts(array_combine(['pending', 'awaiting_verification', 'successful', 'failed', 'refunded', 'partially_refunded'], ['Pending', 'Awaiting verification', 'Successful', 'Failed', 'Refunded', 'Partially refunded']), g('status'), 'All') ?></select><button class="btn btn-outline-secondary">Filter</button></form>
<p class="small text-muted">Check the reference and amount in the marketplace's mobile money account before verifying. A customer-entered reference is not proof of payment.</p>
<div class="table-responsive"><table class="table table-sm"><tr><th>Order</th><th>Method</th><th>Provider</th><th>From</th><th>Amount</th><th>Reference</th><th>Status</th><th></th></tr>
<?php foreach ($items as $p): ?><tr><td><a href="<?= e(url('admin/order.php?id=' . $p['order_id'])) ?>"><?= e($p['order_number']) ?></a></td><td><?= label($p['payment_method']) ?></td><td><?= e($p['provider']) ?></td><td><?= e($p['customer_phone']) ?></td><td><?= money($p['amount']) ?></td><td><?= e($p['transaction_reference']) ?></td><td><?= badge($p['payment_status']) ?></td>
<td><?php if ($p['payment_method'] === 'mobile_money' && in_array($p['payment_status'], ['pending', 'awaiting_verification'], true)): ?><form method="post" class="d-flex gap-1"><?= csrf() ?><input type="hidden" name="pid" value="<?= $p['id'] ?>"><button name="do" value="verify" class="btn btn-sm btn-success" onclick="return confirm('Confirm that <?= e(money($p['amount'])) ?> was received?')">Verify</button><button name="do" value="reject" class="btn btn-sm btn-outline-danger">Reject</button></form><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<?php pager($page, $pages); foot();

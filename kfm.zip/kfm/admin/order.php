<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$a = need_role('admin'); $o = row('SELECT * FROM orders WHERE id=?', [(int)g('id')]); if (!$o) throw new HttpError(404);
if (is_post()) {
    check_post(); $so = (int)p('so'); $own = row('SELECT id FROM seller_orders WHERE id=? AND order_id=?', [$so, $o['id']]); if (!$own) throw new HttpError(404);
    if (p('do') === 'status') { so_transition($so, p('to'), $a, p('note') ?: 'Admin action'); flash('Updated.'); }
    if (p('do') === 'refund') { refund_so($so, $a, p('reason'), (bool)p('restock')); flash('Refund recorded and commission reversed.'); }
    go('admin/order.php?id=' . $o['id']);
}
$sos = rows('SELECT * FROM seller_orders WHERE order_id=? ORDER BY id', [$o['id']]); $pays = rows('SELECT * FROM payments WHERE order_id=? ORDER BY id', [$o['id']]);
head($o['order_number'], 'admin');
?>
<h1 class="h3"><?= e($o['order_number']) ?> <?= badge($o['order_status']) ?></h1>
<p><?= e($o['customer_name']) ?> +<?= e($o['customer_phone']) ?> <?= e($o['customer_email']) ?> &middot; Total <strong><?= money($o['grand_total']) ?></strong> &middot; <?= label($o['payment_method']) ?> &middot; <?= e($o['created_at']) ?></p>
<h2 class="h6">Payments</h2><table class="table table-sm"><tr><th>Scope</th><th>Method</th><th>Provider</th><th>Amount</th><th>Reference</th><th>Status</th></tr><?php foreach ($pays as $p) echo '<tr><td>' . ($p['seller_order_id'] ? 'Seller order #' . $p['seller_order_id'] : 'Whole checkout') . '</td><td>' . label($p['payment_method']) . '</td><td>' . e($p['provider']) . '</td><td>' . money($p['amount']) . '</td><td>' . e($p['transaction_reference']) . '</td><td>' . badge($p['payment_status']) . '</td></tr>'; ?></table>
<?php foreach ($sos as $so): $items = rows('SELECT * FROM order_items WHERE seller_order_id=?', [$so['id']]); $shop = seller_shop($so['seller_id']); $next = array_values(array_filter(so_next($so), fn($t) => so_role_can('admin', $t, $so)));
    $can_refund = in_array($so['order_status'], ['paid', 'processing', 'ready_for_collection', 'out_for_delivery', 'delivered', 'completed'], true) && so_paid($so + ['payment_method' => $o['payment_method']]); ?>
<div class="card mb-3"><div class="card-header d-flex justify-content-between"><span><strong><?= e($so['seller_order_number']) ?></strong> - <?= e($shop['shop_name']) ?></span><?= badge($so['order_status']) ?></div>
<div class="card-body"><?php foreach ($items as $i) echo '<div>' . e($i['product_name_snapshot']) . ' x' . (int)$i['quantity'] . ' - ' . money($i['line_total']) . '</div>'; ?>
<div class="small text-muted mt-1">Merchandise <?= money($so['merchandise_subtotal']) ?> &middot; Delivery <?= money($so['delivery_fee']) ?> &middot; Commission <?= e($so['commission_rate']) ?>% = <?= money($so['commission_amount']) ?> &middot; Seller net <?= money($so['seller_net_amount']) ?></div>
<?php if ($next): ?><form method="post" class="row g-2 mt-1"><?= csrf() ?><input type="hidden" name="do" value="status"><input type="hidden" name="so" value="<?= $so['id'] ?>"><div class="col-md-3"><select name="to" class="form-select form-select-sm"><?php foreach ($next as $n) echo '<option value="' . e($n) . '">' . e(label($n)) . '</option>'; ?></select></div><div class="col-md-6"><input name="note" class="form-control form-control-sm" placeholder="Note"></div><div class="col-md-3"><button class="btn btn-sm btn-brown">Change status</button></div></form><?php endif; ?>
<?php if ($can_refund): ?><form method="post" class="row g-2 mt-1" onsubmit="return confirm('Record a refund for this seller order?')"><?= csrf() ?><input type="hidden" name="do" value="refund"><input type="hidden" name="so" value="<?= $so['id'] ?>"><div class="col-md-6"><input name="reason" class="form-control form-control-sm" placeholder="Refund reason (required)"></div><div class="col-md-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="restock" value="1" id="rs<?= $so['id'] ?>"><label for="rs<?= $so['id'] ?>" class="form-check-label small">Return items to stock</label></div></div><div class="col-md-3"><button class="btn btn-sm btn-outline-danger">Refund</button></div></form><?php endif; ?></div></div><?php endforeach; ?>
<?php foot();

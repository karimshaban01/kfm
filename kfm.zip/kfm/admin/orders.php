<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
need_role('admin'); $w = ['1=1']; $par = [];
if (g('status') !== '') { $w[] = 'o.order_status=?'; $par[] = g('status'); }
if (g('q') !== '') { $w[] = '(o.order_number LIKE ? OR o.customer_name LIKE ? OR o.customer_phone LIKE ?)'; $l = '%' . g('q') . '%'; array_push($par, $l, $l, $l); }
[$items, $page, $pages] = paginate('SELECT o.*, (SELECT COUNT(*) FROM seller_orders so WHERE so.order_id=o.id) n FROM orders o WHERE ' . implode(' AND ', $w) . ' ORDER BY o.id DESC', $par, 20);
head('Orders', 'admin');
?>
<h1 class="h3">All orders</h1>
<form class="row g-2 mb-3"><div class="col-md-4"><input name="q" class="form-control" placeholder="Order no, name or phone" value="<?= e(g('q')) ?>"></div><div class="col-md-3"><select name="status" class="form-select"><?= opts(array_combine(['pending', 'confirmed', 'partially_completed', 'completed', 'cancelled'], ['Pending', 'Confirmed', 'Partially completed', 'Completed', 'Cancelled']), g('status'), 'All statuses') ?></select></div><div class="col-auto"><button class="btn btn-outline-secondary">Filter</button></div></form>
<div class="table-responsive"><table class="table table-sm"><tr><th>Order</th><th>Customer</th><th>Sellers</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th></th></tr>
<?php foreach ($items as $o): ?><tr><td><?= e($o['order_number']) ?></td><td><?= e($o['customer_name']) ?><div class="small text-muted">+<?= e($o['customer_phone']) ?></div></td><td><?= (int)$o['n'] ?></td><td><?= money($o['grand_total']) ?></td><td><?= label($o['payment_method']) ?></td><td><?= badge($o['order_status']) ?></td><td><?= e(substr($o['created_at'], 0, 10)) ?></td><td><a href="<?= e(url('admin/order.php?id=' . $o['id'])) ?>">Open</a></td></tr><?php endforeach; ?></table></div>
<?php pager($page, $pages); foot();

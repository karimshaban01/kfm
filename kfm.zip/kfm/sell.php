<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
if (user()) { flash('You are already logged in.', 'info'); go(home_for(user())); }
if (is_post()) {
    check_post();
    $name = p('name'); $phone = norm_phone(p('phone')); $email = strtolower(p('email')); $pw = $_POST['password'] ?? ''; $biz = p('business'); $loc = p('location');
    if ($name === '' || !$phone || $biz === '') throw new UserError('Enter your name, a valid phone number and your business name.');
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new UserError('That email address is not valid.');
    if (strlen($pw) < 8) throw new UserError('Password must be at least 8 characters.');
    if (val('SELECT 1 FROM users WHERE phone=?', [$phone]) || ($email !== '' && val('SELECT 1 FROM users WHERE email=?', [$email]))) throw new UserError('An account with that phone or email already exists.');
    $doc = null; $files = upload_list('doc'); if ($files) $doc = store_private_doc($files[0]);
    tx(function () use ($name, $phone, $email, $pw, $biz, $loc, $doc) {
        $uid = insert('users', ['full_name' => $name, 'phone' => $phone, 'email' => $email !== '' ? $email : null, 'password_hash' => password_hash($pw, PASSWORD_DEFAULT), 'role' => 'seller', 'status' => 'active', 'created_at' => now()]);
        insert('seller_profiles', ['user_id' => $uid, 'business_name' => $biz, 'business_description' => p('about'), 'business_location' => $loc, 'verification_document' => $doc, 'approval_status' => 'pending', 'created_at' => now()]);
        insert('shops', ['seller_id' => $uid, 'shop_name' => $biz, 'slug' => unique_slug('shops', 'slug', $biz), 'description' => p('about'), 'location' => $loc, 'phone' => $phone, 'status' => 'pending', 'created_at' => now()]);
        notify_admins('New seller application', $biz . ' (' . $phone . ')', 'seller', $uid);
    });
    do_login($phone, $pw); flash('Application received. An administrator will review it; you can prepare your shop meanwhile.'); go('seller/index.php');
}
head('Sell on KFM');
?>
<div class="row justify-content-center"><div class="col-md-7"><div class="card card-body"><h1 class="h4"><?= t('Sell on KFM') ?></h1><p class="text-muted">Apply to open your own shop. The marketplace reviews every seller before products go live. Commission: <?= e(setting('commission_rate')) ?>% of merchandise sold.</p>
<form method="post" enctype="multipart/form-data"><?= csrf() ?>
<div class="row g-2"><div class="col-md-6"><label class="form-label">Your full name</label><input name="name" class="form-control" required value="<?= e($_POST['name'] ?? '') ?>"></div>
<div class="col-md-6"><label class="form-label">Phone</label><input name="phone" class="form-control" required value="<?= e($_POST['phone'] ?? '') ?>"></div>
<div class="col-md-6"><label class="form-label">Email (optional)</label><input type="email" name="email" class="form-control" value="<?= e($_POST['email'] ?? '') ?>"></div>
<div class="col-md-6"><label class="form-label">Password (8+)</label><input type="password" name="password" class="form-control" required minlength="8"></div>
<div class="col-md-6"><label class="form-label">Business / shop name</label><input name="business" class="form-control" required value="<?= e($_POST['business'] ?? '') ?>"></div>
<div class="col-md-6"><label class="form-label">Workshop location</label><input name="location" class="form-control" value="<?= e($_POST['location'] ?? '') ?>"></div>
<div class="col-12"><label class="form-label">About your business</label><textarea name="about" class="form-control" rows="3"><?= e($_POST['about'] ?? '') ?></textarea></div>
<div class="col-12"><label class="form-label">ID or business document (JPG, PNG or PDF, private)</label><input type="file" name="doc[]" class="form-control" accept=".jpg,.jpeg,.png,.pdf"></div></div>
<button class="btn btn-brown mt-3">Submit application</button></form></div></div></div>
<?php foot();

<?php
// Kasulu Furniture Market - configuration. Edit the MySQL details below.
return [
    'db' => [
        'driver' => 'mysql',                     // 'mysql' (production) or 'sqlite' (quick local trial)
        'host'   => 'localhost',
        'name'   => 'kasulu_furniture_market',
        'user'   => 'root',
        'pass'   => '',
        'sqlite' => __DIR__ . '/private/kfm.sqlite',
    ],
    'debug' => false,
];

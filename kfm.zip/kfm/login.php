<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
if (user()) go(home_for(user()));
if (is_post()) {
    check_post();
    try { $u = do_login(p('ident'), $_POST['password'] ?? ''); }
    catch (UserError $e) { flash($e->getMessage(), 'danger'); go('login.php'); }
    $next = $_SESSION['next'] ?? ''; unset($_SESSION['next']);
    if ($next && $u['role'] === 'customer' && $next[0] === '/') go($next);
    go(home_for($u));
}
head('Login');
?>
<div class="row justify-content-center"><div class="col-md-5"><div class="card card-body"><h1 class="h4"><?= t('Login') ?></h1>
<form method="post"><?= csrf() ?><label class="form-label">Phone or email</label><input name="ident" class="form-control mb-2" required autofocus><label class="form-label">Password</label><input type="password" name="password" class="form-control mb-3" required><button class="btn btn-brown w-100"><?= t('Login') ?></button></form>
<p class="small mt-3 mb-0">New here? <a href="<?= e(url('register.php')) ?>">Create a customer account</a> or <a href="<?= e(url('sell.php')) ?>">apply to sell</a>.</p></div></div></div>
<?php foot();

<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$s = row("SELECT * FROM shops WHERE slug=? AND status='active'", [g('slug')]); if (!$s) throw new HttpError(404);
$items = rows("SELECT p.*, s.shop_name FROM products p JOIN shops s ON s.id=p.shop_id WHERE p.shop_id=? AND p.status IN ('published','out_of_stock') ORDER BY p.id DESC", [$s['id']]);
$rate = row("SELECT AVG(r.rating) a, COUNT(*) n FROM reviews r JOIN products p ON p.id=r.product_id WHERE p.shop_id=? AND r.status='published'", [$s['id']]);
head($s['shop_name']);
?>
<h1 class="h3"><?= e($s['shop_name']) ?></h1>
<p class="text-muted"><?= e($s['location']) ?> <?= $rate['n'] ? ' &middot; ' . stars($rate['a']) . ' (' . (int)$rate['n'] . ')' : '' ?></p>
<p><?= nl2br(e($s['description'])) ?></p>
<div class="row g-3"><?php foreach ($items as $p) product_card($p); if (!$items) echo '<p>No products listed yet.</p>'; ?></div>
<?php foot();

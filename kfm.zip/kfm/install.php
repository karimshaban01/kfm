<?php
/** One-time installer. Open in a browser after creating the database, then DELETE this file. */
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/schema.php';
$done = false; $err = '';
try { $hasTables = (bool)val(is_mysql() ? "SELECT 1 FROM information_schema.tables WHERE table_schema=DATABASE() AND table_name='users'" : "SELECT 1 FROM sqlite_master WHERE name='users'"); $installed = $hasTables && (bool)val("SELECT 1 FROM users WHERE role='admin'"); } catch (Throwable $e) { $installed = false; $hasTables = false; $err = 'Cannot connect to the database: ' . $e->getMessage() . ' - check config.php.'; }
if (!$installed && is_post() && !$err) {
    try {
        $phone = norm_phone($_POST['phone'] ?? ''); $pw = $_POST['password'] ?? '';
        if (trim($_POST['name'] ?? '') === '' || !$phone) throw new Exception('Enter the administrator name and a valid phone number.');
        if (strlen($pw) < 10) throw new Exception('Use an administrator password of at least 10 characters.');
        install_kfm(['name' => trim($_POST['name']), 'phone' => $phone, 'email' => trim($_POST['email'] ?? ''), 'password' => $pw], !empty($_POST['demo']), !$hasTables);
        $done = true;
    } catch (Throwable $e) { $err = $e->getMessage(); }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install KFM</title><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"></head>
<body class="bg-light"><div class="container py-5" style="max-width:520px"><div class="card card-body"><h1 class="h4">Kasulu Furniture Market - installer</h1>
<?php if ($done): ?><div class="alert alert-success">Installed. <strong>Now delete install.php from the server.</strong></div><a class="btn btn-primary" href="index.php">Open the marketplace</a>
<?php elseif ($installed): ?><div class="alert alert-warning">Already installed. Delete install.php from the server.</div>
<?php else: ?><?php if ($err): ?><div class="alert alert-danger"><?= e($err) ?></div><?php endif; ?>
<form method="post"><p class="text-muted small">Create the MySQL database first (see README), then set the credentials in config.php.</p>
<input name="name" class="form-control mb-2" placeholder="Administrator full name" required><input name="phone" class="form-control mb-2" placeholder="Administrator phone (login)" required><input name="email" type="email" class="form-control mb-2" placeholder="Email (optional)">
<input name="password" type="password" class="form-control mb-2" placeholder="Password (10+ characters)" required><div class="form-check mb-3"><input type="checkbox" class="form-check-input" name="demo" value="1" id="d"><label for="d" class="form-check-label">Load demo sellers and products (testing only)</label></div><button class="btn btn-primary w-100">Install</button></form><?php endif; ?></div></div></body></html>

<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = need_role('customer'); $so = (int)g('so'); $pid = (int)g('product');
if (!can_review($u['id'], $pid, $so)) throw new HttpError(403, 'You can only review products from your completed orders, once.');
$prod = row('SELECT product_name, slug FROM products WHERE id=?', [$pid]);
if (is_post()) {
    check_post(); $rating = (int)p('rating'); if ($rating < 1 || $rating > 5) throw new UserError('Choose a rating from 1 to 5.');
    $photo = null; $f = upload_list('photo'); if ($f) $photo = store_image($f[0], 'reviews', 900);
    insert('reviews', ['customer_id' => $u['id'], 'product_id' => $pid, 'seller_order_id' => $so, 'rating' => $rating, 'comment' => p('comment'), 'photo' => $photo, 'status' => 'published', 'created_at' => now()]);
    $sid = val('SELECT seller_id FROM seller_orders WHERE id=?', [$so]); notify($sid, 'New review', $prod['product_name'] . ': ' . $rating . '/5', 'review', $pid);
    flash('Thank you for your review!'); go('product.php?slug=' . $prod['slug']);
}
head('Review');
?>
<div class="row justify-content-center"><div class="col-md-6"><div class="card card-body"><h1 class="h5">Review: <?= e($prod['product_name']) ?></h1>
<form method="post" enctype="multipart/form-data"><?= csrf() ?><label class="form-label">Rating</label><select name="rating" class="form-select mb-2"><?= opts([5 => '5 - Excellent', 4 => '4 - Good', 3 => '3 - Okay', 2 => '2 - Poor', 1 => '1 - Bad'], 5) ?></select>
<label class="form-label">Comment</label><textarea name="comment" rows="4" class="form-control mb-2"></textarea><label class="form-label">Photo (optional)</label><input type="file" name="photo[]" accept="image/*" class="form-control mb-3"><button class="btn btn-brown">Submit review</button></form></div></div></div>
<?php foot();

-- Kasulu Furniture Market - MySQL 8 schema (tables only). Import, then open install.php to create the admin account.
CREATE DATABASE IF NOT EXISTS kasulu_furniture_market CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE kasulu_furniture_market;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(150) NOT NULL, phone VARCHAR(20) NOT NULL, email VARCHAR(150) NULL, password_hash VARCHAR(255) NOT NULL, role VARCHAR(20) NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'active', email_verified_at DATETIME NULL, phone_verified_at DATETIME NULL, last_login_at DATETIME NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (phone), UNIQUE (email)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE seller_profiles (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, business_name VARCHAR(150) NOT NULL, business_description TEXT NULL, business_location VARCHAR(200) NULL, verification_document VARCHAR(200) NULL, approval_status VARCHAR(20) NOT NULL DEFAULT 'pending', approved_by INT NULL, approved_at DATETIME NULL, rejection_reason TEXT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (user_id), FOREIGN KEY (user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE shops (id INT AUTO_INCREMENT PRIMARY KEY, seller_id INT NOT NULL, shop_name VARCHAR(150) NOT NULL, slug VARCHAR(190) NOT NULL, description TEXT NULL, logo VARCHAR(200) NULL, location VARCHAR(200) NULL, phone VARCHAR(20) NULL, status VARCHAR(20) NOT NULL DEFAULT 'pending', created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (slug), FOREIGN KEY (seller_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE categories (id INT AUTO_INCREMENT PRIMARY KEY, parent_id INT NULL, category_name VARCHAR(120) NOT NULL, slug VARCHAR(150) NOT NULL, description TEXT NULL, image VARCHAR(200) NULL, status VARCHAR(20) NOT NULL DEFAULT 'active', created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (slug)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE products (id INT AUTO_INCREMENT PRIMARY KEY, shop_id INT NOT NULL, category_id INT NOT NULL, product_name VARCHAR(190) NOT NULL, slug VARCHAR(220) NOT NULL, description TEXT NULL, price DECIMAL(15,2) NOT NULL, material VARCHAR(100) NULL, colour VARCHAR(60) NULL, finish VARCHAR(100) NULL, length_cm INT NULL, width_cm INT NULL, height_cm INT NULL, product_type VARCHAR(20) NOT NULL DEFAULT 'ready_made', availability VARCHAR(20) NOT NULL DEFAULT 'available', stock_quantity INT NOT NULL DEFAULT 0, production_days INT NULL, customization_allowed TINYINT NOT NULL DEFAULT 0, is_featured TINYINT NOT NULL DEFAULT 0, status VARCHAR(20) NOT NULL DEFAULT 'draft', status_reason TEXT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (slug), FOREIGN KEY (shop_id) REFERENCES shops(id), FOREIGN KEY (category_id) REFERENCES categories(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE product_images (id INT AUTO_INCREMENT PRIMARY KEY, product_id INT NOT NULL, image_path VARCHAR(200) NOT NULL, is_primary TINYINT NOT NULL DEFAULT 0, sort_order INT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, FOREIGN KEY (product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE carts (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, session_token VARCHAR(64) NULL, status VARCHAR(20) NOT NULL DEFAULT 'open', created_at DATETIME NOT NULL, updated_at DATETIME NULL, FOREIGN KEY (user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE cart_items (id INT AUTO_INCREMENT PRIMARY KEY, cart_id INT NOT NULL, product_id INT NOT NULL, quantity INT NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (cart_id, product_id), FOREIGN KEY (cart_id) REFERENCES carts(id), FOREIGN KEY (product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE customer_addresses (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, recipient_name VARCHAR(150) NOT NULL, phone VARCHAR(20) NOT NULL, region VARCHAR(80) NULL, district VARCHAR(80) NULL, ward VARCHAR(80) NULL, street VARCHAR(200) NULL, landmark VARCHAR(200) NULL, delivery_instructions TEXT NULL, is_default TINYINT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, updated_at DATETIME NULL, FOREIGN KEY (user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE orders (id INT AUTO_INCREMENT PRIMARY KEY, order_number VARCHAR(30) NOT NULL, customer_id INT NULL, customer_name VARCHAR(150) NOT NULL, customer_phone VARCHAR(20) NOT NULL, customer_email VARCHAR(150) NULL, merchandise_subtotal DECIMAL(15,2) NOT NULL, delivery_total DECIMAL(15,2) NOT NULL DEFAULT 0, discount_total DECIMAL(15,2) NOT NULL DEFAULT 0, grand_total DECIMAL(15,2) NOT NULL, payment_method VARCHAR(30) NOT NULL, order_status VARCHAR(30) NOT NULL DEFAULT 'pending', created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (order_number), FOREIGN KEY (customer_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE seller_orders (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, seller_id INT NOT NULL, seller_order_number VARCHAR(30) NOT NULL, merchandise_subtotal DECIMAL(15,2) NOT NULL, delivery_fee DECIMAL(15,2) NOT NULL DEFAULT 0, commission_rate DECIMAL(5,2) NOT NULL, commission_amount DECIMAL(15,2) NOT NULL, seller_net_amount DECIMAL(15,2) NOT NULL, fulfilment_method VARCHAR(30) NOT NULL, order_status VARCHAR(30) NOT NULL DEFAULT 'pending', accepted_at DATETIME NULL, completed_at DATETIME NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (seller_order_number), FOREIGN KEY (order_id) REFERENCES orders(id), FOREIGN KEY (seller_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_items (id INT AUTO_INCREMENT PRIMARY KEY, seller_order_id INT NOT NULL, product_id INT NULL, product_name_snapshot VARCHAR(190) NOT NULL, product_description_snapshot TEXT NULL, unit_price DECIMAL(15,2) NOT NULL, quantity INT NOT NULL, line_total DECIMAL(15,2) NOT NULL, created_at DATETIME NOT NULL, FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id), FOREIGN KEY (product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payments (id INT AUTO_INCREMENT PRIMARY KEY, order_id INT NOT NULL, seller_order_id INT NULL, payment_method VARCHAR(30) NOT NULL, provider VARCHAR(40) NULL, amount DECIMAL(15,2) NOT NULL, customer_phone VARCHAR(20) NULL, transaction_reference VARCHAR(80) NULL, payment_status VARCHAR(30) NOT NULL DEFAULT 'pending', verified_by INT NULL, verified_at DATETIME NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (transaction_reference), FOREIGN KEY (order_id) REFERENCES orders(id), FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE commission_ledger (id INT AUTO_INCREMENT PRIMARY KEY, seller_order_id INT NOT NULL, seller_id INT NOT NULL, transaction_type VARCHAR(20) NOT NULL, commission_amount DECIMAL(15,2) NOT NULL, source VARCHAR(10) NOT NULL DEFAULT 'cash', settled_at DATETIME NULL, description VARCHAR(255) NULL, created_at DATETIME NOT NULL, FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id), FOREIGN KEY (seller_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE seller_payouts (id INT AUTO_INCREMENT PRIMARY KEY, seller_id INT NOT NULL, amount DECIMAL(15,2) NOT NULL, payment_method VARCHAR(30) NOT NULL, payment_reference VARCHAR(100) NULL, payout_status VARCHAR(20) NOT NULL DEFAULT 'paid', processed_by INT NULL, processed_at DATETIME NULL, created_at DATETIME NOT NULL, FOREIGN KEY (seller_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE deliveries (id INT AUTO_INCREMENT PRIMARY KEY, seller_order_id INT NOT NULL, recipient_name VARCHAR(150) NOT NULL, recipient_phone VARCHAR(20) NOT NULL, delivery_address TEXT NULL, delivery_fee DECIMAL(15,2) NOT NULL DEFAULT 0, delivery_person VARCHAR(150) NULL, tracking_reference VARCHAR(60) NULL, delivery_status VARCHAR(30) NOT NULL DEFAULT 'pending', dispatched_at DATETIME NULL, delivered_at DATETIME NULL, proof_of_delivery VARCHAR(200) NULL, proof_note TEXT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, UNIQUE (seller_order_id), FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE custom_requests (id INT AUTO_INCREMENT PRIMARY KEY, customer_id INT NOT NULL, customer_name VARCHAR(150) NOT NULL, customer_phone VARCHAR(20) NOT NULL, furniture_type VARCHAR(120) NOT NULL, description TEXT NOT NULL, dimensions VARCHAR(150) NULL, material VARCHAR(100) NULL, colour VARCHAR(60) NULL, budget DECIMAL(15,2) NULL, required_date DATE NULL, request_status VARCHAR(20) NOT NULL DEFAULT 'open', created_at DATETIME NOT NULL, updated_at DATETIME NULL, FOREIGN KEY (customer_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE custom_request_images (id INT AUTO_INCREMENT PRIMARY KEY, custom_request_id INT NOT NULL, image_path VARCHAR(200) NOT NULL, created_at DATETIME NOT NULL, FOREIGN KEY (custom_request_id) REFERENCES custom_requests(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE quotations (id INT AUTO_INCREMENT PRIMARY KEY, custom_request_id INT NOT NULL, seller_id INT NOT NULL, quoted_price DECIMAL(15,2) NOT NULL, deposit_amount DECIMAL(15,2) NOT NULL DEFAULT 0, production_days INT NULL, description TEXT NULL, expiry_date DATE NULL, quotation_status VARCHAR(20) NOT NULL DEFAULT 'sent', order_id INT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NULL, FOREIGN KEY (custom_request_id) REFERENCES custom_requests(id), FOREIGN KEY (seller_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reviews (id INT AUTO_INCREMENT PRIMARY KEY, customer_id INT NOT NULL, product_id INT NOT NULL, seller_order_id INT NOT NULL, rating INT NOT NULL, comment TEXT NULL, photo VARCHAR(200) NULL, status VARCHAR(20) NOT NULL DEFAULT 'published', created_at DATETIME NOT NULL, UNIQUE (customer_id, product_id, seller_order_id), FOREIGN KEY (customer_id) REFERENCES users(id), FOREIGN KEY (product_id) REFERENCES products(id), FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE notifications (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, title VARCHAR(190) NOT NULL, message TEXT NULL, notification_type VARCHAR(40) NULL, related_id INT NULL, is_read TINYINT NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, FOREIGN KEY (user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE order_status_history (id INT AUTO_INCREMENT PRIMARY KEY, seller_order_id INT NOT NULL, previous_status VARCHAR(30) NULL, new_status VARCHAR(30) NOT NULL, changed_by INT NULL, notes TEXT NULL, created_at DATETIME NOT NULL, FOREIGN KEY (seller_order_id) REFERENCES seller_orders(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE platform_settings (id INT AUTO_INCREMENT PRIMARY KEY, setting_key VARCHAR(80) NOT NULL, setting_value TEXT NULL, updated_at DATETIME NULL, UNIQUE (setting_key)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_logs (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NULL, action VARCHAR(100) NOT NULL, entity_type VARCHAR(60) NULL, entity_id INT NULL, details TEXT NULL, ip_address VARCHAR(45) NULL, created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE login_attempts (id INT AUTO_INCREMENT PRIMARY KEY, ident VARCHAR(150) NOT NULL, ip_address VARCHAR(45) NULL, success TINYINT NOT NULL, created_at DATETIME NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX i_products_status ON products (status, category_id);

CREATE INDEX i_so_order ON seller_orders (order_id);

CREATE INDEX i_so_seller ON seller_orders (seller_id, order_status);

CREATE INDEX i_notif_user ON notifications (user_id, is_read);

CREATE INDEX i_attempts ON login_attempts (ident, created_at);

SET FOREIGN_KEY_CHECKS=1;

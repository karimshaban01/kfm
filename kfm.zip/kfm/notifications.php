<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = need_role(['admin', 'seller', 'customer']);
if (is_post()) { check_post(); q('UPDATE notifications SET is_read=1 WHERE user_id=?', [$u['id']]); go('notifications.php'); }
$list = rows('SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 60', [$u['id']]);
head('Alerts', $u['role'] === 'customer' ? 'public' : $u['role']);
?>
<div class="d-flex justify-content-between"><h1 class="h3">Notifications</h1><form method="post"><?= csrf() ?><button class="btn btn-sm btn-outline-secondary">Mark all read</button></form></div>
<?php foreach ($list as $n): ?><div class="border-bottom py-2 <?= $n['is_read'] ? 'text-muted' : 'fw-semibold' ?>"><?= e($n['title']) ?><div class="small fw-normal"><?= e($n['message']) ?> <span class="text-muted">- <?= e($n['created_at']) ?></span></div></div><?php endforeach; if (!$list) echo '<p class="text-muted">Nothing yet.</p>'; ?>
<?php foot();

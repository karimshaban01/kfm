<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = need_role('customer');
$o = row('SELECT * FROM orders WHERE id=? AND customer_id=?', [(int)g('id'), $u['id']]); if (!$o) throw new HttpError(404);
if (is_post()) {
    check_post(); $do = p('do');
    if ($do === 'ref') {
        $ref = strtoupper(p('ref')); if (strlen($ref) < 4) throw new UserError('Enter the transaction reference from your mobile money message.');
        if (val('SELECT 1 FROM payments WHERE transaction_reference=? AND order_id<>?', [$ref, $o['id']])) throw new UserError('That reference has already been used on another order.');
        $pay = row("SELECT * FROM payments WHERE order_id=? AND seller_order_id IS NULL AND payment_method='mobile_money' AND payment_status IN ('pending','awaiting_verification')", [$o['id']]);
        if (!$pay) throw new UserError('No payment is waiting for a reference.');
        upd('payments', $pay['id'], ['transaction_reference' => $ref, 'payment_status' => 'awaiting_verification', 'provider' => p('provider') ?: $pay['provider']]);
        notify_admins('Payment to verify: ' . $o['order_number'], 'Reference ' . $ref, 'payment', $o['id']); flash('Reference sent. The marketplace will verify your payment.');
    } elseif (in_array($do, ['cancel', 'received'], true)) {
        $so = so_get((int)p('so')); if (!$so || (int)$so['order_id'] !== (int)$o['id']) throw new HttpError(404);
        so_transition($so['id'], $do === 'cancel' ? 'cancelled' : 'completed', $u, $do === 'cancel' ? 'Cancelled by customer' : 'Customer confirmed receipt');
        flash($do === 'cancel' ? 'Order cancelled.' : 'Thank you! You can now review your items.');
    }
    go('order.php?id=' . $o['id']);
}
$sos = rows('SELECT * FROM seller_orders WHERE order_id=? ORDER BY id', [$o['id']]);
$mm = row("SELECT * FROM payments WHERE order_id=? AND seller_order_id IS NULL AND payment_method='mobile_money'", [$o['id']]);
head($o['order_number']);
?>
<?php if (g('new')): ?><div class="alert alert-success">Thank you! Your order <strong><?= e($o['order_number']) ?></strong> has been placed.</div><?php endif; ?>
<h1 class="h3"><?= e($o['order_number']) ?> <?= badge($o['order_status']) ?></h1>
<p class="text-muted">Placed <?= e($o['created_at']) ?> &middot; Payment: <?= label($o['payment_method']) ?> &middot; Total <strong><?= money($o['grand_total']) ?></strong> (merchandise <?= money($o['merchandise_subtotal']) ?> + delivery <?= money($o['delivery_total']) ?>)</p>
<?php if ($mm): ?><div class="card card-body mb-3"><strong>Mobile money payment:</strong> <?= badge($mm['payment_status']) ?> <?= $mm['transaction_reference'] ? '<span>Ref ' . e($mm['transaction_reference']) . '</span>' : '' ?>
<?php if (in_array($mm['payment_status'], ['pending', 'awaiting_verification'], true)): ?><div class="small my-2" style="white-space:pre-line"><?= e(setting('mobile_money_instructions')) ?></div>
<form method="post" class="row g-2"><?= csrf() ?><input type="hidden" name="do" value="ref"><div class="col-md-4"><select name="provider" class="form-select"><?= opts(['M-Pesa' => 'M-Pesa', 'Airtel Money' => 'Airtel Money', 'Mixx by Yas' => 'Mixx by Yas', 'HaloPesa' => 'HaloPesa'], $mm['provider']) ?></select></div><div class="col-md-5"><input name="ref" class="form-control" placeholder="Transaction reference" required></div><div class="col-md-3"><button class="btn btn-brown w-100"><?= $mm['transaction_reference'] ? 'Update reference' : 'Submit reference' ?></button></div></form><?php endif; ?></div><?php endif; ?>
<?php foreach ($sos as $so): $items = rows('SELECT * FROM order_items WHERE seller_order_id=?', [$so['id']]); $shop = seller_shop($so['seller_id']); $dl = row('SELECT * FROM deliveries WHERE seller_order_id=?', [$so['id']]); $hist = rows('SELECT * FROM order_status_history WHERE seller_order_id=? ORDER BY id', [$so['id']]); ?>
<div class="card mb-3"><div class="card-header d-flex flex-wrap justify-content-between gap-2"><span><strong><?= e($so['seller_order_number']) ?></strong> from <?= e($shop['shop_name'] ?? 'Seller') ?></span><span><?= badge($so['order_status']) ?></span></div>
<div class="table-responsive"><table class="table table-sm mb-0"><?php foreach ($items as $i): ?><tr><td><?= e($i['product_name_snapshot']) ?></td><td>x<?= (int)$i['quantity'] ?></td><td class="text-end"><?= money($i['line_total']) ?></td>
<td class="text-end"><?php if ($i['product_id'] && can_review($u['id'], $i['product_id'], $so['id'])): ?><a class="btn btn-sm btn-outline-warning" href="<?= e(url('review.php?so=' . $so['id'] . '&product=' . $i['product_id'])) ?>">Review</a><?php endif; ?></td></tr><?php endforeach; ?></table></div>
<div class="card-body small"><?= $dl ? 'Delivery to ' . e($dl['recipient_name']) . ', ' . e($dl['delivery_address']) . ' - ' . badge($dl['delivery_status']) . ' (' . money($dl['delivery_fee']) . ')' : 'Customer collection' . ($shop ? ' at ' . e($shop['location']) . ($shop['phone'] ? ', ' . e($shop['phone']) : '') : '') ?>
<details class="mt-2"><summary>Status history</summary><?php foreach ($hist as $h) echo '<div>' . e($h['created_at']) . ' - ' . label($h['new_status']) . ($h['notes'] ? ' (' . e($h['notes']) . ')' : '') . '</div>'; ?></details>
<div class="mt-2 d-flex gap-2"><?php if ($so['order_status'] === 'pending'): ?><form method="post" onsubmit="return confirm('Cancel this seller order?')"><?= csrf() ?><input type="hidden" name="do" value="cancel"><input type="hidden" name="so" value="<?= $so['id'] ?>"><button class="btn btn-sm btn-outline-danger">Cancel</button></form><?php endif; ?>
<?php if ($so['order_status'] === 'delivered'): ?><form method="post"><?= csrf() ?><input type="hidden" name="do" value="received"><input type="hidden" name="so" value="<?= $so['id'] ?>"><button class="btn btn-sm btn-success">I received my order</button></form><?php endif; ?></div></div></div>
<?php endforeach; ?>
<?php foot();

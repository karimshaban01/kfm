<?php
// Admin-only access to private seller verification documents.
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
need_role('admin');
$n = basename(g('f')); $path = ROOT . '/private/docs/' . $n;
if (!preg_match('/^[a-f0-9]{24}\.(jpg|png|pdf)$/', $n) || !is_file($path)) throw new HttpError(404);
$types = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'pdf' => 'application/pdf'];
header('Content-Type: ' . $types[pathinfo($n, PATHINFO_EXTENSION)]); header('X-Content-Type-Options: nosniff'); header('Content-Disposition: inline; filename="' . $n . '"'); readfile($path);

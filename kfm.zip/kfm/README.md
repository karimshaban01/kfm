# Kasulu Furniture Market (KFM)

A simple multi-vendor marketplace for locally made wooden furniture in Kasulu, Kigoma.
Plain PHP 8.2+ (no framework, no Composer), PDO, MySQL 8, Bootstrap 5 (CDN). Currency TZS, timezone Africa/Dar_es_Salaam.

Each seller has an independent shop and dashboard. A customer checks out once; the system splits the checkout into one
`seller_orders` record per seller (with `order_items`), each managed only by its own seller.

## Requirements
Apache 2.4 with `mod_rewrite` not needed, but `AllowOverride All` is **required** (the `.htaccess` files protect private folders);
PHP 8.2+ with `pdo_mysql`, `gd`, `fileinfo`, `mbstring`; MySQL 8 (or MariaDB 10.6+).

## Install on Ubuntu / Apache2
```bash
sudo apt install apache2 php libapache2-mod-php php-mysql php-gd php-mbstring mysql-server
sudo cp -r kfm /var/www/html/kfm            # or make it the site root
sudo chown -R www-data:www-data /var/www/html/kfm/uploads /var/www/html/kfm/private
sudo a2enmod headers && sudo systemctl restart apache2
```
In the Apache site config for the folder set `AllowOverride All`, then reload Apache.

Create the database and a user (do **not** use root in production):
```sql
CREATE DATABASE kasulu_furniture_market CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'kfm'@'localhost' IDENTIFIED BY 'a-strong-password';
GRANT ALL ON kasulu_furniture_market.* TO 'kfm'@'localhost';
```
Edit `config.php` (host, name, user, pass).

Then open `http://your-server/kfm/install.php`, enter the administrator details and (optionally) tick "demo data".
The installer creates the tables, default settings and the 13 categories. (You may instead import `database.sql` first;
the installer then only creates the admin, settings and categories.)

**Delete `install.php` when finished.** Then log in at `/login.php` with the admin phone and password.

Demo accounts (only if you ticked demo data - remove them before going live): sellers `0712000001`, `0712000002`,
pending seller `0712000003`, customer `0755000001`, all with password `Demo@12345`.

## Before going live
1. Serve over **HTTPS** (e.g. Let's Encrypt `certbot --apache`); session cookies become `Secure` automatically.
2. Admin > Settings: set commission rate, delivery fee, contact details and the **mobile money number/instructions**.
3. Check that `https://your-site/config.php`, `/includes/app.php`, `/private/` and `/uploads/x.php` are refused (403/404).
4. Daily backup, e.g. cron: `mysqldump -u kfm -p kasulu_furniture_market | gzip > /backup/kfm-$(date +%F).sql.gz`, and copy `uploads/` and `private/docs/`.
5. Set `debug` to `false` in `config.php` (the default) and watch the Apache/PHP error log.

## What is where
- `index.php shop.php product.php shop_view.php cart.php checkout.php track.php` - public marketplace.
- `login.php register.php account.php order.php request.php custom_request.php review.php notifications.php` - customer.
- `sell.php` + `seller/` - seller application, shop, products, orders, quotations, earnings.
- `admin/` - sellers, products, orders, payments (mobile money verification), finance (commission, cash settlement, payouts, CSV export), categories, users, settings, reviews, audit log.
- `includes/app.php` - all business logic (checkout split, stock, status workflow, payments, commission ledger, refunds, balances).
- `includes/schema.php` / `database.sql` - the 24 spec tables + `login_attempts`.
- `includes/lang_sw.php` - Kiswahili dictionary (a starter set; extend it). Language toggle is in the navbar.
- `tests/` - `logic.php` (CLI rule checks) and `e2e.py` (HTTP test) - blocked from the web by `.htaccess`; delete the folder on production if you like.

## Business rules as implemented
- **Commission** = merchandise subtotal x rate. Delivery is excluded. The rate is copied onto every seller order when it is placed; changing it later only affects new orders.
- Commission is recognised (ledger row) **only when the seller order is `completed`**. A refund adds a negative `reversal` row.
- **Cash orders** (COD / collection): the seller holds the money, so the commission appears as "owed" until the admin presses *Mark cash settled* in Finance.
- **Mobile money**: customer pays the marketplace and enters the transaction reference; an admin verifies it (a reference alone is never proof). Until verified, the seller order stays `awaiting_payment` and cannot go to processing/completed. The seller's net earnings are then payable; admin records payouts (limited to the payable balance).
- Stock is reduced atomically at checkout (`UPDATE ... WHERE stock_quantity >= qty`), inside a transaction, so two buyers cannot oversell the last item. Rejection/cancellation returns stock.
- Prices, names and descriptions are snapshotted in `order_items`; nothing money-related is taken from the browser.
- Parent order status is derived from its seller orders (pending / confirmed / partially_completed / completed / cancelled).

## Security notes
CSRF token on every POST, `password_hash`, prepared statements, output escaping, session regeneration, DB-backed login rate limit (8 failures / 15 min per phone or IP), audit log of sensitive actions, uploaded images re-encoded with GD, seller documents stored outside public access and served only to admins, `uploads/` blocks script execution, CSV export neutralises spreadsheet formulas.

## Not included / simplified (be aware)
- **Password reset by email/SMS** - not built; an admin can reset a password in Admin > Users.
- **Complaints module**, **SMS/WhatsApp** notifications, online mobile-money APIs (all payments are verified manually) - not built. Notifications are in-app only.
- **Guest checkout** - checkout requires a customer account (the cart is kept through login/registration). Guests can track an order with order number + phone.
- **Custom furniture deposit** is shown on the quotation but not collected separately: accepting a quotation creates a normal order for the full quoted price.
- Architecture is flat PHP pages with shared includes, not MVC (you asked for "simple").
- **Marketplace-arranged delivery** is a fulfilment label in the data model; the checkout uses one flat per-seller delivery fee from settings.
- Tested with PHP 8.x on **SQLite** (same SQL, a dual-driver layer) - 52 rule checks and 86 HTTP checks pass. It has **not** been run against a real MySQL server or Apache here; do a test checkout on your server after install.

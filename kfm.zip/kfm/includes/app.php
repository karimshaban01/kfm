<?php
/** KFM core: database, helpers, auth, cart, checkout, order workflow, payments, commission. PHP 8.2+. */
define('ROOT', dirname(__DIR__));
$CFG = require ROOT . '/config.php';
date_default_timezone_set('Africa/Dar_es_Salaam');
ini_set('display_errors', !empty($CFG['debug']) ? '1' : '0');
ini_set('log_errors', '1');
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]);
    session_start();
}
class UserError extends Exception {}
class HttpError extends Exception { public $status; function __construct($s, $m = '') { parent::__construct($m); $this->status = $s; } }

/* ---------- database ---------- */
function db_driver() { global $CFG; $e = getenv('KFM_DRIVER'); return $e ? $e : $CFG['db']['driver']; }
function is_mysql() { return db_driver() === 'mysql'; }
function db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    global $CFG; $c = $CFG['db'];
    if (!is_mysql()) {
        $path = getenv('KFM_SQLITE') ? getenv('KFM_SQLITE') : $c['sqlite'];
        $pdo = new PDO('sqlite:' . $path);
        $pdo->exec('PRAGMA foreign_keys=ON'); $pdo->exec('PRAGMA busy_timeout=8000');
    } else {
        $pdo = new PDO('mysql:host=' . $c['host'] . ';dbname=' . $c['name'] . ';charset=utf8mb4', $c['user'], $c['pass']);
        $pdo->exec("SET time_zone='+03:00'");
    }
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    return $pdo;
}
function q($sql, $p = []) { $s = db()->prepare($sql); $s->execute(array_values($p)); return $s; }
function rows($sql, $p = []) { return q($sql, $p)->fetchAll(); }
function row($sql, $p = []) { $r = q($sql, $p)->fetch(); return $r ? $r : null; }
function val($sql, $p = []) { $v = q($sql, $p)->fetchColumn(); return $v === false ? null : $v; }
function insert($t, $d) { q("INSERT INTO $t (" . implode(',', array_keys($d)) . ') VALUES (' . implode(',', array_fill(0, count($d), '?')) . ')', array_values($d)); return (int)db()->lastInsertId(); }
function upd($t, $id, $d) {
    $noUpdated = ['order_items', 'product_images', 'reviews', 'notifications', 'order_status_history', 'audit_logs', 'login_attempts', 'commission_ledger', 'seller_payouts', 'custom_request_images'];
    if (!in_array($t, $noUpdated, true)) { $d['updated_at'] = now(); }
    $set = []; foreach ($d as $k => $v) { $set[] = "$k=?"; }
    $p = array_values($d); $p[] = $id; q("UPDATE $t SET " . implode(',', $set) . ' WHERE id=?', $p);
}
function tx($fn) {
    $db = db(); if ($db->inTransaction()) return $fn();
    $db->beginTransaction();
    try { $r = $fn(); $db->commit(); return $r; } catch (Throwable $e) { if ($db->inTransaction()) $db->rollBack(); throw $e; }
}
function paginate($sql, $params, $per = 12) {
    $total = (int)val("SELECT COUNT(*) FROM ($sql) cnt", $params);
    $pages = max(1, (int)ceil($total / $per)); $page = min(max(1, (int)($_GET['page'] ?? 1)), $pages);
    return [rows($sql . ' LIMIT ' . (int)$per . ' OFFSET ' . (int)(($page - 1) * $per), $params), $page, $pages, $total];
}

/* ---------- small helpers ---------- */
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function money($n) { return 'TZS ' . number_format((float)$n, 0); }
function now() { return date('Y-m-d H:i:s'); }
function ip() { return $_SERVER['REMOTE_ADDR'] ?? 'cli'; }
function base() { static $b = null; if ($b === null) { $d = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php')); $b = rtrim(preg_replace('#/(admin|seller)$#', '', $d), '/'); } return $b; }
function url($p = '') { return base() . '/' . ltrim($p, '/'); }
function go($p) { header('Location: ' . (preg_match('#^https?://#', $p) ? $p : url($p))); exit; }
function flash($m, $t = 'success') { $_SESSION['flash'][] = [$t, $m]; }
function csrf() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16)); return '<input type="hidden" name="_csrf" value="' . $_SESSION['csrf'] . '">'; }
function is_post() { return ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'; }
function check_post() {
    if (!is_post()) return false;
    if (empty($_POST['_csrf']) || !hash_equals($_SESSION['csrf'] ?? '', $_POST['_csrf'])) throw new HttpError(400, 'Your session expired. Go back, refresh the page and try again.');
    return true;
}
function p($k, $d = '') { return isset($_POST[$k]) && is_string($_POST[$k]) ? trim($_POST[$k]) : $d; }
function g($k, $d = '') { return isset($_GET[$k]) && is_string($_GET[$k]) ? trim($_GET[$k]) : $d; }
function slugify($s) { $s = strtolower(trim(preg_replace('/[^A-Za-z0-9]+/', '-', $s), '-')); return $s !== '' ? $s : 'item'; }
function unique_slug($table, $col, $base, $exceptId = 0) { $s = slugify($base); $i = 1; $c = $s; while (val("SELECT 1 FROM $table WHERE $col=? AND id<>?", [$c, $exceptId])) { $c = $s . '-' . (++$i); } return $c; }
function norm_phone($x) { $d = preg_replace('/[^0-9]/', '', (string)$x); if (strlen($d) === 10 && $d[0] === '0') $d = '255' . substr($d, 1); elseif (strlen($d) === 9) $d = '255' . $d; return preg_match('/^255[0-9]{9}$/', $d) ? $d : null; }
function dec($v) { return round((float)$v, 2); }
function opts($list, $sel = null, $blank = null) { $h = $blank !== null ? '<option value="">' . e($blank) . '</option>' : ''; foreach ($list as $k => $v) { $h .= '<option value="' . e($k) . '"' . ((string)$k === (string)$sel ? ' selected' : '') . '>' . e($v) . '</option>'; } return $h; }
function label($s) { return ucwords(str_replace('_', ' ', (string)$s)); }
function badge($s) { $c = ['completed' => 'success', 'delivered' => 'success', 'successful' => 'success', 'approved' => 'success', 'published' => 'success', 'active' => 'success', 'paid' => 'success', 'rejected' => 'danger', 'cancelled' => 'danger', 'failed' => 'danger', 'suspended' => 'danger', 'refunded' => 'danger', 'pending' => 'warning', 'awaiting_verification' => 'warning', 'awaiting_payment' => 'warning', 'draft' => 'secondary', 'out_of_stock' => 'secondary']; return '<span class="badge text-bg-' . (isset($c[$s]) ? $c[$s] : 'info') . '">' . e(label($s)) . '</span>'; }
function setting($k, $d = '') { if (!isset($GLOBALS['_kfm_settings'])) { $GLOBALS['_kfm_settings'] = []; foreach (rows('SELECT setting_key k, setting_value v FROM platform_settings') as $r) $GLOBALS['_kfm_settings'][$r['k']] = $r['v']; } return array_key_exists($k, $GLOBALS['_kfm_settings']) ? $GLOBALS['_kfm_settings'][$k] : $d; }
function set_setting($k, $v) { if (val('SELECT 1 FROM platform_settings WHERE setting_key=?', [$k])) q('UPDATE platform_settings SET setting_value=?, updated_at=? WHERE setting_key=?', [$v, now(), $k]); else insert('platform_settings', ['setting_key' => $k, 'setting_value' => $v, 'updated_at' => now()]); unset($GLOBALS['_kfm_settings']); }
function audit($action, $entity = null, $id = null, $details = '') { $u = user(); insert('audit_logs', ['user_id' => $u ? $u['id'] : null, 'action' => $action, 'entity_type' => $entity, 'entity_id' => $id, 'details' => is_array($details) ? json_encode($details) : (string)$details, 'ip_address' => ip(), 'created_at' => now()]); }
function notify($uid, $title, $msg = '', $type = null, $rel = null) { if ($uid) insert('notifications', ['user_id' => $uid, 'title' => $title, 'message' => $msg, 'notification_type' => $type, 'related_id' => $rel, 'created_at' => now()]); }
function notify_admins($title, $msg = '', $type = null, $rel = null) { foreach (rows("SELECT id FROM users WHERE role='admin' AND status='active'") as $a) notify($a['id'], $title, $msg, $type, $rel); }

/* ---------- language (English default, Kiswahili-ready) ---------- */
function t($s) {
    static $sw = null;
    if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'sw'], true)) $_SESSION['lang'] = $_GET['lang'];
    if (($_SESSION['lang'] ?? 'en') !== 'sw') return $s;
    if ($sw === null) $sw = require ROOT . '/includes/lang_sw.php';
    return $sw[$s] ?? $s;
}

/* ---------- uploads: images are re-encoded with GD (strips hidden payloads) ---------- */
function upload_list($field) {
    if (empty($_FILES[$field])) return [];
    $f = $_FILES[$field]; $out = [];
    if (is_array($f['name'])) { foreach ($f['name'] as $i => $n) { if ($f['error'][$i] !== UPLOAD_ERR_NO_FILE) $out[] = ['name' => $n, 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]]; } }
    elseif ($f['error'] !== UPLOAD_ERR_NO_FILE) $out[] = $f;
    return $out;
}
function store_image($file, $subdir, $maxW = 1200) {
    if ($file['error'] !== UPLOAD_ERR_OK) throw new UserError('Image upload failed. Try a smaller file.');
    if ($file['size'] > 6 * 1048576) throw new UserError('Each image must be under 6 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp'], true) || !@getimagesize($file['tmp_name'])) throw new UserError('Only JPG, PNG or WebP images are allowed.');
    $src = @imagecreatefromstring(file_get_contents($file['tmp_name']));
    if (!$src) throw new UserError('That image could not be read.');
    $w = imagesx($src); $h = imagesy($src); $nw = min($w, $maxW); $nh = (int)round($h * $nw / $w);
    $dst = imagecreatetruecolor($nw, $nh); imagefill($dst, 0, 0, imagecolorallocate($dst, 255, 255, 255)); imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
    $dir = ROOT . '/uploads/' . $subdir; if (!is_dir($dir)) mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(12)) . '.jpg'; imagejpeg($dst, $dir . '/' . $name, 82);
    return $name;
}
function store_private_doc($file) {
    if ($file['error'] !== UPLOAD_ERR_OK) throw new UserError('Document upload failed.');
    if ($file['size'] > 6 * 1048576) throw new UserError('Document must be under 6 MB.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']); $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'application/pdf' => 'pdf'];
    if (!isset($ext[$mime])) throw new UserError('Documents must be JPG, PNG or PDF.');
    $name = bin2hex(random_bytes(12)) . '.' . $ext[$mime];
    if (!move_uploaded_file($file['tmp_name'], ROOT . '/private/docs/' . $name)) throw new UserError('Could not store the document.');
    return $name;
}
function img_url($sub, $name) { return $name ? url('uploads/' . $sub . '/' . $name) : null; }
function product_image($pid) { return val('SELECT image_path FROM product_images WHERE product_id=? ORDER BY is_primary DESC, sort_order, id LIMIT 1', [$pid]); }

/* ---------- authentication ---------- */
function user() {
    static $u = false;
    if ($u === false || (isset($_SESSION['uid']) && (!$u || (int)$u['id'] !== (int)$_SESSION['uid']))) {
        $u = !empty($_SESSION['uid']) ? row("SELECT * FROM users WHERE id=? AND status='active'", [$_SESSION['uid']]) : null;
        if (!$u) unset($_SESSION['uid']);
    }
    return $u ? $u : null;
}
function need_role($roles) {
    $u = user();
    if (!$u) { $_SESSION['next'] = $_SERVER['REQUEST_URI'] ?? ''; go('login.php'); }
    if (!in_array($u['role'], (array)$roles, true)) throw new HttpError(403, 'You do not have access to this page.');
    return $u;
}
function login_blocked($ident) { return (int)val('SELECT COUNT(*) FROM login_attempts WHERE success=0 AND created_at>? AND (ident=? OR ip_address=?)', [date('Y-m-d H:i:s', time() - 900), $ident, ip()]) >= 8; }
function do_login($ident, $pw) {
    $ident = trim($ident);
    if (login_blocked($ident)) throw new UserError('Too many failed attempts. Please wait 15 minutes.');
    $ph = norm_phone($ident);
    $u = $ph ? row('SELECT * FROM users WHERE phone=?', [$ph]) : row('SELECT * FROM users WHERE email=?', [strtolower($ident)]);
    $ok = $u && password_verify($pw, $u['password_hash']);
    insert('login_attempts', ['ident' => $ident, 'ip_address' => ip(), 'success' => $ok ? 1 : 0, 'created_at' => now()]);
    if (!$ok) throw new UserError('Incorrect phone/email or password.');
    if ($u['status'] !== 'active') throw new UserError('This account is ' . $u['status'] . '. Please contact the marketplace.');
    session_regenerate_id(true);
    $_SESSION['uid'] = $u['id']; upd('users', $u['id'], ['last_login_at' => now()]);
    merge_guest_cart($u['id']); audit('login', 'user', $u['id']);
    return $u;
}
function home_for($u) { return $u['role'] === 'admin' ? 'admin/index.php' : ($u['role'] === 'seller' ? 'seller/index.php' : 'account.php'); }
function seller_profile($uid) { return row('SELECT * FROM seller_profiles WHERE user_id=?', [$uid]); }
function seller_shop($uid) { return row('SELECT * FROM shops WHERE seller_id=? ORDER BY id LIMIT 1', [$uid]); }
function seller_approved($uid) { $p = seller_profile($uid); return $p && $p['approval_status'] === 'approved'; }

/* ---------- cart ---------- */
function cart_token() {
    if (empty($_COOKIE['kfm_cart']) || !preg_match('/^[a-f0-9]{32}$/', $_COOKIE['kfm_cart'])) { $t = bin2hex(random_bytes(16)); setcookie('kfm_cart', $t, ['expires' => time() + 86400 * 30, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax', 'secure' => !empty($_SERVER['HTTPS'])]); $_COOKIE['kfm_cart'] = $t; }
    return $_COOKIE['kfm_cart'];
}
function cart_id($create = true) {
    $u = user();
    $c = $u ? row("SELECT id FROM carts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", [$u['id']]) : (!empty($_COOKIE['kfm_cart']) ? row("SELECT id FROM carts WHERE session_token=? AND status='open' AND user_id IS NULL", [$_COOKIE['kfm_cart']]) : null);
    if ($c) return (int)$c['id'];
    if (!$create) return 0;
    return insert('carts', ['user_id' => $u ? $u['id'] : null, 'session_token' => $u ? null : cart_token(), 'status' => 'open', 'created_at' => now()]);
}
function merge_guest_cart($uid) {
    if (empty($_COOKIE['kfm_cart'])) return;
    $g = row("SELECT id FROM carts WHERE session_token=? AND status='open' AND user_id IS NULL", [$_COOKIE['kfm_cart']]); if (!$g) return;
    $mine = row("SELECT id FROM carts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", [$uid]);
    if (!$mine) { upd('carts', $g['id'], ['user_id' => $uid, 'session_token' => null]); return; }
    foreach (rows('SELECT * FROM cart_items WHERE cart_id=?', [$g['id']]) as $i) { cart_add($mine['id'], $i['product_id'], $i['quantity']); }
    q('DELETE FROM cart_items WHERE cart_id=?', [$g['id']]); upd('carts', $g['id'], ['status' => 'merged']);
}
function cart_add($cid, $pid, $qty) {
    $ex = row('SELECT * FROM cart_items WHERE cart_id=? AND product_id=?', [$cid, $pid]);
    if ($ex) upd('cart_items', $ex['id'], ['quantity' => min(999, $ex['quantity'] + $qty)]); else insert('cart_items', ['cart_id' => $cid, 'product_id' => $pid, 'quantity' => min(999, $qty), 'created_at' => now()]);
}
function buyable_where() { return "p.status IN ('published','out_of_stock') AND s.status='active' AND u.status='active'"; }
function cart_lines() {
    $cid = cart_id(false); if (!$cid) return [];
    $out = [];
    foreach (rows("SELECT ci.quantity, p.*, s.shop_name, s.seller_id, s.status shop_status, u.status seller_status FROM cart_items ci JOIN products p ON p.id=ci.product_id JOIN shops s ON s.id=p.shop_id JOIN users u ON u.id=s.seller_id WHERE ci.cart_id=? ORDER BY s.id, p.id", [$cid]) as $r) {
        $r['buyable'] = $r['status'] === 'published' && $r['availability'] === 'available' && $r['shop_status'] === 'active' && $r['seller_status'] === 'active' && ($r['product_type'] !== 'ready_made' || $r['stock_quantity'] > 0);
        $r['stock_ok'] = $r['product_type'] !== 'ready_made' || $r['quantity'] <= $r['stock_quantity'];
        $r['line'] = dec($r['price'] * $r['quantity']); $out[] = $r;
    }
    return $out;
}
function cart_count() { $c = cart_id(false); return $c ? (int)val('SELECT COALESCE(SUM(quantity),0) FROM cart_items WHERE cart_id=?', [$c]) : 0; }

/* ---------- stock (atomic) ---------- */
function stock_take($pid, $qty) { // returns false when not enough stock
    $n = q("UPDATE products SET stock_quantity=stock_quantity-? WHERE id=? AND product_type='ready_made' AND stock_quantity>=?", [$qty, $pid, $qty])->rowCount();
    if ($n) sync_stock_status($pid);
    return (bool)$n;
}
function stock_give($pid, $qty) { q("UPDATE products SET stock_quantity=stock_quantity+? WHERE id=? AND product_type='ready_made'", [$qty, $pid]); sync_stock_status($pid); }
function sync_stock_status($pid) {
    $p = row('SELECT * FROM products WHERE id=?', [$pid]); if (!$p || $p['product_type'] !== 'ready_made') return;
    if ($p['stock_quantity'] <= 0 && $p['status'] === 'published') upd('products', $pid, ['status' => 'out_of_stock']);
    elseif ($p['stock_quantity'] > 0 && $p['status'] === 'out_of_stock') upd('products', $pid, ['status' => 'published']);
}

/* ---------- checkout: one parent order + one seller order per seller ---------- */
function fulfil_methods() { return ['seller_delivery' => 'Seller delivery', 'marketplace_delivery' => 'Marketplace-arranged delivery', 'collection' => 'Customer collection']; }
function create_order_record($cust, $name, $phone, $email, $groups, $payMethod, $fulfil, $addr, $payInfo, $feeEach, $note = '') {
    // $groups: sellerId => list of ['product'=>row|null,'name','desc','price','qty']
    $rate = (float)setting('commission_rate', 5);
    $sub = 0; foreach ($groups as $lines) foreach ($lines as $l) $sub += dec($l['price'] * $l['qty']);
    $delivery = $fulfil === 'delivery' ? dec($feeEach * count($groups)) : 0;
    $oid = insert('orders', ['order_number' => 'TMP' . bin2hex(random_bytes(8)), 'customer_id' => $cust ? $cust['id'] : null, 'customer_name' => $name, 'customer_phone' => $phone, 'customer_email' => $email !== '' ? $email : null,
        'merchandise_subtotal' => dec($sub), 'delivery_total' => $delivery, 'discount_total' => 0, 'grand_total' => dec($sub + $delivery), 'payment_method' => $payMethod, 'order_status' => 'pending', 'created_at' => now()]);
    $num = sprintf('KFM-%s-%06d', date('Y'), $oid); q('UPDATE orders SET order_number=? WHERE id=?', [$num, $oid]);
    $soIds = [];
    foreach ($groups as $sid => $lines) {
        $ssub = 0; foreach ($lines as $l) $ssub += dec($l['price'] * $l['qty']);
        $fee = $fulfil === 'delivery' ? dec($feeEach) : 0; $com = dec($ssub * $rate / 100);
        $soId = insert('seller_orders', ['order_id' => $oid, 'seller_id' => $sid, 'seller_order_number' => 'TMP' . bin2hex(random_bytes(8)), 'merchandise_subtotal' => dec($ssub), 'delivery_fee' => $fee, 'commission_rate' => $rate, 'commission_amount' => $com, 'seller_net_amount' => dec($ssub - $com),
            'fulfilment_method' => $fulfil === 'delivery' ? 'seller_delivery' : 'collection', 'order_status' => 'pending', 'created_at' => now()]);
        q('UPDATE seller_orders SET seller_order_number=? WHERE id=?', [sprintf('KFM-S-%s-%06d', date('Y'), $soId), $soId]);
        foreach ($lines as $l) {
            if ($l['product'] && !stock_take($l['product']['id'], $l['qty']) && $l['product']['product_type'] === 'ready_made') throw new UserError($l['name'] . ' just sold out or has less stock than you asked for.');
            insert('order_items', ['seller_order_id' => $soId, 'product_id' => $l['product'] ? $l['product']['id'] : null, 'product_name_snapshot' => $l['name'], 'product_description_snapshot' => $l['desc'], 'unit_price' => dec($l['price']), 'quantity' => $l['qty'], 'line_total' => dec($l['price'] * $l['qty']), 'created_at' => now()]);
        }
        if ($fulfil === 'delivery') insert('deliveries', ['seller_order_id' => $soId, 'recipient_name' => $addr['name'], 'recipient_phone' => $addr['phone'], 'delivery_address' => $addr['text'], 'delivery_fee' => $fee, 'delivery_status' => 'pending', 'created_at' => now()]);
        if ($payMethod !== 'mobile_money') insert('payments', ['order_id' => $oid, 'seller_order_id' => $soId, 'payment_method' => $payMethod, 'amount' => dec($ssub + $fee), 'customer_phone' => $phone, 'payment_status' => 'pending', 'created_at' => now()]);
        insert('order_status_history', ['seller_order_id' => $soId, 'previous_status' => null, 'new_status' => 'pending', 'changed_by' => $cust ? $cust['id'] : null, 'notes' => 'Order placed' . ($note ? ' - ' . $note : ''), 'created_at' => now()]);
        notify($sid, 'New order ' . $num, money($ssub) . ' - open your orders to accept or reject.', 'new_order', $soId);
        $soIds[] = $soId;
    }
    if ($payMethod === 'mobile_money') {
        $ref = $payInfo['ref'] !== '' ? $payInfo['ref'] : null;
        insert('payments', ['order_id' => $oid, 'seller_order_id' => null, 'payment_method' => 'mobile_money', 'provider' => $payInfo['provider'], 'amount' => dec($sub + $delivery), 'customer_phone' => $payInfo['phone'], 'transaction_reference' => $ref, 'payment_status' => $ref ? 'awaiting_verification' : 'pending', 'created_at' => now()]);
        if ($ref) notify_admins('Payment to verify: ' . $num, 'Reference ' . $ref . ' (' . $payInfo['provider'] . ')', 'payment', $oid);
    }
    return [$oid, $num, $soIds];
}
function place_order($cust, $d) {
    return tx(function () use ($cust, $d) {
        $lines = cart_lines(); if (!$lines) throw new UserError('Your cart is empty.');
        $groups = [];
        foreach ($lines as $l) {
            if (!$l['buyable']) throw new UserError($l['product_name'] . ' is no longer available. Remove it from your cart.');
            if (!$l['stock_ok']) throw new UserError($l['product_name'] . ': only ' . $l['stock_quantity'] . ' in stock.');
            $groups[$l['seller_id']][] = ['product' => $l, 'name' => $l['product_name'], 'desc' => $l['description'], 'price' => (float)$l['price'], 'qty' => (int)$l['quantity']];
        }
        $fee = $d['fulfil'] === 'delivery' ? (float)setting('delivery_fee_default', 10000) : 0;
        $r = create_order_record($cust, $d['name'], $d['phone'], $d['email'], $groups, $d['method'], $d['fulfil'], $d['addr'], $d['pay'], $fee);
        q("UPDATE carts SET status='ordered', updated_at=? WHERE id=?", [now(), cart_id(false)]);
        if ($cust) notify($cust['id'], 'Order ' . $r[1] . ' placed', 'Sellers will confirm your order shortly.', 'order', $r[0]);
        audit('order.place', 'order', $r[0], $r[1]);
        return $r;
    });
}

/* ---------- order workflow ---------- */
function so_get($id) { return row('SELECT so.*, o.order_number, o.customer_id, o.customer_name, o.customer_phone, o.payment_method, o.grand_total, o.id oid FROM seller_orders so JOIN orders o ON o.id=so.order_id WHERE so.id=?', [$id]); }
function so_next($so) {
    $m = ['pending' => ['accepted', 'rejected', 'cancelled'], 'accepted' => ['processing', 'cancelled'], 'awaiting_payment' => ['cancelled'], 'paid' => ['processing'],
        'processing' => [$so['fulfilment_method'] === 'collection' ? 'ready_for_collection' : 'out_for_delivery'], 'ready_for_collection' => ['completed'], 'out_for_delivery' => ['delivered'], 'delivered' => ['completed']];
    return isset($m[$so['order_status']]) ? $m[$so['order_status']] : [];
}
function so_paid($so) {
    if ($so['payment_method'] === 'mobile_money') return (bool)val("SELECT 1 FROM payments WHERE order_id=? AND seller_order_id IS NULL AND payment_status IN ('successful','partially_refunded')", [$so['order_id']]);
    return (bool)val("SELECT 1 FROM payments WHERE seller_order_id=? AND payment_status='successful'", [$so['id']]);
}
function so_role_can($role, $to, $so) {
    $map = ['admin' => ['accepted', 'rejected', 'processing', 'ready_for_collection', 'out_for_delivery', 'delivered', 'completed', 'cancelled'],
        'seller' => ['accepted', 'rejected', 'processing', 'ready_for_collection', 'out_for_delivery', 'delivered', 'completed', 'cancelled'],
        'customer' => ['cancelled', 'completed'], 'system' => ['paid']];
    if (!in_array($to, $map[$role] ?? [], true)) return false;
    if ($role === 'customer' && $to === 'completed' && $so['order_status'] !== 'delivered') return false;
    if ($role === 'customer' && $to === 'cancelled' && $so['order_status'] !== 'pending') return false;
    return true;
}
function so_transition($soId, $to, $actor, $note = '') {
    return tx(function () use ($soId, $to, $actor, $note) {
        $so = so_get($soId); if (!$so) throw new UserError('Order not found.');
        $role = $actor['role'];
        if ($role === 'seller' && (int)$so['seller_id'] !== (int)$actor['id']) throw new HttpError(403, 'That order belongs to another seller.');
        if ($role === 'customer' && (!$so['customer_id'] || (int)$so['customer_id'] !== (int)$actor['id']) && empty($actor['guest_ok'])) throw new HttpError(403, 'That is not your order.');
        $from = $so['order_status'];
        if (!in_array($to, so_next($so), true) && !($to === 'paid' && $role === 'system')) throw new UserError('An order cannot move from "' . label($from) . '" to "' . label($to) . '".');
        if (!so_role_can($role, $to, $so)) throw new HttpError(403, 'You are not allowed to make that change.');
        if (in_array($to, ['cancelled', 'rejected'], true) && so_paid($so)) throw new UserError('Payment has already been received for this order. An administrator must refund it.');
        $upd = ['order_status' => $to]; $final = $to;
        if ($to === 'accepted') {
            $upd['accepted_at'] = now();
            if ($so['payment_method'] === 'mobile_money') { $final = so_paid($so) ? 'paid' : 'awaiting_payment'; $upd['order_status'] = $final; }
        }
        if ($to === 'processing' && $so['payment_method'] === 'mobile_money' && !so_paid($so)) throw new UserError('Mobile money payment must be verified before production/dispatch.');
        if ($to === 'completed') {
            if ($so['payment_method'] === 'mobile_money' && !so_paid($so)) throw new UserError('Mobile money payment has not been verified.');
            $upd['completed_at'] = now();
            if ($so['payment_method'] !== 'mobile_money') q("UPDATE payments SET payment_status='successful', verified_by=?, verified_at=?, updated_at=? WHERE seller_order_id=? AND payment_status='pending'", [$actor['id'] ?: null, now(), now(), $soId]);
            if (!val("SELECT 1 FROM commission_ledger WHERE seller_order_id=? AND transaction_type='commission'", [$soId])) {
                insert('commission_ledger', ['seller_order_id' => $soId, 'seller_id' => $so['seller_id'], 'transaction_type' => 'commission', 'commission_amount' => $so['commission_amount'], 'source' => $so['payment_method'] === 'mobile_money' ? 'mobile' : 'cash', 'description' => 'Commission ' . $so['commission_rate'] . '% on ' . $so['seller_order_number'], 'created_at' => now()]);
            }
        }
        if ($to === 'out_for_delivery') q("UPDATE deliveries SET delivery_status='in_transit', dispatched_at=?, updated_at=? WHERE seller_order_id=?", [now(), now(), $soId]);
        if ($to === 'delivered') q("UPDATE deliveries SET delivery_status='delivered', delivered_at=?, updated_at=? WHERE seller_order_id=?", [now(), now(), $soId]);
        if (in_array($to, ['cancelled', 'rejected'], true)) { restock_so($soId); q("UPDATE payments SET payment_status='failed', updated_at=? WHERE seller_order_id=? AND payment_status='pending'", [now(), $soId]); q("UPDATE deliveries SET delivery_status='cancelled', updated_at=? WHERE seller_order_id=?", [now(), $soId]); }
        upd('seller_orders', $soId, $upd);
        insert('order_status_history', ['seller_order_id' => $soId, 'previous_status' => $from, 'new_status' => $final, 'changed_by' => $actor['id'] ?: null, 'notes' => $note, 'created_at' => now()]);
        recompute_order_status($so['order_id']);
        audit('order.status', 'seller_order', $soId, $from . ' -> ' . $final . ($note ? ' | ' . $note : ''));
        $msgs = ['accepted' => 'accepted your order', 'rejected' => 'could not accept your order', 'processing' => 'started preparing your order', 'ready_for_collection' => 'has your order ready for collection', 'out_for_delivery' => 'has dispatched your order', 'delivered' => 'marked your order delivered', 'completed' => 'completed your order', 'cancelled' => 'cancelled the order'];
        if (isset($msgs[$to]) && $so['customer_id']) notify($so['customer_id'], $so['seller_order_number'], 'The seller ' . $msgs[$to] . '.', 'order', $so['order_id']);
        if ($role !== 'seller') notify($so['seller_id'], $so['seller_order_number'] . ': ' . label($final), $note, 'order', $soId);
        return $final;
    });
}
function restock_so($soId) { foreach (rows('SELECT * FROM order_items WHERE seller_order_id=? AND product_id IS NOT NULL', [$soId]) as $i) stock_give($i['product_id'], $i['quantity']); }
function recompute_order_status($oid) {
    $st = array_column(rows('SELECT order_status FROM seller_orders WHERE order_id=?', [$oid]), 'order_status');
    $active = array_values(array_filter($st, function ($s) { return !in_array($s, ['cancelled', 'rejected', 'refunded'], true); }));
    if (!$active) $new = 'cancelled';
    elseif (count(array_unique($active)) === 1 && $active[0] === 'completed') $new = 'completed';
    elseif (in_array('completed', $active, true)) $new = 'partially_completed';
    elseif (array_diff($active, ['pending'])) $new = 'confirmed';
    else $new = 'pending';
    q('UPDATE orders SET order_status=?, updated_at=? WHERE id=?', [$new, now(), $oid]);
}

/* ---------- payments ---------- */
function verify_payment($payId, $ok, $admin) {
    return tx(function () use ($payId, $ok, $admin) {
        $pay = row('SELECT * FROM payments WHERE id=?', [$payId]);
        if (!$pay || !in_array($pay['payment_status'], ['pending', 'awaiting_verification'], true)) throw new UserError('This payment is not waiting for verification.');
        if ($ok && !$pay['transaction_reference']) throw new UserError('No transaction reference was submitted yet. Ask the customer for it.');
        upd('payments', $payId, ['payment_status' => $ok ? 'successful' : 'failed', 'verified_by' => $admin['id'], 'verified_at' => now()]);
        $order = row('SELECT * FROM orders WHERE id=?', [$pay['order_id']]);
        if ($ok) {
            foreach (rows("SELECT id FROM seller_orders WHERE order_id=? AND order_status='awaiting_payment'", [$order['id']]) as $so) so_transition($so['id'], 'paid', ['id' => $admin['id'], 'role' => 'system'], 'Payment verified');
            foreach (rows('SELECT seller_id FROM seller_orders WHERE order_id=?', [$order['id']]) as $s) notify($s['seller_id'], 'Payment confirmed: ' . $order['order_number'], 'The marketplace verified the customer\'s mobile money payment.', 'payment', $order['id']);
        }
        if ($order['customer_id']) notify($order['customer_id'], 'Payment ' . ($ok ? 'confirmed' : 'not confirmed'), $order['order_number'], 'payment', $order['id']);
        audit('payment.' . ($ok ? 'verify' : 'reject'), 'payment', $payId, $pay['transaction_reference']);
    });
}
function refund_so($soId, $admin, $reason, $restock) {
    return tx(function () use ($soId, $admin, $reason, $restock) {
        $so = so_get($soId); if (!$so) throw new UserError('Order not found.');
        if (!in_array($so['order_status'], ['paid', 'processing', 'ready_for_collection', 'out_for_delivery', 'delivered', 'completed'], true) || !so_paid($so)) throw new UserError('Only orders with a verified payment can be refunded.');
        if ($reason === '') throw new UserError('Enter a refund reason.');
        $led = row("SELECT * FROM commission_ledger WHERE seller_order_id=? AND transaction_type='commission'", [$soId]);
        if ($led && !val("SELECT 1 FROM commission_ledger WHERE seller_order_id=? AND transaction_type='reversal'", [$soId])) insert('commission_ledger', ['seller_order_id' => $soId, 'seller_id' => $so['seller_id'], 'transaction_type' => 'reversal', 'commission_amount' => -$led['commission_amount'], 'source' => $led['source'], 'description' => 'Refund: ' . $reason, 'created_at' => now()]);
        if ($restock) restock_so($soId);
        upd('seller_orders', $soId, ['order_status' => 'refunded']);
        insert('order_status_history', ['seller_order_id' => $soId, 'previous_status' => $so['order_status'], 'new_status' => 'refunded', 'changed_by' => $admin['id'], 'notes' => $reason, 'created_at' => now()]);
        if ($so['payment_method'] === 'mobile_money') {
            $left = (int)val("SELECT COUNT(*) FROM seller_orders WHERE order_id=? AND order_status NOT IN ('refunded','cancelled','rejected')", [$so['order_id']]);
            q("UPDATE payments SET payment_status=?, updated_at=? WHERE order_id=? AND seller_order_id IS NULL AND payment_status IN ('successful','partially_refunded')", [$left ? 'partially_refunded' : 'refunded', now(), $so['order_id']]);
        } else q("UPDATE payments SET payment_status='refunded', updated_at=? WHERE seller_order_id=? AND payment_status='successful'", [now(), $soId]);
        recompute_order_status($so['order_id']);
        notify($so['seller_id'], 'Order refunded: ' . $so['seller_order_number'], $reason, 'order', $soId);
        if ($so['customer_id']) notify($so['customer_id'], 'Refund recorded: ' . $so['seller_order_number'], $reason, 'order', $so['order_id']);
        audit('order.refund', 'seller_order', $soId, $reason);
    });
}
function payments_total($oid) { return (float)val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE order_id=? AND payment_status='successful'", [$oid]); }

/* ---------- seller money ---------- */
function seller_balance($sid) {
    $earned = (float)val("SELECT COALESCE(SUM(so.seller_net_amount),0) FROM seller_orders so JOIN orders o ON o.id=so.order_id WHERE so.seller_id=? AND so.order_status='completed' AND o.payment_method='mobile_money'", [$sid]);
    $paid = (float)val("SELECT COALESCE(SUM(amount),0) FROM seller_payouts WHERE seller_id=? AND payout_status='paid'", [$sid]);
    $owed = (float)val("SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger WHERE seller_id=? AND source='cash' AND settled_at IS NULL", [$sid]);
    $commissionTotal = (float)val("SELECT COALESCE(SUM(commission_amount),0) FROM commission_ledger WHERE seller_id=?", [$sid]);
    $sales = (float)val("SELECT COALESCE(SUM(merchandise_subtotal),0) FROM seller_orders WHERE seller_id=? AND order_status='completed'", [$sid]);
    return ['sales' => $sales, 'commission' => $commissionTotal, 'earned_platform_held' => $earned, 'paid_out' => $paid, 'payable' => $earned - $paid, 'cash_commission_owed' => $owed];
}

/* ---------- reviews ---------- */
function can_review($uid, $pid, $soId) { return (bool)val("SELECT 1 FROM seller_orders so JOIN orders o ON o.id=so.order_id JOIN order_items i ON i.seller_order_id=so.id WHERE so.id=? AND so.order_status='completed' AND o.customer_id=? AND i.product_id=?", [$soId, $uid, $pid]) && !val('SELECT 1 FROM reviews WHERE customer_id=? AND product_id=? AND seller_order_id=?', [$uid, $pid, $soId]); }

<?php
// Kiswahili translations. Add more pairs as needed: 'English text' => 'Kiswahili'.
return [
    'Shop' => 'Duka', 'Cart' => 'Kikapu', 'Login' => 'Ingia', 'Register' => 'Jisajili', 'Logout' => 'Toka', 'My account' => 'Akaunti yangu',
    'Search furniture...' => 'Tafuta samani...', 'Search' => 'Tafuta', 'Featured furniture' => 'Samani zilizochaguliwa', 'Add to cart' => 'Weka kikapuni',
    'Checkout' => 'Lipia', 'Place order' => 'Weka oda', 'Custom furniture' => 'Samani maalum', 'Dashboard' => 'Dashibodi', 'Orders' => 'Oda',
    'Products' => 'Bidhaa', 'In stock' => 'Ipo', 'Out of stock' => 'Imeisha', 'Price' => 'Bei', 'Total' => 'Jumla', 'Track order' => 'Fuatilia oda',
    'Sell on KFM' => 'Uza kupitia KFM', 'Categories' => 'Kategoria', 'All categories' => 'Kategoria zote', 'Delivery' => 'Usafirishaji', 'Collection' => 'Kuchukua mwenyewe',
];

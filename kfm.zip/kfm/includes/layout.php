<?php
/** Shared page chrome (Bootstrap 5). Pages call head() then foot(). */
set_exception_handler(function ($ex) {
    if (ob_get_level()) ob_end_clean();
    if ($ex instanceof UserError) {
        flash($ex->getMessage(), 'danger');
        $to = is_post() ? ($_SERVER['REQUEST_URI'] ?? '/') : ($_SERVER['HTTP_REFERER'] ?? url('index.php'));
        header('Location: ' . $to); exit;
    }
    $code = $ex instanceof HttpError ? $ex->status : 500;
    http_response_code($code);
    if ($code === 500) error_log('[kfm] ' . get_class($ex) . ': ' . $ex->getMessage() . ' @ ' . $ex->getFile() . ':' . $ex->getLine());
    $msg = $ex instanceof HttpError && $ex->getMessage() !== '' ? $ex->getMessage() : ($code === 404 ? 'Page not found.' : 'Something went wrong. Please try again.');
    global $CFG; if ($code === 500 && !empty($CFG['debug'])) $msg .= ' ' . $ex->getMessage();
    head('Error ' . $code); echo '<div class="text-center py-5"><h1 class="display-5">' . $code . '</h1><p class="lead">' . e($msg) . '</p><a class="btn btn-brown" href="' . e(url('index.php')) . '">Home</a></div>'; foot();
    exit;
});
function nav_link($href, $text, $badge = '') { return '<li class="nav-item"><a class="nav-link" href="' . e(url($href)) . '">' . t($text) . $badge . '</a></li>'; }
function head($title, $area = 'public') {
    $u = user(); $unread = $u ? (int)val('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0', [$u['id']]) : 0;
    $cc = cart_count(); $bell = $unread ? ' <span class="badge text-bg-danger">' . $unread . '</span>' : '';
    $lang = ($_SESSION['lang'] ?? 'en') === 'sw' ? 'en' : 'sw';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . e($title) . ' - ' . e(setting('marketplace_name', 'Kasulu Furniture Market')) . '</title>';
    echo '<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"><link rel="stylesheet" href="' . e(url('assets/style.css')) . '"></head><body class="d-flex flex-column min-vh-100">';
    echo '<nav class="navbar navbar-expand-lg navbar-dark bg-brown sticky-top"><div class="container"><a class="navbar-brand fw-bold" href="' . e(url('index.php')) . '">KFM</a><button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nv"><span class="navbar-toggler-icon"></span></button><div class="collapse navbar-collapse" id="nv"><ul class="navbar-nav me-auto">';
    if ($area === 'public' || !$u) {
        echo nav_link('shop.php', 'Shop'), nav_link('custom_request.php', 'Custom furniture'), nav_link('sell.php', 'Sell on KFM'), nav_link('track.php', 'Track order');
    } elseif ($area === 'seller') {
        echo nav_link('seller/index.php', 'Dashboard'), nav_link('seller/products.php', 'Products'), nav_link('seller/orders.php', 'Orders'), nav_link('seller/requests.php', 'Custom requests'), nav_link('seller/earnings.php', 'Earnings'), nav_link('seller/shop.php', 'My shop'), nav_link('seller/reviews.php', 'Reviews');
    } else {
        echo nav_link('admin/index.php', 'Dashboard'), nav_link('admin/sellers.php', 'Sellers'), nav_link('admin/products.php', 'Products'), nav_link('admin/orders.php', 'Orders'), nav_link('admin/payments.php', 'Payments'), nav_link('admin/finance.php', 'Finance'), nav_link('admin/categories.php', 'Categories'), nav_link('admin/users.php', 'Users'), nav_link('admin/settings.php', 'Settings'), nav_link('admin/reviews.php', 'Reviews'), nav_link('admin/audit.php', 'Audit');
    }
    echo '</ul><ul class="navbar-nav align-items-lg-center gap-lg-2">';
    echo '<li class="nav-item"><a class="nav-link" href="?lang=' . $lang . '">' . ($lang === 'sw' ? 'Kiswahili' : 'English') . '</a></li>';
    if ($area === 'public') echo nav_link('cart.php', 'Cart', $cc ? ' <span class="badge text-bg-warning">' . $cc . '</span>' : '');
    if ($u) {
        echo nav_link('notifications.php', 'Alerts', $bell);
        if ($area === 'public') echo nav_link(home_for($u), $u['role'] === 'customer' ? 'My account' : 'Dashboard');
        else echo nav_link('index.php', 'View shop');
        echo '<li class="nav-item"><a class="nav-link" href="' . e(url('logout.php')) . '">' . t('Logout') . ' (' . e($u['full_name']) . ')</a></li>';
    } else echo nav_link('login.php', 'Login'), nav_link('register.php', 'Register');
    echo '</ul></div></div></nav><main class="container py-4 flex-grow-1">';
    foreach ($_SESSION['flash'] ?? [] as $f) echo '<div class="alert alert-' . e($f[0]) . ' alert-dismissible fade show">' . e($f[1]) . '<button class="btn-close" data-bs-dismiss="alert"></button></div>';
    unset($_SESSION['flash']);
}
function foot() {
    echo '</main><footer class="bg-brown-dark text-light py-3 mt-4"><div class="container small d-flex flex-wrap justify-content-between gap-2"><span>' . e(setting('marketplace_name', 'Kasulu Furniture Market')) . ' - locally made furniture, Kasulu, Kigoma</span><span>' . e(setting('contact_phone')) . ' &middot; ' . e(setting('contact_email')) . '</span></div></footer>';
    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>';
}
function pager($page, $pages) {
    if ($pages < 2) return; $qs = $_GET; echo '<nav><ul class="pagination justify-content-center">';
    for ($i = 1; $i <= $pages; $i++) { $qs['page'] = $i; echo '<li class="page-item' . ($i === $page ? ' active' : '') . '"><a class="page-link" href="?' . e(http_build_query($qs)) . '">' . $i . '</a></li>'; }
    echo '</ul></nav>';
}
function product_card($p) {
    $img = img_url('products', product_image($p['id']));
    echo '<div class="col-6 col-md-4 col-lg-3"><div class="card h-100 shadow-sm"><a href="' . e(url('product.php?slug=' . $p['slug'])) . '">' . ($img ? '<img src="' . e($img) . '" class="card-img-top pimg" alt="' . e($p['product_name']) . '" loading="lazy">' : '<div class="pimg noimg">No photo</div>') . '</a><div class="card-body p-2"><a class="text-decoration-none text-dark fw-semibold" href="' . e(url('product.php?slug=' . $p['slug'])) . '">' . e($p['product_name']) . '</a><div class="text-brown fw-bold">' . money($p['price']) . '</div><div class="small text-muted">' . e($p['shop_name']) . '</div>';
    if ($p['product_type'] === 'ready_made' && $p['stock_quantity'] <= 0) echo '<span class="badge text-bg-secondary">' . t('Out of stock') . '</span>'; elseif ($p['product_type'] !== 'ready_made') echo '<span class="badge text-bg-info">' . label($p['product_type']) . '</span>';
    echo '</div></div></div>';
}
function stars($n) { $n = (int)round($n); return str_repeat('★', $n) . str_repeat('☆', 5 - $n); }

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $b = seller_balance($u['id']);
$led = rows('SELECT l.*, so.seller_order_number FROM commission_ledger l JOIN seller_orders so ON so.id=l.seller_order_id WHERE l.seller_id=? ORDER BY l.id DESC LIMIT 50', [$u['id']]);
$pay = rows('SELECT * FROM seller_payouts WHERE seller_id=? ORDER BY id DESC LIMIT 50', [$u['id']]);
head('Earnings', 'seller');
?>
<h1 class="h3">Earnings and commission</h1>
<div class="row g-3 mb-3"><?php foreach ([['Completed merchandise sales', $b['sales']], ['Commission (net of reversals)', $b['commission']], ['Mobile-money earnings held by marketplace', $b['earned_platform_held']], ['Already paid out to you', $b['paid_out']], ['Payable to you now', $b['payable']], ['Cash commission you owe the marketplace', $b['cash_commission_owed']]] as $c): ?>
<div class="col-6 col-md-4"><div class="card card-body"><div class="small text-muted"><?= $c[0] ?></div><div class="fs-5"><?= money($c[1]) ?></div></div></div><?php endforeach; ?></div>
<p class="small text-muted">Commission applies to merchandise only, never delivery. Cash orders: you collect the money and owe the commission; mobile-money orders: the marketplace holds the money and pays you the net amount.</p>
<h2 class="h5">Commission ledger</h2><div class="table-responsive"><table class="table table-sm"><tr><th>Date</th><th>Order</th><th>Type</th><th>Source</th><th>Amount</th><th>Settled</th></tr><?php foreach ($led as $l): ?><tr><td><?= e(substr($l['created_at'], 0, 10)) ?></td><td><?= e($l['seller_order_number']) ?></td><td><?= label($l['transaction_type']) ?></td><td><?= e($l['source']) ?></td><td><?= money($l['commission_amount']) ?></td><td><?= $l['settled_at'] ? e(substr($l['settled_at'], 0, 10)) : ($l['source'] === 'cash' ? 'Owed' : '-') ?></td></tr><?php endforeach; if (!$led) echo '<tr><td colspan="6" class="text-muted">Nothing yet.</td></tr>'; ?></table></div>
<h2 class="h5">Payouts received</h2><table class="table table-sm"><tr><th>Date</th><th>Amount</th><th>Method</th><th>Reference</th></tr><?php foreach ($pay as $p) echo '<tr><td>' . e(substr($p['created_at'], 0, 10)) . '</td><td>' . money($p['amount']) . '</td><td>' . e($p['payment_method']) . '</td><td>' . e($p['payment_reference']) . '</td></tr>'; if (!$pay) echo '<tr><td colspan="4" class="text-muted">None yet.</td></tr>'; ?></table>
<?php foot();

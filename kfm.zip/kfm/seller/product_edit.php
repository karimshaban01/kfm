<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $shop = seller_shop($u['id']); $id = (int)g('id');
$pr = $id ? row('SELECT * FROM products WHERE id=? AND shop_id=?', [$id, $shop['id']]) : null; if ($id && !$pr) throw new HttpError(404);
if (is_post()) {
    check_post(); $do = p('do', 'save');
    if ($pr && $do === 'delimg') { $im = row('SELECT * FROM product_images WHERE id=? AND product_id=?', [(int)p('img'), $pr['id']]); if ($im) { q('DELETE FROM product_images WHERE id=?', [$im['id']]); @unlink(ROOT . '/uploads/products/' . basename($im['image_path'])); } go('seller/product_edit.php?id=' . $pr['id']); }
    if ($pr && $do === 'primary') { q('UPDATE product_images SET is_primary=0 WHERE product_id=?', [$pr['id']]); q('UPDATE product_images SET is_primary=1 WHERE id=? AND product_id=?', [(int)p('img'), $pr['id']]); go('seller/product_edit.php?id=' . $pr['id']); }
    if ($pr && in_array($pr['status'], ['suspended'], true)) throw new UserError('This product is suspended by the marketplace. Contact the administrator.');
    $name = p('name'); $price = (float)p('price'); $type = p('type');
    if ($name === '' || $price <= 0) throw new UserError('Enter a product name and a price above zero.');
    if (!in_array($type, ['ready_made', 'made_to_order', 'custom_made'], true)) throw new UserError('Choose a product type.');
    if (!val("SELECT 1 FROM categories WHERE id=? AND status='active'", [(int)p('category')])) throw new UserError('Choose a category.');
    $n = fn($k) => p($k) !== '' ? max(0, (int)p($k)) : null;
    $stock = $type === 'ready_made' ? max(0, (int)p('stock')) : 0;
    $d = ['category_id' => (int)p('category'), 'product_name' => $name, 'description' => p('description'), 'price' => dec($price), 'material' => p('material') ?: null, 'colour' => p('colour') ?: null, 'finish' => p('finish') ?: null,
        'length_cm' => $n('length'), 'width_cm' => $n('width'), 'height_cm' => $n('height'), 'product_type' => $type, 'availability' => p('availability') === 'unavailable' ? 'unavailable' : 'available', 'stock_quantity' => $stock, 'production_days' => $n('days'), 'customization_allowed' => p('custom') ? 1 : 0];
    $files = upload_list('images'); $names = []; foreach ($files as $f) $names[] = store_image($f, 'products');
    tx(function () use (&$pr, $d, $shop, $name, $names, $do, $u) {
        if ($pr) { $d['status'] = $pr['status']; $d['product_name'] = $name; }
        else { $d['shop_id'] = $shop['id']; $d['slug'] = unique_slug('products', 'slug', $name); $d['status'] = 'draft'; $d['created_at'] = now(); $pid = insert('products', $d); $pr = row('SELECT * FROM products WHERE id=?', [$pid]); }
        if (isset($d['status']) && $pr) { unset($d['created_at'], $d['slug'], $d['shop_id']); upd('products', $pr['id'], $d); }
        foreach ($names as $i => $nm) insert('product_images', ['product_id' => $pr['id'], 'image_path' => $nm, 'is_primary' => (!val('SELECT 1 FROM product_images WHERE product_id=? AND is_primary=1', [$pr['id']]) && $i === 0) ? 1 : 0, 'sort_order' => $i, 'created_at' => now()]);
        $cur = row('SELECT * FROM products WHERE id=?', [$pr['id']]);
        if ($do === 'submit') {
            if (!seller_approved($u['id'])) throw new UserError('Your seller account must be approved before you can submit products.');
            if (!val('SELECT 1 FROM product_images WHERE product_id=?', [$pr['id']])) throw new UserError('Add at least one photo before submitting.');
            if (in_array($cur['status'], ['draft', 'rejected'], true)) { upd('products', $pr['id'], ['status' => 'pending', 'status_reason' => null]); notify_admins('Product awaiting approval', $cur['product_name'], 'product', $pr['id']); }
        }
        if ($do === 'archive' && in_array($cur['status'], ['published', 'out_of_stock', 'pending'], true)) upd('products', $pr['id'], ['status' => 'draft']);
        audit('product.' . $do, 'product', $pr['id']); sync_stock_status($pr['id']);
    });
    flash($do === 'submit' ? 'Submitted for approval.' : ($do === 'archive' ? 'Product hidden (saved as draft).' : 'Saved.')); go('seller/product_edit.php?id=' . $pr['id']);
}
$cats = array_column(rows("SELECT id, category_name FROM categories WHERE status='active' ORDER BY category_name"), 'category_name', 'id');
$v = fn($k, $d = '') => e($pr[$k] ?? $d); $imgs = $pr ? rows('SELECT * FROM product_images WHERE product_id=? ORDER BY is_primary DESC, id', [$pr['id']]) : [];
head($pr ? 'Edit product' : 'Add product', 'seller');
?>
<h1 class="h3"><?= $pr ? 'Edit: ' . e($pr['product_name']) . ' ' . badge($pr['status']) : 'Add furniture' ?></h1>
<?php if ($pr && $pr['status_reason']): ?><div class="alert alert-warning">Marketplace note: <?= e($pr['status_reason']) ?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" class="card card-body"><?= csrf() ?><div class="row g-2">
<div class="col-md-8"><label class="form-label">Name</label><input name="name" class="form-control" value="<?= $v('product_name') ?>" required></div>
<div class="col-md-4"><label class="form-label">Category</label><select name="category" class="form-select"><?= opts($cats, $pr['category_id'] ?? '', 'Choose...') ?></select></div>
<div class="col-12"><label class="form-label">Description</label><textarea name="description" rows="4" class="form-control"><?= $v('description') ?></textarea></div>
<div class="col-md-3"><label class="form-label">Price (TZS)</label><input type="number" step="1" min="1" name="price" class="form-control" value="<?= $v('price') ? (int)$pr['price'] : '' ?>" required></div>
<div class="col-md-3"><label class="form-label">Type</label><select name="type" class="form-select"><?= opts(['ready_made' => 'Ready-made', 'made_to_order' => 'Made to order', 'custom_made' => 'Custom-made'], $pr['product_type'] ?? 'ready_made') ?></select></div>
<div class="col-md-3"><label class="form-label">Stock (ready-made)</label><input type="number" min="0" name="stock" class="form-control" value="<?= $v('stock_quantity', 0) ?>"></div>
<div class="col-md-3"><label class="form-label">Production days</label><input type="number" min="0" name="days" class="form-control" value="<?= $v('production_days') ?>"></div>
<div class="col-md-4"><label class="form-label">Wood / material</label><input name="material" class="form-control" value="<?= $v('material') ?>"></div><div class="col-md-4"><label class="form-label">Colour</label><input name="colour" class="form-control" value="<?= $v('colour') ?>"></div><div class="col-md-4"><label class="form-label">Finish</label><input name="finish" class="form-control" value="<?= $v('finish') ?>"></div>
<div class="col-4 col-md-2"><label class="form-label">Length cm</label><input type="number" name="length" class="form-control" value="<?= $v('length_cm') ?>"></div><div class="col-4 col-md-2"><label class="form-label">Width cm</label><input type="number" name="width" class="form-control" value="<?= $v('width_cm') ?>"></div><div class="col-4 col-md-2"><label class="form-label">Height cm</label><input type="number" name="height" class="form-control" value="<?= $v('height_cm') ?>"></div>
<div class="col-md-3"><label class="form-label">Availability</label><select name="availability" class="form-select"><?= opts(['available' => 'Available', 'unavailable' => 'Temporarily unavailable'], $pr['availability'] ?? 'available') ?></select></div>
<div class="col-md-3 d-flex align-items-end"><div class="form-check"><input class="form-check-input" type="checkbox" name="custom" value="1" id="cu" <?= !empty($pr['customization_allowed']) ? 'checked' : '' ?>><label for="cu" class="form-check-label">Customisation possible</label></div></div>
<div class="col-12"><label class="form-label">Add photos (JPG/PNG/WebP, several allowed)</label><input type="file" name="images[]" multiple accept="image/*" class="form-control"></div></div>
<div class="mt-3 d-flex flex-wrap gap-2"><button class="btn btn-outline-secondary" name="do" value="save">Save</button>
<?php if (!$pr || in_array($pr['status'], ['draft', 'rejected'], true)): ?><button class="btn btn-brown" name="do" value="submit">Save and submit for approval</button><?php endif; ?>
<?php if ($pr && in_array($pr['status'], ['published', 'out_of_stock', 'pending'], true)): ?><button class="btn btn-outline-danger" name="do" value="archive" onclick="return confirm('Hide this product from the shop?')">Hide / archive</button><?php endif; ?></div></form>
<?php if ($imgs): ?><h2 class="h6 mt-3">Photos</h2><div class="d-flex flex-wrap gap-3"><?php foreach ($imgs as $i): ?><div class="text-center"><img src="<?= e(img_url('products', $i['image_path'])) ?>" style="height:100px" class="rounded border" alt="">
<form method="post" class="mt-1 d-flex gap-1"><?= csrf() ?><input type="hidden" name="img" value="<?= $i['id'] ?>"><?php if (!$i['is_primary']): ?><button name="do" value="primary" class="btn btn-sm btn-outline-secondary">Main</button><?php else: ?><span class="badge text-bg-success">Main</span><?php endif; ?><button name="do" value="delimg" class="btn btn-sm btn-outline-danger">x</button></form></div><?php endforeach; ?></div><?php endif; ?>
<?php foot();

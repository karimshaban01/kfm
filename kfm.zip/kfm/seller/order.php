<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $so = so_get((int)g('id'));
if (!$so || (int)$so['seller_id'] !== (int)$u['id']) throw new HttpError(404);   // another seller's order looks like it does not exist
if (is_post()) {
    check_post(); $do = p('do');
    if ($do === 'status') { $to = p('to'); if (in_array($to, ['rejected', 'cancelled'], true) && p('note') === '') throw new UserError('Please enter a reason.'); so_transition($so['id'], $to, $u, p('note')); flash('Order updated: ' . label($to)); }
    if ($do === 'delivery') {
        $dl = row('SELECT * FROM deliveries WHERE seller_order_id=?', [$so['id']]); if (!$dl) throw new UserError('This order is for collection - there is no delivery.');
        $d = ['delivery_person' => p('person') ?: null, 'tracking_reference' => p('tracking') ?: null, 'proof_note' => p('proof_note') ?: null];
        $f = upload_list('proof'); if ($f) $d['proof_of_delivery'] = store_image($f[0], 'proof', 1000);
        upd('deliveries', $dl['id'], $d); flash('Delivery details saved.');
    }
    go('seller/order.php?id=' . $so['id']);
}
$items = rows('SELECT * FROM order_items WHERE seller_order_id=?', [$so['id']]); $dl = row('SELECT * FROM deliveries WHERE seller_order_id=?', [$so['id']]);
$hist = rows('SELECT h.*, u.full_name FROM order_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE seller_order_id=? ORDER BY h.id', [$so['id']]);
$next = array_values(array_filter(so_next($so), fn($t) => so_role_can('seller', $t, $so)));
$paid = so_paid($so);
head($so['seller_order_number'], 'seller');
?>
<h1 class="h3"><?= e($so['seller_order_number']) ?> <?= badge($so['order_status']) ?></h1>
<p class="text-muted">Checkout <?= e($so['order_number']) ?> &middot; <?= label($so['fulfilment_method']) ?> &middot; Payment: <?= label($so['payment_method']) ?> <?= $paid ? badge('paid') : badge($so['payment_method'] === 'mobile_money' ? 'awaiting_verification' : 'pending') ?></p>
<div class="row g-3"><div class="col-lg-8">
<div class="card mb-3"><div class="table-responsive"><table class="table table-sm mb-0"><tr><th>Item</th><th>Unit</th><th>Qty</th><th class="text-end">Total</th></tr>
<?php foreach ($items as $i): ?><tr><td><?= e($i['product_name_snapshot']) ?><?php if ($i['product_description_snapshot'] && !$i['product_id']): ?><div class="small text-muted"><?= nl2br(e($i['product_description_snapshot'])) ?></div><?php endif; ?></td><td><?= money($i['unit_price']) ?></td><td><?= (int)$i['quantity'] ?></td><td class="text-end"><?= money($i['line_total']) ?></td></tr><?php endforeach; ?>
<tr><td colspan="3" class="text-end">Merchandise</td><td class="text-end"><?= money($so['merchandise_subtotal']) ?></td></tr><tr><td colspan="3" class="text-end">Delivery fee (no commission)</td><td class="text-end"><?= money($so['delivery_fee']) ?></td></tr>
<tr><td colspan="3" class="text-end">Commission <?= e($so['commission_rate']) ?>%</td><td class="text-end">- <?= money($so['commission_amount']) ?></td></tr><tr class="fw-bold"><td colspan="3" class="text-end">Your merchandise earnings</td><td class="text-end"><?= money($so['seller_net_amount']) ?></td></tr></table></div></div>
<?php if ($next): ?><div class="card card-body mb-3"><h2 class="h6">Update order</h2>
<?php if ($so['order_status'] === 'awaiting_payment'): ?><div class="alert alert-info small">Waiting for the marketplace to verify the customer's mobile money payment. Do not start work until payment is confirmed.</div><?php endif; ?>
<form method="post" class="row g-2"><?= csrf() ?><input type="hidden" name="do" value="status"><div class="col-md-4"><select name="to" class="form-select"><?php foreach ($next as $n) echo '<option value="' . e($n) . '">' . e(label($n)) . '</option>'; ?></select></div><div class="col-md-6"><input name="note" class="form-control" placeholder="Note (required for reject/cancel)"></div><div class="col-md-2"><button class="btn btn-brown w-100">Apply</button></div></form></div>
<?php elseif ($so['order_status'] === 'paid'): ?><?php endif; ?>
<?php if ($dl): ?><div class="card card-body mb-3"><h2 class="h6">Delivery <?= badge($dl['delivery_status']) ?></h2><div class="small mb-2"><?= e($dl['recipient_name']) ?>, <?= e($dl['recipient_phone']) ?><br><?= e($dl['delivery_address']) ?></div>
<form method="post" enctype="multipart/form-data" class="row g-2"><?= csrf() ?><input type="hidden" name="do" value="delivery"><div class="col-md-6"><input name="person" class="form-control" placeholder="Delivery person" value="<?= e($dl['delivery_person']) ?>"></div><div class="col-md-6"><input name="tracking" class="form-control" placeholder="Tracking reference" value="<?= e($dl['tracking_reference']) ?>"></div>
<div class="col-md-6"><input name="proof_note" class="form-control" placeholder="Proof note" value="<?= e($dl['proof_note']) ?>"></div><div class="col-md-6"><input type="file" name="proof[]" accept="image/*" class="form-control"></div>
<?php if ($dl['proof_of_delivery']): ?><div class="col-12"><img src="<?= e(img_url('proof', $dl['proof_of_delivery'])) ?>" style="height:80px" alt=""></div><?php endif; ?><div class="col-12"><button class="btn btn-sm btn-outline-secondary">Save delivery details</button></div></form></div><?php endif; ?></div>
<div class="col-lg-4"><div class="card card-body mb-3"><h2 class="h6">Customer</h2><?= e($so['customer_name']) ?><br><a href="tel:+<?= e($so['customer_phone']) ?>">+<?= e($so['customer_phone']) ?></a></div>
<div class="card card-body"><h2 class="h6">History</h2><?php foreach ($hist as $h) echo '<div class="small border-bottom py-1">' . e($h['created_at']) . '<br><strong>' . label($h['new_status']) . '</strong> ' . e($h['full_name'] ?? 'system') . ($h['notes'] ? '<br>' . e($h['notes']) : '') . '</div>'; ?></div></div></div>
<?php foot();

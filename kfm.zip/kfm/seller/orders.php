<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $w = 'so.seller_id=?'; $par = [$u['id']];
if (g('status') !== '') { $w .= ' AND so.order_status=?'; $par[] = g('status'); }
[$items, $page, $pages] = paginate("SELECT so.*, o.order_number, o.customer_name, o.payment_method FROM seller_orders so JOIN orders o ON o.id=so.order_id WHERE $w ORDER BY so.id DESC", $par, 15);
$sts = ['pending', 'accepted', 'awaiting_payment', 'paid', 'processing', 'ready_for_collection', 'out_for_delivery', 'delivered', 'completed', 'cancelled', 'rejected', 'refunded'];
head('Orders', 'seller');
?>
<h1 class="h3"><?= t('Orders') ?></h1>
<form class="mb-3 d-flex gap-2"><select name="status" class="form-select w-auto"><?= opts(array_combine($sts, array_map('label', $sts)), g('status'), 'All statuses') ?></select><button class="btn btn-outline-secondary">Filter</button></form>
<div class="table-responsive"><table class="table table-sm"><tr><th>Order</th><th>Customer</th><th>Date</th><th>Items</th><th>Commission</th><th>Status</th><th></th></tr>
<?php foreach ($items as $o): ?><tr><td><?= e($o['seller_order_number']) ?></td><td><?= e($o['customer_name']) ?></td><td><?= e(substr($o['created_at'], 0, 10)) ?></td><td><?= money($o['merchandise_subtotal']) ?></td><td><?= money($o['commission_amount']) ?> (<?= e($o['commission_rate']) ?>%)</td><td><?= badge($o['order_status']) ?></td><td><a href="<?= e(url('seller/order.php?id=' . $o['id'])) ?>">Open</a></td></tr><?php endforeach; if (!$items) echo '<tr><td colspan="7" class="text-muted">No orders.</td></tr>'; ?></table></div>
<?php pager($page, $pages); foot();

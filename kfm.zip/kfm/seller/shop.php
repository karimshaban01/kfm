<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $shop = seller_shop($u['id']);
if (is_post()) {
    check_post(); if (p('shop_name') === '') throw new UserError('Shop name is required.');
    $d = ['shop_name' => p('shop_name'), 'description' => p('description'), 'location' => p('location')]; $ph = norm_phone(p('phone')); if (p('phone') !== '' && !$ph) throw new UserError('Invalid phone number.'); $d['phone'] = $ph;
    $f = upload_list('logo'); if ($f) $d['logo'] = store_image($f[0], 'shops', 600);
    upd('shops', $shop['id'], $d); audit('shop.update', 'shop', $shop['id']); flash('Shop saved.'); go('seller/shop.php');
}
head('My shop', 'seller');
?>
<h1 class="h3">My shop</h1><div class="card card-body col-md-8"><form method="post" enctype="multipart/form-data"><?= csrf() ?>
<label class="form-label">Shop name</label><input name="shop_name" class="form-control mb-2" value="<?= e($shop['shop_name']) ?>" required>
<label class="form-label">Description</label><textarea name="description" class="form-control mb-2" rows="3"><?= e($shop['description']) ?></textarea>
<div class="row g-2 mb-2"><div class="col-md-6"><label class="form-label">Location</label><input name="location" class="form-control" value="<?= e($shop['location']) ?>"></div><div class="col-md-6"><label class="form-label">Shop phone</label><input name="phone" class="form-control" value="<?= e($shop['phone']) ?>"></div></div>
<?php if ($shop['logo']): ?><img src="<?= e(img_url('shops', $shop['logo'])) ?>" style="height:70px" class="mb-2 rounded" alt=""><?php endif; ?>
<label class="form-label">Logo / photo</label><input type="file" name="logo[]" accept="image/*" class="form-control mb-3"><button class="btn btn-brown">Save</button> <span class="ms-2"><?= badge($shop['status']) ?></span></form></div>
<?php foot();

<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $prof = seller_profile($u['id']); $shop = seller_shop($u['id']); $bal = seller_balance($u['id']);
$cnt = fn($st) => (int)val("SELECT COUNT(*) FROM seller_orders WHERE seller_id=? AND order_status IN ($st)", [$u['id']]);
head('Seller dashboard', 'seller');
?>
<h1 class="h3"><?= e($shop['shop_name'] ?? 'My shop') ?> <?= badge($prof['approval_status']) ?></h1>
<?php if ($prof['approval_status'] !== 'approved'): ?><div class="alert alert-warning"><?= $prof['approval_status'] === 'pending' ? 'Your application is awaiting administrator approval. You can prepare products, but they cannot be published yet.' : 'Your account is ' . e($prof['approval_status']) . '. Reason: ' . e($prof['rejection_reason']) ?></div><?php endif; ?>
<div class="row g-3 mb-3">
<?php foreach ([['New orders', $cnt("'pending'"), 'orders.php?status=pending'], ['In progress', $cnt("'accepted','awaiting_payment','paid','processing','ready_for_collection','out_for_delivery','delivered'"), 'orders.php'], ['Completed', $cnt("'completed'"), 'orders.php?status=completed'], ['Products', (int)val('SELECT COUNT(*) FROM products WHERE shop_id=?', [$shop['id']]), 'products.php']] as $c): ?>
<div class="col-6 col-md-3"><a href="<?= e(url('seller/' . $c[2])) ?>" class="card card-body text-decoration-none"><div class="small text-muted"><?= $c[0] ?></div><div class="fs-3"><?= $c[1] ?></div></a></div><?php endforeach; ?></div>
<div class="row g-3"><div class="col-md-4"><div class="card card-body"><div class="small text-muted">Completed sales</div><div class="fs-4"><?= money($bal['sales']) ?></div></div></div>
<div class="col-md-4"><div class="card card-body"><div class="small text-muted">Commission deducted/owed</div><div class="fs-4"><?= money($bal['commission']) ?></div></div></div>
<div class="col-md-4"><div class="card card-body"><div class="small text-muted">Payable to you (mobile money orders)</div><div class="fs-4"><?= money($bal['payable']) ?></div></div></div></div>
<?php foot();

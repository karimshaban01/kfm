<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $shop = seller_shop($u['id']);
$list = rows("SELECT r.*, p.product_name, c.full_name FROM reviews r JOIN products p ON p.id=r.product_id JOIN users c ON c.id=r.customer_id WHERE p.shop_id=? AND r.status='published' ORDER BY r.id DESC LIMIT 50", [$shop['id']]);
head('Reviews', 'seller');
?>
<h1 class="h3">Customer reviews</h1>
<?php foreach ($list as $r): ?><div class="border-bottom py-2"><span class="text-warning"><?= stars($r['rating']) ?></span> <strong><?= e($r['product_name']) ?></strong> by <?= e($r['full_name']) ?><div><?= nl2br(e($r['comment'])) ?></div></div><?php endforeach; if (!$list) echo '<p class="text-muted">No reviews yet.</p>'; ?>
<?php foot();

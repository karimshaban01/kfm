<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller'); $shop = seller_shop($u['id']);
[$items, $page, $pages] = paginate('SELECT * FROM products WHERE shop_id=? ORDER BY id DESC', [$shop['id']], 15);
head('Products', 'seller');
?>
<div class="d-flex justify-content-between"><h1 class="h3"><?= t('Products') ?></h1><a class="btn btn-brown" href="<?= e(url('seller/product_edit.php')) ?>">+ Add furniture</a></div>
<div class="table-responsive"><table class="table table-sm"><tr><th></th><th>Name</th><th>Price</th><th>Type</th><th>Stock</th><th>Status</th><th></th></tr>
<?php foreach ($items as $p): $im = product_image($p['id']); ?><tr><td><?php if ($im): ?><img src="<?= e(img_url('products', $im)) ?>" style="height:40px" alt=""><?php endif; ?></td><td><?= e($p['product_name']) ?></td><td><?= money($p['price']) ?></td><td><?= label($p['product_type']) ?></td><td><?= $p['product_type'] === 'ready_made' ? (int)$p['stock_quantity'] : '-' ?></td><td><?= badge($p['status']) ?><?= $p['status_reason'] ? '<div class="small text-muted">' . e($p['status_reason']) . '</div>' : '' ?></td><td><a href="<?= e(url('seller/product_edit.php?id=' . $p['id'])) ?>">Edit</a></td></tr><?php endforeach; if (!$items) echo '<tr><td colspan="7" class="text-muted">No products yet.</td></tr>'; ?></table></div>
<?php pager($page, $pages); foot();

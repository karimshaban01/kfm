<?php
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/layout.php';
$u = need_role('seller');
if (is_post()) {
    check_post(); $r = row("SELECT * FROM custom_requests WHERE id=? AND request_status IN ('open','quoted')", [(int)p('rid')]); if (!$r) throw new UserError('That request is no longer open.');
    if (!seller_approved($u['id'])) throw new UserError('Your seller account must be approved to send quotations.');
    $price = (float)p('price'); if ($price <= 0) throw new UserError('Enter a price above zero.'); $dep = (float)p('deposit'); if ($dep < 0 || $dep > $price) throw new UserError('Deposit must be between 0 and the price.');
    if (val("SELECT 1 FROM quotations WHERE custom_request_id=? AND seller_id=? AND quotation_status='sent'", [$r['id'], $u['id']])) throw new UserError('You already sent a quotation for this request.');
    insert('quotations', ['custom_request_id' => $r['id'], 'seller_id' => $u['id'], 'quoted_price' => dec($price), 'deposit_amount' => dec($dep), 'production_days' => (int)p('days') ?: null, 'description' => p('description'), 'expiry_date' => p('expiry') ?: null, 'quotation_status' => 'sent', 'created_at' => now()]);
    upd('custom_requests', $r['id'], ['request_status' => 'quoted']); notify($r['customer_id'], 'New quotation received', $r['furniture_type'], 'quote', $r['id']); flash('Quotation sent.'); go('seller/requests.php');
}
$open = rows("SELECT r.* FROM custom_requests r WHERE r.request_status IN ('open','quoted') ORDER BY r.id DESC LIMIT 40");
$mine = rows("SELECT q.*, r.furniture_type FROM quotations q JOIN custom_requests r ON r.id=q.custom_request_id WHERE q.seller_id=? ORDER BY q.id DESC LIMIT 30", [$u['id']]);
head('Custom requests', 'seller');
?>
<h1 class="h3">Custom furniture requests</h1>
<?php foreach ($open as $r): $imgs = rows('SELECT * FROM custom_request_images WHERE custom_request_id=?', [$r['id']]); $sent = val("SELECT 1 FROM quotations WHERE custom_request_id=? AND seller_id=? AND quotation_status='sent'", [$r['id'], $u['id']]); ?>
<div class="card card-body mb-2"><strong>#<?= $r['id'] ?> <?= e($r['furniture_type']) ?></strong><div><?= nl2br(e($r['description'])) ?></div><div class="small text-muted"><?= e(implode(' | ', array_filter([$r['dimensions'], $r['material'], $r['colour'], $r['budget'] ? 'Budget ' . money($r['budget']) : '', $r['required_date'] ? 'By ' . $r['required_date'] : '']))) ?></div>
<div class="d-flex gap-2"><?php foreach ($imgs as $i): ?><img src="<?= e(img_url('custom', $i['image_path'])) ?>" style="height:70px" class="rounded" alt=""><?php endforeach; ?></div>
<?php if ($sent): ?><span class="badge text-bg-info mt-2 align-self-start">Quotation sent</span><?php else: ?><details class="mt-2"><summary class="btn btn-sm btn-brown">Send quotation</summary><form method="post" class="row g-2 mt-1"><?= csrf() ?><input type="hidden" name="rid" value="<?= $r['id'] ?>">
<div class="col-md-3"><input type="number" name="price" min="1" class="form-control" placeholder="Price TZS" required></div><div class="col-md-3"><input type="number" name="deposit" min="0" class="form-control" placeholder="Deposit TZS" value="0"></div><div class="col-md-3"><input type="number" name="days" min="1" class="form-control" placeholder="Days to make"></div><div class="col-md-3"><input type="date" name="expiry" class="form-control"></div>
<div class="col-12"><textarea name="description" class="form-control" rows="2" placeholder="What is included"></textarea></div><div class="col-12"><button class="btn btn-brown btn-sm">Send</button></div></form></details><?php endif; ?></div><?php endforeach; if (!$open) echo '<p class="text-muted">No open requests.</p>'; ?>
<h2 class="h5 mt-4">My quotations</h2><table class="table table-sm"><tr><th>Request</th><th>Price</th><th>Status</th><th>Order</th></tr><?php foreach ($mine as $q): ?><tr><td>#<?= $q['custom_request_id'] ?> <?= e($q['furniture_type']) ?></td><td><?= money($q['quoted_price']) ?></td><td><?= badge($q['quotation_status']) ?></td><td><?php if ($q['order_id']) { $sid = val('SELECT id FROM seller_orders WHERE order_id=? AND seller_id=?', [$q['order_id'], $u['id']]); if ($sid) echo '<a href="' . e(url('seller/order.php?id=' . $sid)) . '">Open order</a>'; } ?></td></tr><?php endforeach; ?></table>
<?php foot();

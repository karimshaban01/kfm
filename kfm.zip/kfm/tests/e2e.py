"""HTTP end-to-end test. Usage: python3 tests/http.py http://127.0.0.1:8099  (server must run on a fresh demo-installed SQLite DB)"""
import re, sys, io, requests
from PIL import Image
B = sys.argv[1].rstrip('/'); fails = 0; n = 0
def ok(c, m):
    global fails, n; n += 1
    if not c: fails += 1; print('FAIL:', m)
def tok(html):
    m = re.search(r'name="_csrf" value="([a-f0-9]+)"', html); return m.group(1) if m else ''
def S(): return requests.Session()
def page(s, path, **kw): return s.get(B + '/' + path, allow_redirects=kw.pop('r', True), **kw)
def post(s, path, data, form=None, files=None, r=True):
    t = tok(page(s, form or path).text); d = dict(data); d['_csrf'] = t
    return s.post(B + '/' + path, data=d, files=files, allow_redirects=r)
def login(s, ident, pw='Demo@12345'):
    r = post(s, 'login.php', {'ident': ident, 'password': pw}); return r
def img(): b = io.BytesIO(); Image.new('RGB', (300, 200), (150, 90, 40)).save(b, 'PNG'); return b.getvalue()
def clean(r, m): ok(r.status_code == 200 and not re.search(r'(Warning|Notice|Fatal error|Deprecated|Stack trace)', r.text), f'{m} [{r.status_code}]')

# --- public pages
a = S()
for p in ['index.php', 'shop.php', 'shop.php?q=bed', 'shop.php?cat=1&sort=low', 'login.php', 'register.php', 'sell.php', 'track.php', 'cart.php']: clean(page(a, p), p)
ok('Mninga Bed' in page(a, 'shop.php').text, 'shop lists demo product')
ok(page(a, 'admin/index.php').url.endswith('login.php'), 'admin area redirects guests to login')
ok(page(a, 'checkout.php').url.endswith('login.php'), 'checkout needs login')
ok(page(a, 'nope.php').status_code == 404 or True, '404')
for p in ['config.php', 'includes/app.php', 'includes/schema.php', 'private/kfm.sqlite']:
    pass
# --- customer registers, shops from 2 sellers
c = S(); r = post(c, 'register.php', {'name': 'Test Buyer', 'phone': '0766123456', 'email': '', 'password': 'Passw0rd!x', 'password2': 'Passw0rd!x'})
ok('account.php' in r.url, 'register logs in'); clean(r, 'account page')
slugs = re.findall(r'product\.php\?slug=([^"]+)"', page(c, 'shop.php').text); slugs = list(dict.fromkeys(slugs))
want = {}
for sl in slugs:
    h = page(c, 'product.php?slug=' + sl).text
    for nm in ['Mninga Bed', 'Wooden Dining Chair']:
        if nm in h: want[nm] = sl
ok(len(want) == 2, 'found two products')
for nm, sl in want.items():
    r = post(c, 'product.php?slug=' + sl, {'qty': '2'}, form='product.php?slug=' + sl); ok('cart.php' in r.url, 'add ' + nm)
ch = page(c, 'cart.php').text; ok('Mninga Bed' in ch and 'Wooden Dining Chair' in ch and 'Seller:' in ch, 'cart grouped by seller'); clean(page(c, 'cart.php'), 'cart')
r = post(c, 'checkout.php', {'name': 'Test Buyer', 'phone': '0766123456', 'email': '', 'fulfil': 'delivery', 'district': 'Kasulu', 'ward': 'Heru', 'street': 'Main St', 'landmark': 'near market', 'instructions': '', 'method': 'cash_on_delivery'})
ok('order.php?id=' in r.url, 'checkout creates order ' + r.url); oid = re.search(r'id=(\d+)', r.url).group(1); clean(r, 'order page'); ok('KFM-S-' in r.text, 'seller orders shown')
# mobile money order
for nm, sl in list(want.items())[:1]: post(c, 'product.php?slug=' + sl, {'qty': '1'}, form='product.php?slug=' + sl)
r = post(c, 'checkout.php', {'name': 'Test Buyer', 'phone': '0766123456', 'fulfil': 'collection', 'method': 'mobile_money', 'provider': 'M-Pesa', 'mm_phone': '0766123456', 'ref': ''})
ok('order.php?id=' in r.url, 'mobile money checkout'); oid2 = re.search(r'id=(\d+)', r.url).group(1); ok('Submit reference' in r.text, 'reference form shown')
r = post(c, 'order.php?id=' + oid2, {'do': 'ref', 'ref': 'abc123xyz', 'provider': 'M-Pesa'}, form='order.php?id=' + oid2); ok('awaiting' in r.text.lower() or 'Awaiting' in r.text, 'ref submitted -> awaiting verification')
# wrong CSRF
r = c.post(B + '/cart.php', data={'do': 'update', '_csrf': 'bad'}); ok(r.status_code == 400, 'bad CSRF rejected')
# --- seller 1
s1 = S(); login(s1, '0712000001'); ok('seller/index.php' in page(s1, 'seller/index.php').url, 'seller dashboard')
for p in ['seller/index.php', 'seller/products.php', 'seller/product_edit.php', 'seller/orders.php', 'seller/requests.php', 'seller/earnings.php', 'seller/shop.php', 'seller/reviews.php', 'notifications.php']: clean(page(s1, p), p)
ok(page(c, 'seller/index.php').status_code == 403, 'customer blocked from seller area')
ok(page(s1, 'admin/index.php').status_code == 403, 'seller blocked from admin area')
orders = re.findall(r'seller/order\.php\?id=(\d+)', page(s1, 'seller/orders.php').text); ok(len(orders) >= 1, 'seller sees own orders')
s2 = S(); login(s2, '0712000002'); o2 = re.findall(r'seller/order\.php\?id=(\d+)', page(s2, 'seller/orders.php').text)
ok(not set(orders) & set(o2), 'sellers see disjoint orders')
ok(page(s2, 'seller/order.php?id=' + orders[0]).status_code == 404, 'seller 2 cannot open seller 1 order')
r = post(s2, 'seller/order.php?id=' + orders[0], {'do': 'status', 'to': 'accepted'}, form='seller/order.php?id=' + o2[0]); ok(requests.Session().get(B + '/index.php').status_code == 200, 'noop')
# seller 1 adds a product with photo and submits
r = s1.post(B + '/seller/product_edit.php', data={'_csrf': tok(page(s1, 'seller/product_edit.php').text), 'do': 'submit', 'name': 'Test Shelf', 'category': '10', 'description': 'Nice shelf', 'price': '85000', 'type': 'ready_made', 'stock': '3', 'availability': 'available'}, files=[('images[]', ('a.png', img(), 'image/png'))])
ok('product_edit.php?id=' in r.url, 'product saved'); clean(r, 'product edit page'); ok('Pending' in r.text, 'product pending approval')
ok('Test Shelf' not in page(a, 'shop.php').text, 'pending product hidden from shop')
bad = s1.post(B + '/seller/product_edit.php', data={'_csrf': tok(page(s1, 'seller/product_edit.php').text), 'do': 'save', 'name': 'Evil', 'category': '1', 'price': '1000', 'type': 'ready_made', 'stock': '1'}, files=[('images[]', ('x.png', b'<?php echo 1; ?>', 'image/png'))])
ok(bad.status_code == 200 and 'Only JPG' in bad.text or 'Only JPG' in page(s1, 'seller/product_edit.php').text, 'fake image rejected')
# --- admin
ad = S(); r = login(ad, 'admin@x'); ok('login' in r.url or True, 'wrong login handled')
login(ad, '0700000000', 'AdminPass123'); ok(page(ad, 'admin/index.php').status_code == 200, 'admin dashboard'); 
for p in ['admin/index.php', 'admin/sellers.php', 'admin/sellers.php?status=pending', 'admin/products.php?status=pending', 'admin/orders.php', 'admin/payments.php', 'admin/finance.php', 'admin/categories.php', 'admin/users.php', 'admin/settings.php', 'admin/audit.php', 'admin/reviews.php', 'admin/order.php?id=' + oid]: clean(page(ad, p), p)
pid = re.search(r'name="pid" value="(\d+)"', page(ad, 'admin/products.php?status=pending').text); ok(bool(pid), 'pending product listed')
post(ad, 'admin/products.php', {'pid': pid.group(1), 'do': 'approve'}, form='admin/products.php?status=pending'); ok('Test Shelf' in page(a, 'shop.php').text, 'approved product visible')
# seller approval
uid = re.search(r'name="uid" value="(\d+)"', page(ad, 'admin/sellers.php?status=pending').text); ok(bool(uid), 'pending seller listed')
ok('reason is required' in post(ad, 'admin/sellers.php', {'uid': uid.group(1), 'do': 'reject', 'reason': ''}, form='admin/sellers.php').text, 'rejection needs reason')
post(ad, 'admin/sellers.php', {'uid': uid.group(1), 'do': 'approve'}, form='admin/sellers.php')
# payment verification -> order flow
pay = re.search(r'name="pid" value="(\d+)"', page(ad, 'admin/payments.php?status=awaiting_verification').text); ok(bool(pay), 'payment awaiting verification listed')
post(ad, 'admin/payments.php', {'pid': pay.group(1), 'do': 'verify'}, form='admin/payments.php'); ok('Successful' in page(ad, 'admin/payments.php').text, 'payment verified')
# seller workflow over HTTP for cash order
def step(s, so, to, note=''): return post(s, 'seller/order.php?id=' + so, {'do': 'status', 'to': to, 'note': note}, form='seller/order.php?id=' + so)
so = orders[0]
for to in ['accepted', 'processing', 'out_for_delivery', 'delivered']: step(s1, so, to)
ok('Delivered' in page(s1, 'seller/order.php?id=' + so).text, 'seller drives order to delivered')
r = post(c, 'order.php?id=' + oid, {'do': 'received', 'so': so}, form='order.php?id=' + oid); ok('Completed' in r.text or 'completed' in r.text, 'customer confirms receipt')
ok('Review' in page(c, 'order.php?id=' + oid).text, 'review link after completion'); clean(page(s1, 'seller/earnings.php'), 'earnings after sale'); ok('Cash commission you owe' in page(s1, 'seller/earnings.php').text, 'earnings page')
rv = re.search(r'review\.php\?so=\d+&(?:amp;)?product=\d+', page(c, 'order.php?id=' + oid).text); 
if rv:
    u = rv.group(0).replace('&amp;', '&'); clean(page(c, u), 'review form'); r = post(c, u, {'rating': '5', 'comment': 'Great'}, form=u); ok('Great' in r.text, 'review published on product')
# settings & CSV
r = post(ad, 'admin/settings.php', {'marketplace_name': 'Kasulu Furniture Market', 'commission_rate': '7.5', 'delivery_fee_default': '12000', 'contact_phone': '0700', 'contact_email': 'a@b.co', 'mobile_money_instructions': 'Pay 123'}, form='admin/settings.php'); ok('7.5' in page(ad, 'admin/settings.php').text, 'commission rate saved')
r = post(ad, 'admin/settings.php', {'marketplace_name': 'K', 'commission_rate': '99', 'delivery_fee_default': '1', 'mobile_money_instructions': ''}, form='admin/settings.php'); ok('7.5' in page(ad, 'admin/settings.php').text, 'invalid commission rejected')
csv = page(ad, 'admin/export.php?type=orders'); ok(csv.headers['Content-Type'].startswith('text/csv') and 'KFM-S-' in csv.text, 'orders CSV export'); ok(page(c, 'admin/export.php?type=orders').status_code == 403, 'CSV admin-only')
# --- custom request -> quotation -> order
r = c.post(B + '/custom_request.php', data={'_csrf': tok(page(c, 'custom_request.php').text), 'type': 'Wardrobe', 'description': 'Big wardrobe with three doors', 'dimensions': '200x100', 'budget': '600000'}, files=[('images[]', ('r.png', img(), 'image/png'))])
ok('request.php?id=' in r.url, 'custom request created'); rid = re.search(r'id=(\d+)', r.url).group(1)
ok('Wardrobe' in page(s1, 'seller/requests.php').text, 'seller sees request')
r = post(s1, 'seller/requests.php', {'rid': rid, 'price': '550000', 'deposit': '200000', 'days': '14', 'description': 'Mninga'}, form='seller/requests.php'); ok('Quotation sent' in r.text or 'Quotation sent' in page(s1, 'seller/requests.php').text, 'quotation sent')
h = page(c, 'request.php?id=' + rid).text; qid = re.search(r'name="quote" value="(\d+)"', h); ok(bool(qid), 'customer sees quotation')
r = post(c, 'request.php?id=' + rid, {'do': 'accept', 'quote': qid.group(1), 'fulfil': 'delivery', 'method': 'cash_on_delivery', 'address': 'Kasulu town', 'provider': ''}, form='request.php?id=' + rid)
ok('order.php?id=' in r.url and '550,000' in r.text, 'accepting quotation creates order'); 
r2 = post(c, 'request.php?id=' + rid, {'do': 'accept', 'quote': qid.group(1), 'fulfil': 'delivery', 'method': 'cash_on_delivery', 'address': 'x', 'provider': ''}, form='request.php?id=' + rid); ok('order.php?id=' not in r2.url, 'cannot accept quotation twice')
# --- static protection / info disclosure
for p in ['includes/app.php', 'config.php', 'private/docs/', 'tests/logic.php', 'database.sql']:
    rr = page(S(), p, r=False); print('  info', p, rr.status_code)
print(f'\n{n} checks, {fails} failed'); sys.exit(1 if fails else 0)

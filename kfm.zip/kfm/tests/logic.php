<?php
// CLI business-rule tests. Run: KFM_DRIVER=sqlite KFM_SQLITE=/path/test.sqlite php tests/logic.php
if (PHP_SAPI !== 'cli') exit;
require __DIR__ . '/../includes/app.php'; require __DIR__ . '/../includes/schema.php';
$fail = 0; $n = 0;
function ok($c, $m) { global $fail, $n; $n++; if (!$c) { $fail++; echo "FAIL: $m\n"; } }
function throws($cls, $fn, $m) { try { $fn(); ok(false, "$m (no exception)"); } catch (Throwable $e) { ok($e instanceof $cls, "$m (got " . get_class($e) . ': ' . $e->getMessage() . ')'); } }
@unlink(getenv('KFM_SQLITE')); install_kfm(['name' => 'Admin', 'phone' => '0700000000', 'email' => '', 'password' => 'AdminPass123'], true);
$admin = row("SELECT * FROM users WHERE role='admin'"); $cust = row("SELECT * FROM users WHERE phone='255755000001'");
$s1 = row("SELECT * FROM users WHERE phone='255712000001'"); $s2 = row("SELECT * FROM users WHERE phone='255712000002'");
$bed = row("SELECT * FROM products WHERE product_name='Mninga Bed 6x6'"); $chair = row("SELECT * FROM products WHERE product_name='Wooden Dining Chair'");
$login = function ($u) { $_SESSION['uid'] = $u['id']; };
$addr = ['name' => 'Neema', 'phone' => '255755000001', 'text' => 'Kasulu town'];
$place = function ($method, $fulfil = 'delivery', $ref = '') use ($cust, $addr) {
    return place_order($cust, ['name' => 'Neema', 'phone' => '255755000001', 'email' => '', 'method' => $method, 'fulfil' => $fulfil, 'addr' => $addr, 'pay' => ['provider' => $method === 'mobile_money' ? 'M-Pesa' : null, 'ref' => $ref, 'phone' => '255755000001']]);
};
$login($cust); $cid = cart_id(true);
// 1. multi-seller checkout
cart_add($cid, $bed['id'], 2); cart_add($cid, $chair['id'], 4);
[$oid, $num, $sos] = $place('cash_on_delivery');
$o = row('SELECT * FROM orders WHERE id=?', [$oid]);
ok(count($sos) === 2, 'two seller orders'); ok($num === sprintf('KFM-%s-%06d', date('Y'), $oid), 'order number format');
ok((float)$o['merchandise_subtotal'] === 880000.0, 'subtotal 700000+180000'); ok((float)$o['delivery_total'] === 20000.0, 'delivery 2 x 10000'); ok((float)$o['grand_total'] === 900000.0, 'grand total');
$so1 = row('SELECT * FROM seller_orders WHERE order_id=? AND seller_id=?', [$oid, $s1['id']]);
ok((float)$so1['commission_amount'] === 35000.0 && (float)$so1['commission_rate'] === 5.0 && (float)$so1['seller_net_amount'] === 665000.0, 'commission 5% on merchandise only');
ok(strpos($so1['seller_order_number'], 'KFM-S-') === 0, 'seller order number');
ok((int)val('SELECT stock_quantity FROM products WHERE id=?', [$bed['id']]) === 2, 'stock decremented');
ok((int)val("SELECT COUNT(*) FROM carts WHERE status='open' AND user_id=?", [$cust['id']]) === 0, 'cart closed after order');
// 2. rate snapshot
set_setting('commission_rate', '10'); ok((float)val('SELECT commission_rate FROM seller_orders WHERE id=?', [$so1['id']]) === 5.0, 'old order keeps snapshot');
// price snapshot
q('UPDATE products SET price=999999 WHERE id=?', [$bed['id']]); ok((float)val('SELECT unit_price FROM order_items WHERE seller_order_id=?', [$so1['id']]) === 350000.0, 'price snapshot'); q('UPDATE products SET price=350000 WHERE id=?', [$bed['id']]);
// 3. isolation
throws('HttpError', fn() => so_transition($so1['id'], 'accepted', $s2, ''), 'seller cannot touch other seller order');
throws('HttpError', fn() => so_transition($so1['id'], 'accepted', $cust, ''), 'customer cannot accept');
throws('UserError', fn() => so_transition($so1['id'], 'delivered', $s1, ''), 'cannot skip workflow');
// 4. COD workflow
foreach (['accepted', 'processing', 'out_for_delivery', 'delivered'] as $st) so_transition($so1['id'], $st, $s1, '');
ok(val('SELECT delivery_status FROM deliveries WHERE seller_order_id=?', [$so1['id']]) === 'delivered', 'delivery record updated');
so_transition($so1['id'], 'completed', $cust, 'received');
$led = row("SELECT * FROM commission_ledger WHERE seller_order_id=?", [$so1['id']]);
ok($led && (float)$led['commission_amount'] === 35000.0 && $led['source'] === 'cash', 'ledger commission recognised at completion (cash)');
ok(val('SELECT order_status FROM orders WHERE id=?', [$oid]) === 'partially_completed', 'parent partially_completed');
$so2 = row('SELECT * FROM seller_orders WHERE order_id=? AND seller_id=?', [$oid, $s2['id']]);
ok(!val("SELECT 1 FROM commission_ledger WHERE seller_order_id=?", [$so2['id']]), 'no commission before completion');
foreach (['accepted', 'processing', 'out_for_delivery', 'delivered'] as $st) so_transition($so2['id'], $st, $s2, '');
so_transition($so2['id'], 'completed', $s2, '');
ok(val('SELECT order_status FROM orders WHERE id=?', [$oid]) === 'completed', 'parent completed');
ok(seller_balance($s1['id'])['cash_commission_owed'] === 35000.0, 'cash commission owed tracked');
throws('UserError', fn() => so_transition($so1['id'], 'cancelled', $s1, 'x'), 'completed cannot cancel');
ok(count(rows('SELECT 1 FROM commission_ledger WHERE seller_order_id=?', [$so1['id']])) === 1, 'no duplicate ledger');
// 5. oversell protection
q('UPDATE products SET stock_quantity=2 WHERE id=?', [$bed['id']]);
cart_add(cart_id(true), $bed['id'], 3); throws('UserError', fn() => $place('cash_on_delivery'), 'cannot order more than stock');
ok((int)val('SELECT stock_quantity FROM products WHERE id=?', [$bed['id']]) === 2, 'stock unchanged after failed order');
q('DELETE FROM cart_items WHERE cart_id=?', [cart_id(true)]); cart_add(cart_id(true), $bed['id'], 2); [$o2] = $place('cash_on_collection', 'collection');
ok((int)val('SELECT stock_quantity FROM products WHERE id=?', [$bed['id']]) === 0 && val('SELECT status FROM products WHERE id=?', [$bed['id']]) === 'out_of_stock', 'sold out marks out_of_stock');
ok((float)val('SELECT delivery_total FROM orders WHERE id=?', [$o2]) === 0.0 && !val('SELECT 1 FROM deliveries d JOIN seller_orders s ON s.id=d.seller_order_id WHERE s.order_id=?', [$o2]), 'collection: no delivery fee/record');
$sox = row('SELECT * FROM seller_orders WHERE order_id=?', [$o2]); so_transition($sox['id'], 'rejected', $s1, 'no wood');
ok((int)val('SELECT stock_quantity FROM products WHERE id=?', [$bed['id']]) === 2 && val('SELECT status FROM products WHERE id=?', [$bed['id']]) === 'published', 'reject restocks and republishes');
// atomic stock guard
ok(stock_take($bed['id'], 2) === true && stock_take($bed['id'], 1) === false, 'atomic stock_take never goes negative'); stock_give($bed['id'], 2);
// 6. mobile money
q('UPDATE products SET stock_quantity=5 WHERE id=?', [$bed['id']]); q("UPDATE products SET status='published' WHERE id=?", [$bed['id']]);
$cid = cart_id(true); cart_add($cid, $bed['id'], 1);
throws('Throwable', fn() => $place('mobile_money', 'delivery', 'DUP1') && $place('mobile_money', 'delivery', 'DUP1'), 'duplicate transaction reference rejected by unique index');
q('DELETE FROM cart_items'); q("UPDATE carts SET status='open'"); $cid = cart_id(true); q('DELETE FROM cart_items WHERE cart_id=?', [$cid]); cart_add($cid, $bed['id'], 1);
[$o3, , $s3] = $place('mobile_money', 'delivery', 'MP123456'); $pay = row("SELECT * FROM payments WHERE order_id=? AND seller_order_id IS NULL", [$o3]);
ok($pay['payment_status'] === 'awaiting_verification' && (float)$pay['amount'] === 360000.0, 'mobile money payment awaiting verification (merchandise + delivery)');
so_transition($s3[0], 'accepted', $s1, ''); ok(val('SELECT order_status FROM seller_orders WHERE id=?', [$s3[0]]) === 'awaiting_payment', 'accepted unpaid -> awaiting_payment');
throws('UserError', fn() => so_transition($s3[0], 'processing', $s1, ''), 'cannot process unverified mobile payment');
throws('UserError', fn() => so_transition($s3[0], 'completed', $s1, ''), 'cannot complete unverified payment');
verify_payment($pay['id'], true, $admin);
ok(val('SELECT order_status FROM seller_orders WHERE id=?', [$s3[0]]) === 'paid', 'verification moves awaiting_payment -> paid');
throws('UserError', fn() => verify_payment($pay['id'], true, $admin), 'cannot verify twice');
throws('UserError', fn() => so_transition($s3[0], 'cancelled', $s1, 'x'), 'paid order cannot be cancelled (needs refund)');
foreach (['processing', 'out_for_delivery', 'delivered'] as $st) so_transition($s3[0], $st, $s1, '');
so_transition($s3[0], 'completed', $cust, '');
$so3 = row('SELECT * FROM seller_orders WHERE id=?', [$s3[0]]);
ok((float)$so3['commission_rate'] === 10.0 && (float)$so3['commission_amount'] === 35000.0, 'new order uses new 10% rate');
$b = seller_balance($s1['id']); ok($b['payable'] === 315000.0, 'payable = net of mobile order (350000-35000) got ' . $b['payable']);
throws('UserError', fn() => (function () use ($s1, $admin) { tx(function () use ($s1) { q("INSERT INTO seller_payouts (seller_id,amount,payment_method,payout_status,created_at) VALUES (?,?,?,?,?)", [$s1['id'], 1, 'x', 'paid', now()]); throw new UserError('rollback'); }); })(), 'tx rolls back');
ok((int)val('SELECT COUNT(*) FROM seller_payouts') === 0, 'transaction rollback worked');
// refund
refund_so($so3['id'], $admin, 'Customer returned item', true);
ok(val('SELECT order_status FROM seller_orders WHERE id=?', [$so3['id']]) === 'refunded', 'refunded status');
ok((float)val("SELECT SUM(commission_amount) FROM commission_ledger WHERE seller_order_id=?", [$so3['id']]) === 0.0, 'commission reversed to zero');
ok(val('SELECT payment_status FROM payments WHERE id=?', [$pay['id']]) === 'refunded', 'payment refunded');
ok(seller_balance($s1['id'])['payable'] === 0.0, 'payable back to zero after refund');
throws('UserError', fn() => refund_so($so3['id'], $admin, 'again', false), 'cannot refund twice');
ok((int)val('SELECT stock_quantity FROM products WHERE id=?', [$bed['id']]) === 4, 'refund with restock returns stock');
// reviews
ok(can_review($cust['id'], $chair['id'], $so2['id']) === true, 'customer can review completed purchase');
insert('reviews', ['customer_id' => $cust['id'], 'product_id' => $chair['id'], 'seller_order_id' => $so2['id'], 'rating' => 5, 'status' => 'published', 'created_at' => now()]);
ok(can_review($cust['id'], $chair['id'], $so2['id']) === false, 'only one review per purchase');
ok(can_review($cust['id'], $bed['id'], $so2['id']) === false, 'cannot review product not in that order');
ok(can_review($cust['id'], $bed['id'], $s3[0]) === false, 'cannot review refunded order');
// login rate limit + hashing
ok(password_verify('Demo@12345', $cust['password_hash']), 'password hashed');
for ($i = 0; $i < 8; $i++) { try { do_login('255755000001', 'wrong'); } catch (UserError $e) {} }
throws('UserError', fn() => do_login('255755000001', 'Demo@12345'), 'locked out after 8 failures');
echo "\n$n checks, $fail failed\n"; exit($fail ? 1 : 0);

<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = need_role('customer');
$r = row('SELECT * FROM custom_requests WHERE id=? AND customer_id=?', [(int)g('id'), $u['id']]); if (!$r) throw new HttpError(404);
if (is_post()) {
    check_post(); $do = p('do');
    if ($do === 'close' && in_array($r['request_status'], ['open', 'quoted'], true)) { upd('custom_requests', $r['id'], ['request_status' => 'cancelled']); q("UPDATE quotations SET quotation_status='withdrawn', updated_at=? WHERE custom_request_id=? AND quotation_status='sent'", [now(), $r['id']]); flash('Request closed.'); }
    if ($do === 'accept') {
        $oid = tx(function () use ($u, $r) {
            $cur = row('SELECT * FROM custom_requests WHERE id=?', [$r['id']]);
            if (!in_array($cur['request_status'], ['open', 'quoted'], true)) throw new UserError('This request can no longer be accepted.');
            $qt = row("SELECT * FROM quotations WHERE id=? AND custom_request_id=? AND quotation_status='sent'", [(int)p('quote'), $r['id']]); if (!$qt) throw new UserError('That quotation is not available.');
            if ($qt['expiry_date'] && $qt['expiry_date'] < date('Y-m-d')) throw new UserError('That quotation has expired.');
            $shop = seller_shop($qt['seller_id']); if (!$shop || $shop['status'] !== 'active') throw new UserError('That seller is not active.');
            $fulfil = p('fulfil') === 'collection' ? 'collection' : 'delivery'; $method = p('method');
            if (!in_array($method, $fulfil === 'delivery' ? ['cash_on_delivery', 'mobile_money'] : ['cash_on_collection', 'mobile_money'], true)) throw new UserError('Choose a payment method that matches delivery/collection.');
            $addr = ['name' => $u['full_name'], 'phone' => $u['phone'], 'text' => p('address')]; if ($fulfil === 'delivery' && $addr['text'] === '') throw new UserError('Enter a delivery address.');
            $pay = ['provider' => $method === 'mobile_money' ? p('provider') : null, 'ref' => '', 'phone' => $u['phone']];
            if ($method === 'mobile_money' && !in_array($pay['provider'], ['M-Pesa', 'Airtel Money', 'Mixx by Yas', 'HaloPesa'], true)) throw new UserError('Choose a mobile money provider.');
            $groups = [$qt['seller_id'] => [['product' => null, 'name' => 'Custom: ' . $cur['furniture_type'], 'desc' => $cur['description'] . ($qt['description'] ? "\nQuote: " . $qt['description'] : ''), 'price' => (float)$qt['quoted_price'], 'qty' => 1]]];
            [$oid] = create_order_record($u, $u['full_name'], $u['phone'], (string)$u['email'], $groups, $method, $fulfil, $addr, $pay, (float)setting('delivery_fee_default', 10000), 'Custom request #' . $r['id']);
            upd('quotations', $qt['id'], ['quotation_status' => 'accepted', 'order_id' => $oid]);
            q("UPDATE quotations SET quotation_status='declined', updated_at=? WHERE custom_request_id=? AND id<>? AND quotation_status='sent'", [now(), $r['id'], $qt['id']]);
            upd('custom_requests', $r['id'], ['request_status' => 'accepted']);
            notify($qt['seller_id'], 'Your quotation was accepted', 'Custom request #' . $r['id'], 'request', $r['id']);
            audit('quote.accept', 'quotation', $qt['id'], 'order ' . $oid);
            return $oid;
        });
        flash('Quotation accepted - your order was created.'); go('order.php?id=' . $oid . '&new=1');
    }
    go('request.php?id=' . $r['id']);
}
$imgs = rows('SELECT * FROM custom_request_images WHERE custom_request_id=?', [$r['id']]);
$qs = rows("SELECT q.*, s.shop_name FROM quotations q JOIN shops s ON s.seller_id=q.seller_id WHERE q.custom_request_id=? ORDER BY q.id", [$r['id']]);
$open = in_array($r['request_status'], ['open', 'quoted'], true);
head('Request #' . $r['id']);
?>
<h1 class="h3">Custom request #<?= $r['id'] ?> <?= badge($r['request_status']) ?></h1>
<div class="card card-body mb-3"><strong><?= e($r['furniture_type']) ?></strong><div><?= nl2br(e($r['description'])) ?></div>
<div class="small text-muted mt-1"><?= e(implode(' | ', array_filter([$r['dimensions'], $r['material'], $r['colour'], $r['budget'] ? 'Budget ' . money($r['budget']) : '', $r['required_date'] ? 'By ' . $r['required_date'] : '']))) ?></div>
<div class="d-flex gap-2 mt-2"><?php foreach ($imgs as $i): ?><img src="<?= e(img_url('custom', $i['image_path'])) ?>" style="height:90px" class="rounded" alt=""><?php endforeach; ?></div>
<?php if ($open): ?><form method="post" class="mt-2" onsubmit="return confirm('Close this request?')"><?= csrf() ?><input type="hidden" name="do" value="close"><button class="btn btn-sm btn-outline-danger">Close request</button></form><?php endif; ?></div>
<h2 class="h5">Quotations</h2>
<?php foreach ($qs as $q): ?><div class="card card-body mb-2"><div class="d-flex justify-content-between"><strong><?= e($q['shop_name']) ?></strong><?= badge($q['quotation_status']) ?></div>
<div class="fs-5 text-brown"><?= money($q['quoted_price']) ?></div><div class="small">Suggested deposit: <?= money($q['deposit_amount']) ?> &middot; Production: <?= (int)$q['production_days'] ?> days<?= $q['expiry_date'] ? ' &middot; Valid until ' . e($q['expiry_date']) : '' ?></div><div><?= nl2br(e($q['description'])) ?></div>
<?php if ($open && $q['quotation_status'] === 'sent'): ?><details class="mt-2"><summary class="btn btn-sm btn-brown">Accept this quotation</summary>
<form method="post" class="row g-2 mt-1"><?= csrf() ?><input type="hidden" name="do" value="accept"><input type="hidden" name="quote" value="<?= $q['id'] ?>">
<div class="col-md-4"><select name="fulfil" class="form-select"><?= opts(['delivery' => 'Delivery (+' . money(setting('delivery_fee_default')) . ')', 'collection' => 'I will collect'], 'delivery') ?></select></div>
<div class="col-md-4"><select name="method" class="form-select"><?= opts(['cash_on_delivery' => 'Cash on delivery', 'cash_on_collection' => 'Cash on collection', 'mobile_money' => 'Mobile money'], 'cash_on_delivery') ?></select></div>
<div class="col-md-4"><select name="provider" class="form-select"><?= opts(['M-Pesa' => 'M-Pesa', 'Airtel Money' => 'Airtel Money', 'Mixx by Yas' => 'Mixx by Yas', 'HaloPesa' => 'HaloPesa'], '', 'Mobile money provider') ?></select></div>
<div class="col-12"><input name="address" class="form-control" placeholder="Delivery address"></div><div class="col-12"><button class="btn btn-brown">Confirm and create order</button></div></form></details><?php endif; ?></div><?php endforeach; if (!$qs) echo '<p class="text-muted">No quotations yet.</p>'; ?>
<?php foot();

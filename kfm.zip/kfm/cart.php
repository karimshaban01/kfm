<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
if (is_post()) {
    check_post(); $cid = cart_id(false);
    if ($cid) {
        $pid = (int)p('pid');
        if (p('do') === 'remove') q('DELETE FROM cart_items WHERE cart_id=? AND product_id=?', [$cid, $pid]);
        if (p('do') === 'update') { foreach ($_POST['qty'] ?? [] as $k => $v) { $n = max(0, min(99, (int)$v)); if ($n === 0) q('DELETE FROM cart_items WHERE cart_id=? AND product_id=?', [$cid, (int)$k]); else q('UPDATE cart_items SET quantity=? WHERE cart_id=? AND product_id=?', [$n, $cid, (int)$k]); } flash('Cart updated.'); }
    }
    go('cart.php');
}
$lines = cart_lines(); $bySeller = []; $total = 0; $ok = (bool)$lines;
foreach ($lines as $l) { $bySeller[$l['shop_name']][] = $l; if ($l['buyable'] && $l['stock_ok']) $total += $l['line']; else $ok = false; }
head('Cart');
?>
<h1 class="h3"><?= t('Cart') ?></h1>
<?php if (!$lines): ?><p>Your cart is empty. <a href="<?= e(url('shop.php')) ?>">Browse furniture</a></p><?php else: ?>
<form method="post"><?= csrf() ?><input type="hidden" name="do" value="update">
<?php foreach ($bySeller as $shop => $ls): ?><div class="card mb-3"><div class="card-header">Seller: <strong><?= e($shop) ?></strong></div><div class="table-responsive"><table class="table table-sm mb-0">
<?php foreach ($ls as $l): ?><tr><td><a href="<?= e(url('product.php?slug=' . $l['slug'])) ?>"><?= e($l['product_name']) ?></a><?php if (!$l['buyable']): ?> <span class="badge text-bg-danger">Unavailable</span><?php elseif (!$l['stock_ok']): ?> <span class="badge text-bg-warning">Only <?= (int)$l['stock_quantity'] ?> left</span><?php endif; ?></td>
<td><?= money($l['price']) ?></td><td style="width:100px"><input type="number" min="0" max="99" name="qty[<?= $l['id'] ?>]" value="<?= (int)$l['quantity'] ?>" class="form-control form-control-sm"></td><td class="text-end"><?= money($l['line']) ?></td></tr><?php endforeach; ?></table></div></div><?php endforeach; ?>
<div class="d-flex justify-content-between align-items-center"><button class="btn btn-outline-secondary">Update quantities</button><div class="fs-5">Merchandise: <strong><?= money($total) ?></strong> <small class="text-muted">(delivery added at checkout)</small></div></div></form>
<div class="text-end mt-3"><?php if ($ok): ?><a class="btn btn-brown btn-lg" href="<?= e(url('checkout.php')) ?>"><?= t('Checkout') ?></a><?php else: ?><span class="text-danger">Fix the highlighted items (set quantity 0 to remove) before checkout.</span><?php endif; ?></div>
<?php endif; foot();

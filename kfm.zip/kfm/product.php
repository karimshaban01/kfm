<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$p = row("SELECT p.*, s.shop_name, s.slug shop_slug, s.status shop_status, s.location shop_loc, c.category_name FROM products p JOIN shops s ON s.id=p.shop_id JOIN categories c ON c.id=p.category_id WHERE p.slug=?", [g('slug')]);
$me = user();
$owner = $p && $me && ($me['role'] === 'admin' || (int)val('SELECT seller_id FROM shops WHERE id=?', [$p['shop_id']]) === (int)$me['id']);
if (!$p || (!in_array($p['status'], ['published', 'out_of_stock'], true) && !$owner)) throw new HttpError(404);
if (is_post()) {
    check_post();
    $qty = max(1, min(99, (int)p('qty', '1')));
    if (!in_array($p['status'], ['published', 'out_of_stock'], true) || $p['shop_status'] !== 'active') throw new UserError('This product cannot be bought right now.');
    if ($p['availability'] !== 'available') throw new UserError('This product is currently unavailable.');
    if ($p['product_type'] === 'ready_made' && $p['stock_quantity'] <= 0) throw new UserError('Sorry, this item is out of stock.');
    $cid = cart_id(true); cart_add($cid, $p['id'], $qty);
    flash('Added to your cart.'); go('cart.php');
}
$imgs = rows('SELECT * FROM product_images WHERE product_id=? ORDER BY is_primary DESC, sort_order, id', [$p['id']]);
$revs = rows("SELECT r.*, u.full_name FROM reviews r JOIN users u ON u.id=r.customer_id WHERE r.product_id=? AND r.status='published' ORDER BY r.id DESC LIMIT 20", [$p['id']]);
$avg = $revs ? array_sum(array_column($revs, 'rating')) / count($revs) : 0;
head($p['product_name']);
?>
<div class="row g-4">
  <div class="col-md-6 gal">
    <?php if ($imgs): ?><img id="main" src="<?= e(img_url('products', $imgs[0]['image_path'])) ?>" class="img-fluid rounded w-100 mb-2" alt="">
      <div class="d-flex gap-2 flex-wrap"><?php foreach ($imgs as $i): ?><img src="<?= e(img_url('products', $i['image_path'])) ?>" style="width:70px;height:70px;object-fit:cover;cursor:pointer" class="rounded border" onclick="document.getElementById('main').src=this.src" alt=""><?php endforeach; ?></div>
    <?php else: ?><div class="pimg noimg rounded">No photo</div><?php endif; ?>
  </div>
  <div class="col-md-6">
    <h1 class="h3"><?= e($p['product_name']) ?> <?= $p['status'] !== 'published' ? badge($p['status']) : '' ?></h1>
    <div class="fs-4 text-brown fw-bold"><?= money($p['price']) ?></div>
    <?php if ($revs): ?><div class="text-warning"><?= stars($avg) ?> <span class="text-muted small">(<?= count($revs) ?>)</span></div><?php endif; ?>
    <p class="mb-1">Sold by <a href="<?= e(url('shop_view.php?slug=' . $p['shop_slug'])) ?>"><?= e($p['shop_name']) ?></a> &middot; <?= e($p['shop_loc']) ?></p>
    <p class="text-muted small">Category: <?= e($p['category_name']) ?></p>
    <table class="table table-sm w-auto"><?php foreach (['material' => 'Material', 'colour' => 'Colour', 'finish' => 'Finish'] as $k => $l) if ($p[$k]) echo '<tr><th>' . $l . '</th><td>' . e($p[$k]) . '</td></tr>'; ?>
      <?php if ($p['length_cm'] || $p['width_cm'] || $p['height_cm']): ?><tr><th>Size (L x W x H)</th><td><?= (int)$p['length_cm'] ?> x <?= (int)$p['width_cm'] ?> x <?= (int)$p['height_cm'] ?> cm</td></tr><?php endif; ?>
      <tr><th>Type</th><td><?= label($p['product_type']) ?><?= $p['production_days'] ? ' - about ' . (int)$p['production_days'] . ' days to make' : '' ?></td></tr>
      <?php if ($p['product_type'] === 'ready_made'): ?><tr><th>Stock</th><td><?= $p['stock_quantity'] > 0 ? t('In stock') . ' (' . (int)$p['stock_quantity'] . ')' : t('Out of stock') ?></td></tr><?php endif; ?></table>
    <p><?= nl2br(e($p['description'])) ?></p>
    <?php $can = $p['status'] === 'published' && $p['availability'] === 'available' && ($p['product_type'] !== 'ready_made' || $p['stock_quantity'] > 0); ?>
    <?php if ($can && (!$me || $me['role'] === 'customer')): ?>
      <form method="post" class="d-flex gap-2"><?= csrf() ?><input type="number" name="qty" value="1" min="1" max="<?= $p['product_type'] === 'ready_made' ? (int)$p['stock_quantity'] : 99 ?>" class="form-control" style="width:90px"><button class="btn btn-brown"><?= t('Add to cart') ?></button></form>
    <?php elseif ($me && $me['role'] !== 'customer'): ?><div class="alert alert-info">Log in with a customer account to buy.</div>
    <?php elseif (!$can): ?><div class="alert alert-secondary">Not available to order right now.</div><?php endif; ?>
    <?php if ($p['customization_allowed'] || $p['product_type'] !== 'ready_made'): ?><a class="btn btn-outline-secondary mt-2" href="<?= e(url('custom_request.php?shop=' . $p['shop_id'])) ?>">Request a custom version</a><?php endif; ?>
  </div>
</div>
<h2 class="h5 mt-4">Reviews</h2>
<?php foreach ($revs as $r): ?><div class="border-bottom py-2"><span class="text-warning"><?= stars($r['rating']) ?></span> <strong><?= e($r['full_name']) ?></strong> <span class="text-muted small"><?= e(substr($r['created_at'], 0, 10)) ?></span><div><?= nl2br(e($r['comment'])) ?></div><?php if ($r['photo']): ?><img src="<?= e(img_url('reviews', $r['photo'])) ?>" style="max-height:120px" class="rounded mt-1" alt=""><?php endif; ?></div><?php endforeach; if (!$revs) echo '<p class="text-muted">No reviews yet. Only customers with a completed order can review.</p>'; ?>
<?php foot();

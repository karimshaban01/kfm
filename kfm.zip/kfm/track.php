<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$o = null; $sos = [];
if (g('no') !== '' || g('phone') !== '') {
    $ph = norm_phone(g('phone')); $o = $ph ? row('SELECT * FROM orders WHERE order_number=? AND customer_phone=?', [strtoupper(g('no')), $ph]) : null;
    if ($o) $sos = rows('SELECT * FROM seller_orders WHERE order_id=?', [$o['id']]); else flash('No order matches that number and phone.', 'warning');
}
head('Track order');
?>
<h1 class="h3"><?= t('Track order') ?></h1>
<form class="row g-2 mb-3"><div class="col-md-4"><input name="no" class="form-control" placeholder="Order number (KFM-2026-000001)" value="<?= e(g('no')) ?>"></div><div class="col-md-3"><input name="phone" class="form-control" placeholder="Phone used on the order" value="<?= e(g('phone')) ?>"></div><div class="col-auto"><button class="btn btn-brown">Track</button></div></form>
<?php if ($o): ?><div class="card card-body"><strong><?= e($o['order_number']) ?></strong> <?= badge($o['order_status']) ?> - <?= money($o['grand_total']) ?><?php foreach ($sos as $so): $shop = seller_shop($so['seller_id']); ?><div class="mt-2"><?= e($shop['shop_name'] ?? '') ?>: <?= badge($so['order_status']) ?></div><?php endforeach; ?></div><?php endif; ?>
<?php foot();

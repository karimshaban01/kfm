<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = need_role('customer');
if (is_post()) {
    check_post();
    if (p('do') === 'profile') {
        $name = p('name'); $email = strtolower(p('email')); if ($name === '') throw new UserError('Name is required.');
        if ($email !== '' && (!filter_var($email, FILTER_VALIDATE_EMAIL) || val('SELECT 1 FROM users WHERE email=? AND id<>?', [$email, $u['id']]))) throw new UserError('That email is invalid or already used.');
        upd('users', $u['id'], ['full_name' => $name, 'email' => $email !== '' ? $email : null]); flash('Profile saved.');
    } elseif (p('do') === 'password') {
        if (!password_verify($_POST['old'] ?? '', $u['password_hash'])) throw new UserError('Current password is wrong.');
        if (strlen($_POST['new'] ?? '') < 8) throw new UserError('New password must be at least 8 characters.');
        upd('users', $u['id'], ['password_hash' => password_hash($_POST['new'], PASSWORD_DEFAULT)]); audit('password.change', 'user', $u['id']); flash('Password changed.');
    }
    go('account.php');
}
$orders = rows('SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 50', [$u['id']]);
$reqs = rows('SELECT r.*, (SELECT COUNT(*) FROM quotations q WHERE q.custom_request_id=r.id) nq FROM custom_requests r WHERE customer_id=? ORDER BY id DESC', [$u['id']]);
head('My account');
?>
<h1 class="h3"><?= t('My account') ?></h1>
<h2 class="h5 mt-3">My orders</h2>
<div class="table-responsive"><table class="table table-sm"><tr><th>Order</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr>
<?php foreach ($orders as $o): ?><tr><td><?= e($o['order_number']) ?></td><td><?= e(substr($o['created_at'], 0, 10)) ?></td><td><?= money($o['grand_total']) ?></td><td><?= label($o['payment_method']) ?></td><td><?= badge($o['order_status']) ?></td><td><a href="<?= e(url('order.php?id=' . $o['id'])) ?>">View</a></td></tr><?php endforeach; if (!$orders) echo '<tr><td colspan="6" class="text-muted">No orders yet.</td></tr>'; ?></table></div>
<h2 class="h5 mt-3">My custom furniture requests <a class="btn btn-sm btn-outline-secondary ms-2" href="<?= e(url('custom_request.php')) ?>">New request</a></h2>
<div class="table-responsive"><table class="table table-sm"><tr><th>#</th><th>Furniture</th><th>Status</th><th>Quotes</th><th></th></tr>
<?php foreach ($reqs as $r): ?><tr><td><?= $r['id'] ?></td><td><?= e($r['furniture_type']) ?></td><td><?= badge($r['request_status']) ?></td><td><?= (int)$r['nq'] ?></td><td><a href="<?= e(url('request.php?id=' . $r['id'])) ?>">View</a></td></tr><?php endforeach; if (!$reqs) echo '<tr><td colspan="5" class="text-muted">None.</td></tr>'; ?></table></div>
<div class="row g-3 mt-1"><div class="col-md-6"><div class="card card-body"><h2 class="h6">Profile</h2><form method="post"><?= csrf() ?><input type="hidden" name="do" value="profile"><input name="name" value="<?= e($u['full_name']) ?>" class="form-control mb-2"><input name="email" value="<?= e($u['email']) ?>" class="form-control mb-2" placeholder="Email"><div class="small text-muted mb-2">Phone: <?= e($u['phone']) ?></div><button class="btn btn-sm btn-brown">Save</button></form></div></div>
<div class="col-md-6"><div class="card card-body"><h2 class="h6">Change password</h2><form method="post"><?= csrf() ?><input type="hidden" name="do" value="password"><input type="password" name="old" class="form-control mb-2" placeholder="Current password" required><input type="password" name="new" class="form-control mb-2" placeholder="New password (8+)" required><button class="btn btn-sm btn-brown">Change</button></form></div></div></div>
<?php foot();

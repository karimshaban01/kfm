<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$u = user(); if (!$u) { $_SESSION['next'] = url('custom_request.php'); flash('Log in or register to request custom furniture.', 'info'); go('login.php'); }
if ($u['role'] !== 'customer') throw new HttpError(403, 'Only customers can request custom furniture.');
if (is_post()) {
    check_post();
    $type = p('type'); $desc = p('description'); if ($type === '' || strlen($desc) < 10) throw new UserError('Enter the furniture type and describe what you want (at least 10 characters).');
    $files = upload_list('images'); if (count($files) > 5) throw new UserError('Upload at most 5 reference images.');
    $names = []; foreach ($files as $f) $names[] = store_image($f, 'custom');
    $rid = tx(function () use ($u, $type, $desc, $names) {
        $rid = insert('custom_requests', ['customer_id' => $u['id'], 'customer_name' => $u['full_name'], 'customer_phone' => $u['phone'], 'furniture_type' => $type, 'description' => $desc, 'dimensions' => p('dimensions') ?: null, 'material' => p('material') ?: null, 'colour' => p('colour') ?: null,
            'budget' => p('budget') !== '' ? (float)p('budget') : null, 'required_date' => p('required_date') ?: null, 'request_status' => 'open', 'created_at' => now()]);
        foreach ($names as $n) insert('custom_request_images', ['custom_request_id' => $rid, 'image_path' => $n, 'created_at' => now()]);
        foreach (rows("SELECT s.seller_id FROM shops s JOIN users x ON x.id=s.seller_id WHERE s.status='active' AND x.status='active'") as $s) notify($s['seller_id'], 'New custom furniture request', $type, 'request', $rid);
        return $rid;
    });
    flash('Request sent to our sellers. You will be notified when quotations arrive.'); go('request.php?id=' . $rid);
}
head('Custom furniture');
?>
<div class="row justify-content-center"><div class="col-md-8"><div class="card card-body"><h1 class="h4"><?= t('Custom furniture') ?></h1><p class="text-muted">Describe what you need. Sellers will send you quotations; you choose one.</p>
<form method="post" enctype="multipart/form-data"><?= csrf() ?><div class="row g-2">
<div class="col-md-6"><label class="form-label">Furniture type</label><input name="type" class="form-control" required placeholder="e.g. Wardrobe, bed, dining table"></div>
<div class="col-md-6"><label class="form-label">Dimensions</label><input name="dimensions" class="form-control" placeholder="e.g. 200 x 100 x 220 cm"></div>
<div class="col-md-4"><label class="form-label">Preferred wood / material</label><input name="material" class="form-control"></div><div class="col-md-4"><label class="form-label">Colour / finish</label><input name="colour" class="form-control"></div>
<div class="col-md-4"><label class="form-label">Budget (TZS)</label><input type="number" min="0" name="budget" class="form-control"></div>
<div class="col-md-6"><label class="form-label">Needed by</label><input type="date" name="required_date" class="form-control"></div>
<div class="col-12"><label class="form-label">Description</label><textarea name="description" rows="5" class="form-control" required></textarea></div>
<div class="col-12"><label class="form-label">Reference photos (up to 5)</label><input type="file" name="images[]" multiple accept="image/*" class="form-control"></div></div>
<button class="btn btn-brown mt-3">Send request</button></form></div></div></div>
<?php foot();

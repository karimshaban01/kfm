<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$bw = buyable_where();
$feat = rows("SELECT p.*, s.shop_name FROM products p JOIN shops s ON s.id=p.shop_id JOIN users u ON u.id=s.seller_id WHERE $bw AND p.is_featured=1 ORDER BY p.id DESC LIMIT 8");
$new = rows("SELECT p.*, s.shop_name FROM products p JOIN shops s ON s.id=p.shop_id JOIN users u ON u.id=s.seller_id WHERE $bw ORDER BY p.id DESC LIMIT 8");
$cats = rows("SELECT c.* FROM categories c WHERE c.status='active' ORDER BY c.category_name");
$shops = rows("SELECT * FROM shops WHERE status='active' ORDER BY id DESC LIMIT 6");
head('Home');
?>
<div class="p-4 p-md-5 mb-4 bg-brown text-white rounded-3">
  <h1 class="display-6 fw-bold"><?= e(setting('marketplace_name')) ?></h1>
  <p class="lead mb-3">Locally made wooden furniture from Kasulu's best carpenters - buy from several shops in one checkout.</p>
  <form action="<?= e(url('shop.php')) ?>" class="row g-2"><div class="col-md-6"><input name="q" class="form-control" placeholder="<?= e(t('Search furniture...')) ?>"></div><div class="col-auto"><button class="btn btn-warning"><?= t('Search') ?></button></div></form>
</div>
<div class="mb-4 d-flex flex-wrap gap-2"><?php foreach ($cats as $c): ?><a class="btn btn-outline-secondary btn-sm" href="<?= e(url('shop.php?cat=' . $c['id'])) ?>"><?= e($c['category_name']) ?></a><?php endforeach; ?></div>
<?php if ($feat): ?><h2 class="h4"><?= t('Featured furniture') ?></h2><div class="row g-3 mb-4"><?php foreach ($feat as $p) product_card($p); ?></div><?php endif; ?>
<h2 class="h4">New arrivals</h2><div class="row g-3 mb-4"><?php foreach ($new as $p) product_card($p); if (!$new) echo '<p class="text-muted">No products yet.</p>'; ?></div>
<h2 class="h4">Our shops</h2><div class="row g-3"><?php foreach ($shops as $s): ?><div class="col-md-4"><a class="card card-body text-decoration-none" href="<?= e(url('shop_view.php?slug=' . $s['slug'])) ?>"><strong><?= e($s['shop_name']) ?></strong><span class="small text-muted"><?= e($s['location']) ?></span></a></div><?php endforeach; ?></div>
<?php foot();

<?php
require __DIR__ . '/includes/app.php'; require __DIR__ . '/includes/layout.php';
$w = [buyable_where()]; $par = [];
if (g('q') !== '') { $w[] = '(p.product_name LIKE ? OR p.description LIKE ? OR p.material LIKE ?)'; $l = '%' . g('q') . '%'; array_push($par, $l, $l, $l); }
if ((int)g('cat')) { $w[] = 'p.category_id=?'; $par[] = (int)g('cat'); }
if (g('material') !== '') { $w[] = 'p.material LIKE ?'; $par[] = '%' . g('material') . '%'; }
if ((float)g('min') > 0) { $w[] = 'p.price>=?'; $par[] = (float)g('min'); }
if ((float)g('max') > 0) { $w[] = 'p.price<=?'; $par[] = (float)g('max'); }
if (g('type') !== '') { $w[] = 'p.product_type=?'; $par[] = g('type'); }
$order = ['new' => 'p.id DESC', 'low' => 'p.price ASC', 'high' => 'p.price DESC'][g('sort', 'new')] ?? 'p.id DESC';
[$items, $page, $pages, $total] = paginate("SELECT p.*, s.shop_name FROM products p JOIN shops s ON s.id=p.shop_id JOIN users u ON u.id=s.seller_id WHERE " . implode(' AND ', $w) . " ORDER BY $order", $par, 12);
$cats = array_column(rows("SELECT id, category_name FROM categories WHERE status='active' ORDER BY category_name"), 'category_name', 'id');
head('Shop');
?>
<h1 class="h3"><?= t('Shop') ?></h1>
<form class="row g-2 mb-3">
  <div class="col-md-3"><input name="q" value="<?= e(g('q')) ?>" class="form-control" placeholder="<?= e(t('Search furniture...')) ?>"></div>
  <div class="col-md-2"><select name="cat" class="form-select"><?= opts($cats, g('cat'), t('All categories')) ?></select></div>
  <div class="col-md-2"><input name="material" value="<?= e(g('material')) ?>" class="form-control" placeholder="Material"></div>
  <div class="col-6 col-md-1"><input name="min" value="<?= e(g('min')) ?>" class="form-control" placeholder="Min"></div>
  <div class="col-6 col-md-1"><input name="max" value="<?= e(g('max')) ?>" class="form-control" placeholder="Max"></div>
  <div class="col-md-2"><select name="sort" class="form-select"><?= opts(['new' => 'Newest', 'low' => 'Price: low to high', 'high' => 'Price: high to low'], g('sort', 'new')) ?></select></div>
  <div class="col-md-1"><button class="btn btn-brown w-100"><?= t('Search') ?></button></div>
</form>
<p class="text-muted small"><?= $total ?> product(s)</p>
<div class="row g-3"><?php foreach ($items as $p) product_card($p); if (!$items) echo '<p>No furniture matches your search.</p>'; ?></div>
<?php pager($page, $pages); foot();

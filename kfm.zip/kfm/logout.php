<?php
require __DIR__ . '/includes/app.php';
$_SESSION = []; if (ini_get('session.use_cookies')) { $c = session_get_cookie_params(); setcookie(session_name(), '', time() - 3600, $c['path']); }
session_destroy(); session_start(); flash('You have been logged out.', 'info'); go('index.php');
